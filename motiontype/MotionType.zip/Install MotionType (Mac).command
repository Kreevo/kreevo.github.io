#!/bin/bash
# MotionType by Kreevo - installer (macOS)
SRC="$(cd "$(dirname "$0")" && pwd)/MotionType"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/MotionType"
if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
  echo "Couldn't find the MotionType files. Double-click MotionType.zip to unzip it, then run this file again."
  read -r -p "Press Enter to close..."; exit 1
fi
if pgrep -qf "Adobe After Effects"; then
  echo "After Effects is open. Save your work, quit it, then press Enter."; read -r
fi
echo "Installing MotionType..."
rm -rf "$DEST"; mkdir -p "$DEST"
cp -R "$SRC/." "$DEST/" || { echo "Couldn't copy the files. Email kreevoassets@gmail.com"; read -r -p "Press Enter..."; exit 1; }
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
for v in 9 10 11 12 13; do defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1; done
killall cfprefsd 2>/dev/null
echo ""
echo "  Done! MotionType 2.0 is installed."
echo "  Open After Effects: Window > Extensions > MotionType by Kreevo"
echo ""
sleep 6
osascript -e 'tell application "Terminal" to close front window' >/dev/null 2>&1 &
exit 0
