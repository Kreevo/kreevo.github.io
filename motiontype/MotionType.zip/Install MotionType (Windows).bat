@echo off
setlocal
title MotionType installer
color 0F
set "SRC=%~dp0MotionType"
set "DEST=%APPDATA%\Adobe\CEP\extensions\MotionType"

rem Opened straight from inside the zip? Find the zip and unpack it first.
if not exist "%SRC%\CSXS\manifest.xml" (
  set "ZIP="
  for %%d in ("%USERPROFILE%\Downloads" "%USERPROFILE%\Desktop" "%USERPROFILE%\OneDrive\Desktop") do (
    if exist "%%~d\MotionType.zip" if not defined ZIP set "ZIP=%%~d\MotionType.zip"
  )
  if not defined ZIP goto nozip
  set "TMPX=%TEMP%\MotionType_install"
  if exist "%TEMP%\MotionType_install" rmdir /s /q "%TEMP%\MotionType_install"
  powershell -NoProfile -Command "Expand-Archive -LiteralPath $env:ZIP -DestinationPath $env:TMPX -Force" >nul 2>&1
  set "SRC=%TEMP%\MotionType_install\MotionType"
)
if not exist "%SRC%\CSXS\manifest.xml" goto nozip

tasklist /FI "IMAGENAME eq AfterFX.exe" 2>nul | find /I "AfterFX.exe" >nul
if not errorlevel 1 (
  echo.
  echo   After Effects is open. Save your work and close it, then press any key.
  pause >nul
)

echo.
echo   Installing MotionType...
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%" >nul 2>&1
robocopy "%SRC%" "%DEST%" /E /NFL /NDL /NJH /NJS /NP >nul
if %ERRORLEVEL% GEQ 8 goto copyfail
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

echo.
echo   ===========================================
echo     Done!  MotionType 2.0 is installed.
echo   ===========================================
echo.
echo   Open After Effects:
echo   Window ^> Extensions ^> MotionType by Kreevo
echo.
echo   (This window closes in 10 seconds.)
timeout /t 10 >nul
exit /b 0

:nozip
echo.
echo   Couldn't find the MotionType files.
echo   Right-click MotionType.zip ^> Extract All, then run this file again
echo   from the extracted folder.
echo.
pause
exit /b 1

:copyfail
echo.
echo   Couldn't copy the files. Close After Effects and run this file again.
echo   Still stuck? Email kreevoassets@gmail.com
echo.
pause
exit /b 1
