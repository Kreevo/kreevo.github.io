// MotionType 2.0 by Kreevo — After Effects host script (ExtendScript, ES3).
// The panel sends one plain object per Apply; everything the panel's
// sliders control is written as "MT ..." Slider Controls on the layer and
// read back by expressions, so the animation stays editable after Apply.

var MT = {};

MT.UNIT = { letter: 2, word: 3, line: 4 };   // Based On: chars excl. spaces / words / lines

MT.textLayers = function (comp) {
    var out = [], sel = comp.selectedLayers;
    for (var i = 0; i < sel.length; i++) if (sel[i] instanceof TextLayer) out.push(sel[i]);
    return out;
};

MT.fx = function (L) { return L.property("ADBE Effect Parade"); };
MT.animators = function (L) { return L.property("ADBE Text Properties").property("ADBE Text Animators"); };
MT.doc = function (L) { return L.property("ADBE Text Properties").property("ADBE Text Document"); };

MT.slider = function (L, name, val) {
    var e = MT.fx(L).addProperty("ADBE Slider Control");
    e.name = name; e.property(1).setValue(val); return e;
};
MT.checkbox = function (L, name, on) {
    var e = MT.fx(L).addProperty("ADBE Checkbox Control");
    e.name = name; e.property(1).setValue(on ? 1 : 0); return e;
};

// Removes everything a previous Apply added, so Apply on the same layer
// works as "Update" instead of stacking animators.
MT.clean = function (L) {
    var i, p;
    var fx = MT.fx(L);
    for (i = fx.numProperties; i >= 1; i--) { p = fx.property(i); if (p.name.indexOf("MT ") === 0) p.remove(); }
    var an = MT.animators(L);
    for (i = an.numProperties; i >= 1; i--) { p = an.property(i); if (p.name.indexOf("MT ") === 0) p.remove(); }
    var masks = L.property("ADBE Mask Parade");
    for (i = masks.numProperties; i >= 1; i--) { p = masks.property(i); if (p.name.indexOf("MT ") === 0) p.remove(); }
    var st = MT.doc(L);
    if (st.expression && st.expression.indexOf("MT Count To") >= 0) st.expression = "";
    var comp = L.containingComp;
    for (i = comp.numLayers; i >= 1; i--) { p = comp.layer(i); if (p.name === "MT SFX · " + L.name) p.remove(); }
};

// Paragraph alignment + anchor point, without moving the text on screen.
//   align: "left" | "center" | "right" | ""    anchor: [fx, fy] fractions of the text box, or null
MT.layout = function (L, align, anchor) {
    var tr = L.property("ADBE Transform Group"), ap = tr.property("ADBE Anchor Point"), pos = tr.property("ADBE Position");
    if (ap.numKeys || pos.numKeys || pos.dimensionsSeparated) return false;
    var sc = tr.property("ADBE Scale").value, t = L.inPoint;
    var before = L.sourceRectAtTime(t, false), P = pos.value, A0 = ap.value;
    if (align) {
        var stP = MT.doc(L), td = stP.value;
        td.justification = align === "left" ? ParagraphJustification.LEFT_JUSTIFY :
                           align === "right" ? ParagraphJustification.RIGHT_JUSTIFY : ParagraphJustification.CENTER_JUSTIFY;
        stP.setValue(td);
        var after = L.sourceRectAtTime(t, false);
        P = [P[0] + (before.left - after.left) * sc[0] / 100, P[1] + (before.top - after.top) * sc[1] / 100].concat(P.length > 2 ? [P[2]] : []);
        before = after;
    }
    if (anchor) {
        var A1 = [before.left + before.width * anchor[0], before.top + before.height * anchor[1]];
        P = [P[0] + (A1[0] - A0[0]) * sc[0] / 100, P[1] + (A1[1] - A0[1]) * sc[1] / 100].concat(P.length > 2 ? [P[2]] : []);
        ap.setValue(A0.length > 2 ? [A1[0], A1[1], A0[2]] : A1);
    }
    pos.setValue(P);
    return true;
};

// Ease curve shared by every selector/effect expression.
//   smooth: quart-out (Apple-like)   bounce: damped overshoot
//   hold:   instant (typing)         MT Bounce checkbox switches smooth->bounce live
MT.progressExpr = function (mode, perUnit) {
    var s = [];
    s.push('var d=effect("MT Delay")(1), dur=Math.max(0.01,effect("MT Duration")(1)), st=effect("MT Start")(1), b=effect("MT Bounce")(1);');
    s.push('var t=time-inPoint-st' + (perUnit ? '-(textIndex-1)*d' : '') + ';');
    s.push('var p=Math.min(Math.max(t/dur,0),1);');
    if (mode === "hold") s.push('var e=(t>=0)?1:0;');
    else s.push('var e=(b>0)?((p>=1)?1:1-Math.exp(-6*p)*Math.cos(12*p)):1-Math.pow(1-p,4);');
    return s.join("\n");
};

MT.selectorExpr = function (mode) {
    if (mode === "shake") {
        return MT.progressExpr("smooth", true) + '\nvar v=100*Math.exp(-4*p)*Math.sin(p*Math.PI*8)*(p>0&&p<1?1:0);\n[v,v,v]';
    }
    return MT.progressExpr(mode, true) + '\nvar v=100*(1-e);\n[v,v,v]';
};

MT.rgb = function (hex) {
    hex = String(hex || "#ffffff").replace("#", "");
    return [parseInt(hex.substr(0, 2), 16) / 255, parseInt(hex.substr(2, 2), 16) / 255, parseInt(hex.substr(4, 2), 16) / 255];
};

MT.findEffect = function (displayNames) {
    try {
        for (var i = 0; i < app.effects.length; i++) {
            for (var j = 0; j < displayNames.length; j++) {
                if (app.effects[i].displayName === displayNames[j]) return app.effects[i].matchName;
            }
        }
    } catch (e) {}
    return null;
};

MT.setByName = function (eff, names, val) {
    for (var i = 0; i < names.length; i++) {
        try { var p = eff.property(names[i]); if (p) { p.setValue(val); return true; } } catch (e) {}
    }
    return false;
};

MT.centerAnchor = function (L) {
    try {
        var r = L.sourceRectAtTime(L.inPoint, false);
        L.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([r.left + r.width / 2, r.top + r.height / 2]);
    } catch (e) {}
};

MT.importSfx = function (path) {
    var f = new File(path);
    if (!f.exists) return null;
    var proj = app.project, folder = null, i, it;
    for (i = 1; i <= proj.numItems; i++) {
        it = proj.item(i);
        if (it instanceof FootageItem && it.file && it.file.fsName === f.fsName) return it;
        if (it instanceof FolderItem && it.name === "MotionType SFX") folder = it;
    }
    it = proj.importFile(new ImportOptions(f));
    if (!folder) folder = proj.items.addFolder("MotionType SFX");
    it.parentFolder = folder;
    return it;
};

MT.unitCount = function (L, unit) {
    var s = "";
    try { s = String(MT.doc(L).value.text); } catch (e) {}
    if (unit === "line") return Math.max(1, s.split(/[\r\n]+/).length);
    if (unit === "word") return Math.max(1, s.replace(/^\s+|\s+$/g, "").split(/\s+/).length);
    return Math.max(1, s.replace(/\s+/g, "").length);
};

// --------------------------------------------------------------- setup
MT.setup = function (comp, L, o, startOffset) {
    MT.clean(L);
    var rect = L.sourceRectAtTime(L.inPoint, false);
    var A = o.anim || {};

    // style: colour / outline written into the text document itself
    try {
        var stP = MT.doc(L), td = stP.value, wasOutline = String(L.comment).indexOf("· Outline") >= 0;
        var col = o.color ? MT.rgb(o.color) : (td.applyFill ? td.fillColor : td.strokeColor);
        if (o.outline) {
            td.applyFill = false; td.applyStroke = true; td.strokeColor = col;
            td.strokeWidth = Math.max(2, Math.round(td.fontSize / 28));
        } else {
            if (wasOutline) { td.applyStroke = false; td.applyFill = true; }
            if (o.color) { td.applyFill = true; td.fillColor = col; }
        }
        stP.setValue(td);
    } catch (eStyle) {}

    MT.slider(L, "MT Amount", o.amount);
    MT.slider(L, "MT Delay", o.delay);
    MT.slider(L, "MT Duration", o.dur);
    MT.slider(L, "MT Blur", o.blur);
    MT.slider(L, "MT Start", startOffset);
    MT.checkbox(L, "MT Bounce", o.bounce);

    var T = o.dur + (MT.unitCount(L, o.unit) - 1) * o.delay;

    // counter: Source Text expression, no animator
    if (o.counter) {
        var raw = String(o.text || ""), m = raw.match(/[\d.,]+/);
        var num = m ? parseFloat(m[0].replace(/,/g, "")) : 1000;
        var pre = m ? raw.substr(0, raw.indexOf(m[0])) : "", suf = m ? raw.substr(raw.indexOf(m[0]) + m[0].length) : "";
        MT.slider(L, "MT Count To", isNaN(num) ? 1000 : num);
        MT.doc(L).expression =
            MT.progressExpr("smooth", false) +
            '\nvar n=Math.round(effect("MT Count To")(1)*e);\nvar s=String(n).replace(/\\B(?=(\\d{3})+(?!\\d))/g,",");\n' +
            '"' + pre.replace(/"/g, '\\"') + '"+s+"' + suf.replace(/"/g, '\\"') + '"';
        T = o.dur;
    }

    // main animator
    var hasAnim = A.pos || (A.scale !== undefined && A.scale !== null) || A.rot || A.op || A.track || A.coff;
    if (hasAnim) {
        var an = MT.animators(L).addProperty("ADBE Text Animator");
        an.name = "MT Animator";
        var props = an.property("ADBE Text Animator Properties");
        if (A.pos) {
            var pp = props.addProperty("ADBE Text Position 3D");
            pp.expression = 'var a=effect("MT Amount")(1);\n[a*' + A.pos[0] + ', a*' + A.pos[1] + ', 0]';
        }
        if (A.scale !== undefined && A.scale !== null) {
            var sv = (A.scale instanceof Array) ? A.scale : [A.scale, A.scale];
            props.addProperty("ADBE Text Scale 3D").setValue([sv[0], sv[1], 100]);
        }
        if (A.rot) props.addProperty("ADBE Text Rotation").setValue(A.rot);
        if (A.track) props.addProperty("ADBE Text Tracking Amount").setValue(A.track);
        if (A.coff) props.addProperty("ADBE Text Character Offset").setValue(A.coff);
        if (A.op) props.addProperty("ADBE Text Opacity").setValue(0);
        var bl = props.addProperty("ADBE Text Blur");
        bl.expression = 'var b=effect("MT Blur")(1);\n[b,b]';

        var sel = an.property("ADBE Text Selectors").addProperty("ADBE Text Expressible Selector");
        sel.name = "MT Selector";
        sel.property("ADBE Text Range Type2").setValue(MT.UNIT[o.unit] || 2);
        sel.property("ADBE Text Expressible Amount").expression = MT.selectorExpr(o.mode);
    }

    // gradient: second animator fades fill A -> B across the text
    if (o.color2) {
        var g = MT.animators(L).addProperty("ADBE Text Animator");
        g.name = "MT Gradient";
        g.property("ADBE Text Animator Properties").addProperty("ADBE Text Fill Color").setValue(MT.rgb(o.color2));
        var rs = g.property("ADBE Text Selectors").addProperty("ADBE Text Selector");
        try { rs.property("ADBE Text Range Advanced").property("ADBE Text Range Shape").setValue(2); } catch (eSh) {}
    }

    // reveal mask (Mask Reveal / Line Lift): text rises out from behind a line
    if (o.mask) {
        var big = Math.max(rect.width, rect.height) * 3 + 2000, pad = 8;
        var x0 = rect.left - big, x1 = rect.left + rect.width + big, y0 = rect.top - big, y1 = rect.top + rect.height + big;
        if (o.dir === "up") y1 = rect.top + rect.height + pad;          // enters from below: clip the bottom edge
        else if (o.dir === "down") y0 = rect.top - pad;
        else if (o.dir === "left") x1 = rect.left + rect.width + pad;   // enters from the right
        else if (o.dir === "right") x0 = rect.left - pad;
        var shp = new Shape();
        shp.vertices = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
        shp.closed = true;
        var mk = L.property("ADBE Mask Parade").addProperty("ADBE Mask Atom");
        mk.name = "MT Mask";
        mk.property("ADBE Mask Shape").setValue(shp);
    }

    // wipe / gradient reveal
    if (o.wipe) {
        var w = MT.fx(L).addProperty("ADBE Linear Wipe");
        w.name = "MT Wipe";
        try { w.property(2).setValue(270); } catch (eA) {}
        try { w.property(3).setValue(o.wipe.feather); } catch (eF) {}
        w.property(1).expression = MT.progressExpr("smooth", false) + '\n100*(1-e)';
    }

    var t0 = L.inPoint + startOffset;

    // glow: Deep Glow when installed, else AE's own Glow
    if (o.glow) {
        var dg = MT.findEffect(["Deep Glow", "Deep Glow 2"]);
        var ge = MT.fx(L).addProperty(dg || "ADBE Glo2");
        ge.name = "MT Glow";
        if (!dg) {
            MT.setByName(ge, ["ADBE Glo2-0002", "Glow Threshold"], 45);
            MT.setByName(ge, ["ADBE Glo2-0003", "Glow Radius"], 35);
            MT.setByName(ge, ["ADBE Glo2-0004", "Glow Intensity"], 1.4);
        }
    }

    // light sweep passes over once the text has landed
    if (o.sweep) {
        var ls = MT.fx(L).addProperty("CC Light Sweep");
        ls.name = "MT Light Sweep";
        MT.setByName(ls, ["Direction"], 25);
        MT.setByName(ls, ["Width"], Math.max(30, rect.height * 0.6));
        MT.setByName(ls, ["Sweep Intensity"], 60);
        try {
            var c = ls.property("Center"), y = rect.top + rect.height / 2, ts = t0 + T * 0.85;
            c.setValueAtTime(ts, [rect.left - rect.height, y]);
            c.setValueAtTime(ts + 0.9, [rect.left + rect.width + rect.height, y]);
        } catch (eC) {}
    }

    // sound effect, one per layer, starting with the animation
    if (o.sfxPath) {
        var item = MT.importSfx(o.sfxPath);
        if (item) {
            var sl = comp.layers.add(item);
            sl.name = "MT SFX · " + L.name;
            sl.startTime = t0;
            if (o.mode === "hold") sl.outPoint = Math.min(sl.outPoint, t0 + T + 0.1);
            sl.moveBefore(L);
            try { sl.property("ADBE Audio Group").property("ADBE Audio Levels").setValue([-6, -6]); } catch (eL) {}
        }
    }
    L.comment = "MotionType 2.0 · " + o.name;
};

// --------------------------------------------------------------- entry points
function mt2_selection() {
    try {
        var c = app.project.activeItem;
        if (!(c && c instanceof CompItem)) return "nocomp";
        return String(MT.textLayers(c).length);
    } catch (e) { return "nocomp"; }
}

function mt2_apply(o) {
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) return "ERR:Open a composition first.";
    app.beginUndoGroup("MotionType: " + o.name);
    var res;
    try {
        var layers = MT.textLayers(comp), created = false;
        if (!layers.length) {
            if (!o.text) throw new Error("Select a text layer, or type some text in the panel.");
            var L = comp.layers.addText(o.text);
            var stP = MT.doc(L), td = stP.value;
            td.fontSize = Math.round(Math.min(comp.width, comp.height) / 10);
            td.justification = ParagraphJustification.CENTER_JUSTIFY;
            td.applyFill = true; td.fillColor = [1, 1, 1];
            stP.setValue(td);
            L.startTime = comp.time;
            MT.centerAnchor(L);
            L.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width / 2, comp.height / 2]);
            layers.push(L); created = true;
        }
        var anchor = o.anchor ? [o.anchor[0], o.anchor[1]] : null, skipped = 0;
        for (var i = 0; i < layers.length; i++) {
            if ((o.align || anchor) && !MT.layout(layers[i], o.align, anchor)) skipped++;
            MT.setup(comp, layers[i], o, 0);
        }
        res = "OK:" + layers.length + ":" + (created ? "new" : "") + ":" + skipped;
    } catch (e) {
        res = "ERR:" + (e.message || e.toString()) + (e.line ? " (line " + e.line + ")" : "");
    }
    app.endUndoGroup();
    return res;
}

// Replaces the live Expression Selector with a plain Range Selector driven
// by two Offset keyframes, and freezes the slider-driven values, so the
// animation can be edited in the Graph Editor like any keyframed text.
function mt2_bake() {
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) return "ERR:Open a composition first.";
    var layers = MT.textLayers(comp);
    if (!layers.length) return "ERR:Select the MotionType text layers to bake.";
    app.beginUndoGroup("MotionType: Bake to keyframes");
    var baked = 0, res;
    try {
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i], an = MT.animators(L).property("MT Animator");
            if (!an) continue;
            var sels = an.property("ADBE Text Selectors"), es = sels.property("MT Selector");
            if (!es) continue;
            var fx = MT.fx(L);
            var d = fx.property("MT Delay").property(1).value, dur = fx.property("MT Duration").property(1).value;
            var st = fx.property("MT Start").property(1).value;
            var based = es.property("ADBE Text Range Type2").value;
            var unit = based === 4 ? "line" : based === 3 ? "word" : "letter";
            var hold = es.property("ADBE Text Expressible Amount").expression.indexOf("(t>=0)?1:0") >= 0;
            var T = dur + (MT.unitCount(L, unit) - 1) * d, t0 = L.inPoint + st;
            var w = Math.max(1, 100 * dur / Math.max(T, 0.001));

            var rs = sels.addProperty("ADBE Text Selector");
            rs.name = "MT Range (keyframes)";
            var adv = rs.property("ADBE Text Range Advanced");
            adv.property("ADBE Text Range Type2").setValue(based);
            adv.property("ADBE Text Range Shape").setValue(hold ? 1 : 2);
            rs.property("ADBE Text Percent Start").setValue(0);
            rs.property("ADBE Text Percent End").setValue(hold ? 100 : w);
            var off = rs.property("ADBE Text Percent Offset");
            off.setValueAtTime(t0, hold ? 0 : -w);
            off.setValueAtTime(t0 + T, 100);
            if (!hold) {
                var ein = [new KeyframeEase(0, 20)], eout = [new KeyframeEase(0, 75)];
                off.setTemporalEaseAtKey(1, ein, eout); off.setTemporalEaseAtKey(2, eout, ein);
            } else {
                off.setInterpolationTypeAtKey(1, KeyframeInterpolationType.LINEAR);
                off.setInterpolationTypeAtKey(2, KeyframeInterpolationType.LINEAR);
            }
            es.remove();

            var props = an.property("ADBE Text Animator Properties");
            for (var k = 1; k <= props.numProperties; k++) {
                var p = props.property(k);
                if (p.expression) { var v = p.valueAtTime(t0, false); p.expression = ""; p.setValue(v); }
            }
            var gone = ["MT Amount", "MT Blur"];
            for (var g = 0; g < gone.length; g++) { var e = fx.property(gone[g]); if (e) e.remove(); }
            baked++;
        }
        res = baked ? "OK:" + baked : "ERR:No MotionType animation found on the selected layers.";
    } catch (err) {
        res = "ERR:" + (err.message || err.toString()) + (err.line ? " (line " + err.line + ")" : "");
    }
    app.endUndoGroup();
    return res;
}
