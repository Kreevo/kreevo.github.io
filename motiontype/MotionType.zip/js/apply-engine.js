// ---------------------------------------------------------------
// APPLY ENGINE — MotionType is After Effects–only, so this is much
// smaller than a dual-host engine: one preset mechanism (so far),
// applied by generating ExtendScript and running it via
// CSInterface.evalScript, wrapped in a single undo group.
// ---------------------------------------------------------------

function getExtensionRootPath() {
    try {
        if (typeof CSInterface !== "undefined" && typeof SystemPath !== "undefined") {
            var cs = new CSInterface();
            return cs.getSystemPath(SystemPath.EXTENSION);
        }
    } catch (e) {}
    return "";
}

function jsxStringLiteral(str) {
    return '"' + String(str).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
}

// Creates brand-new text layers via AE's own documented
// LayerCollection.addText() call — not a pre-authored/duplicated
// composition and not a modification of an already-selected layer, so
// there's no property-name guessing risk and no "select a layer first"
// requirement. Each line gets its own layer, keyframed with the same
// Position/Opacity approach proven reliable across every AE preset in
// this product line, staggered so lines cascade in one after another.
// `style` picks the offset each line starts from before settling at
// its stacked position: "bottom" (slide up, the original), "fade" (no
// motion, just opacity), "sides" (alternating left/right slide).
function buildMultiLineRevealJSX_AE(userLines, style) {
    if (!userLines || !userLines.length) {
        return 'return "ERR:No text entered.";';
    }
    var linesArr = '[' + userLines.map(jsxStringLiteral).join(', ') + ']';
    var lines = [];
    lines.push('var __lines = ' + linesArr + ';');
    lines.push('var __lineGap = 90;');
    lines.push('var __totalH = (__lines.length - 1) * __lineGap;');
    lines.push('for (var __li = 0; __li < __lines.length; __li++) {');
    lines.push('  var __txtLayer = comp.layers.addText(__lines[__li]);');
    lines.push('  try {');
    lines.push('    var __td = __txtLayer.property("Source Text").value;');
    lines.push('    __td.fontSize = Math.max(24, Math.min(90, comp.width / 14));');
    lines.push('    __td.fillColor = [1, 1, 1];');
    lines.push('    __td.justification = ParagraphJustification.CENTER_JUSTIFY;');
    lines.push('    __txtLayer.property("Source Text").setValue(__td);');
    lines.push('  } catch (eFmt) {}');
    lines.push('  __txtLayer.startTime = anchorTime;');
    lines.push('  try {');
    lines.push('    var __rect = __txtLayer.sourceRectAtTime(anchorTime, false);');
    lines.push('    __txtLayer.property("Anchor Point").setValue([__rect.left + __rect.width / 2, __rect.top + __rect.height / 2]);');
    lines.push('  } catch (eAnchor) {}');
    lines.push('  var __baseX = comp.width / 2;');
    lines.push('  var __baseY = comp.height / 2 - __totalH / 2 + __li * __lineGap;');
    lines.push('  var __posProp = __txtLayer.property("Position");');
    lines.push('  var __opProp = __txtLayer.property("Opacity");');
    lines.push('  var __delay = 0.15 * __li;');
    lines.push('  __opProp.setValueAtTime(anchorTime + __delay, 0);');
    lines.push('  __opProp.setValueAtTime(anchorTime + __delay + 0.22, 100);');
    if (style === "fade") {
        lines.push('  __posProp.setValue([__baseX, __baseY]);');
    } else if (style === "sides") {
        lines.push('  var __sideSign = (__li % 2 === 0) ? -1 : 1;');
        lines.push('  __posProp.setValueAtTime(anchorTime + __delay, [__baseX + __sideSign * 130, __baseY]);');
        lines.push('  __posProp.setValueAtTime(anchorTime + __delay + 0.3, [__baseX, __baseY]);');
    } else { // "bottom" (default)
        lines.push('  __posProp.setValueAtTime(anchorTime + __delay, [__baseX, __baseY + 34]);');
        lines.push('  __posProp.setValueAtTime(anchorTime + __delay + 0.3, [__baseX, __baseY]);');
    }
    lines.push('  easyEaseAll(__posProp);');
    lines.push('  easyEaseAll(__opProp);');
    lines.push('}');
    return lines.join('\n');
}

// Same creation-only approach as buildMultiLineRevealJSX_AE. `style`
// picks both the layout and the per-item motion:
//   "pop"   (default) — one horizontal row, each word scale-punches in
//   "slide" — one horizontal row, each word slides up + fades in
//   "stack" — one word per line, stacked vertically, each pops in
// All three still just create layers via addText() and measure them
// with sourceRectAtTime() — only the layout math and which properties
// get keyframed change.
function buildWordPopJSX_AE(words, style) {
    if (!words || !words.length) {
        return 'return "ERR:No text entered.";';
    }
    var wordsArr = '[' + words.map(jsxStringLiteral).join(', ') + ']';
    var lines = [];
    lines.push('var __words = ' + wordsArr + ';');
    lines.push('var __wordLayers = [];');
    lines.push('var __wordSizes = [];');
    lines.push('for (var __wi = 0; __wi < __words.length; __wi++) {');
    lines.push('  var __wLayer = comp.layers.addText(__words[__wi]);');
    lines.push('  try {');
    lines.push('    var __wtd = __wLayer.property("Source Text").value;');
    lines.push('    __wtd.fontSize = Math.max(28, Math.min(100, comp.width / 12));');
    lines.push('    __wtd.fillColor = [1, 1, 1];');
    lines.push('    __wLayer.property("Source Text").setValue(__wtd);');
    lines.push('  } catch (eFmt) {}');
    lines.push('  __wLayer.startTime = anchorTime;');
    lines.push('  var __wRect = __wLayer.sourceRectAtTime(anchorTime, false);');
    lines.push('  try {');
    lines.push('    __wLayer.property("Anchor Point").setValue([__wRect.left + __wRect.width / 2, __wRect.top + __wRect.height / 2]);');
    lines.push('  } catch (eAnchor) {}');
    lines.push('  __wordLayers.push(__wLayer);');
    lines.push('  __wordSizes.push({ w: __wRect.width, h: __wRect.height });');
    lines.push('}');

    if (style === "stack") {
        lines.push('var __gap = 74;');
        lines.push('var __totalH = (__wordLayers.length - 1) * __gap;');
        lines.push('for (var __wj = 0; __wj < __wordLayers.length; __wj++) {');
        lines.push('  var __wl = __wordLayers[__wj];');
        lines.push('  var __wX = comp.width / 2;');
        lines.push('  var __wY = comp.height / 2 - __totalH / 2 + __wj * __gap;');
        lines.push('  __wl.property("Position").setValue([__wX, __wY]);');
        lines.push('  var __scaleProp = __wl.property("Scale");');
        lines.push('  var __opProp = __wl.property("Opacity");');
        lines.push('  var __wDelay = 0.14 * __wj;');
        lines.push('  __scaleProp.setValueAtTime(anchorTime + __wDelay, [0, 0]);');
        lines.push('  __scaleProp.setValueAtTime(anchorTime + __wDelay + 0.18, [116, 116]);');
        lines.push('  __scaleProp.setValueAtTime(anchorTime + __wDelay + 0.28, [100, 100]);');
        lines.push('  __opProp.setValueAtTime(anchorTime + __wDelay, 0);');
        lines.push('  __opProp.setValueAtTime(anchorTime + __wDelay + 0.08, 100);');
        lines.push('  easyEaseAll(__scaleProp);');
        lines.push('  easyEaseAll(__opProp);');
        lines.push('}');
        return lines.join('\n');
    }

    lines.push('var __wordSpacing = 22;');
    lines.push('var __totalW = 0;');
    lines.push('for (var __wsum = 0; __wsum < __wordSizes.length; __wsum++) {');
    lines.push('  __totalW += __wordSizes[__wsum].w;');
    lines.push('  if (__wsum > 0) __totalW += __wordSpacing;');
    lines.push('}');
    lines.push('var __cursorX = comp.width / 2 - __totalW / 2;');
    lines.push('for (var __wk = 0; __wk < __wordLayers.length; __wk++) {');
    lines.push('  var __wl2 = __wordLayers[__wk];');
    lines.push('  var __wCenterX = __cursorX + __wordSizes[__wk].w / 2;');
    lines.push('  var __wY2 = comp.height / 2;');
    lines.push('  var __wDelay2 = 0.12 * __wk;');
    lines.push('  var __opProp2 = __wl2.property("Opacity");');
    lines.push('  __opProp2.setValueAtTime(anchorTime + __wDelay2, 0);');
    lines.push('  __opProp2.setValueAtTime(anchorTime + __wDelay2 + 0.08, 100);');
    lines.push('  easyEaseAll(__opProp2);');
    if (style === "slide") {
        lines.push('  var __posProp2 = __wl2.property("Position");');
        lines.push('  __posProp2.setValueAtTime(anchorTime + __wDelay2, [__wCenterX, __wY2 + 28]);');
        lines.push('  __posProp2.setValueAtTime(anchorTime + __wDelay2 + 0.26, [__wCenterX, __wY2]);');
        lines.push('  easyEaseAll(__posProp2);');
    } else { // "pop" (default)
        lines.push('  __wl2.property("Position").setValue([__wCenterX, __wY2]);');
        lines.push('  var __scaleProp2 = __wl2.property("Scale");');
        lines.push('  __scaleProp2.setValueAtTime(anchorTime + __wDelay2, [0, 0]);');
        lines.push('  __scaleProp2.setValueAtTime(anchorTime + __wDelay2 + 0.18, [118, 118]);');
        lines.push('  __scaleProp2.setValueAtTime(anchorTime + __wDelay2 + 0.28, [100, 100]);');
        lines.push('  easyEaseAll(__scaleProp2);');
    }
    lines.push('  __cursorX += __wordSizes[__wk].w + __wordSpacing;');
    lines.push('}');
    return lines.join('\n');
}

// One layer, built with the FULL text first so it can be measured up
// front — then Source Text itself is keyframed with progressively
// longer substrings ("H", "He", "Hel", ...), a plain, well-documented
// way to fake a per-character typewriter reveal without AE's
// per-character Animator/Range Selector API (the one that caused real
// match-name errors in CreatorStash before real .ffx files fixed it).
//   centerMode false (default) — left-justified, anchored to the
//     FINAL text's left edge, so it types outward to the right without
//     re-centering every frame.
//   centerMode true — center-justified and re-centered at every single
//     keyframe (anchor point recomputed each step), so the growing
//     text stays centered as a whole the entire time instead of
//     growing from a fixed left edge.
function buildTypewriterLineJSX_AE(fullText, centerMode) {
    if (!fullText) {
        return 'return "ERR:No text entered.";';
    }
    var lines = [];
    lines.push('var __full = ' + jsxStringLiteral(fullText) + ';');
    lines.push('var __twLayer = comp.layers.addText(__full);');
    lines.push('try {');
    lines.push('  var __twStyle = __twLayer.property("Source Text").value;');
    lines.push('  __twStyle.fontSize = Math.max(24, Math.min(90, comp.width / 14));');
    lines.push('  __twStyle.fillColor = [1, 1, 1];');
    lines.push('  __twStyle.justification = ' + (centerMode ? 'ParagraphJustification.CENTER_JUSTIFY' : 'ParagraphJustification.LEFT_JUSTIFY') + ';');
    lines.push('  __twLayer.property("Source Text").setValue(__twStyle);');
    lines.push('} catch (eFmt) {}');
    lines.push('__twLayer.startTime = anchorTime;');
    lines.push('var __twRect = __twLayer.sourceRectAtTime(anchorTime, false);');

    if (centerMode) {
        lines.push('__twLayer.property("Position").setValue([comp.width / 2, comp.height / 2]);');
        lines.push('var __charDelay = Math.max(0.02, Math.min(0.09, 1.6 / Math.max(1, __full.length)));');
        lines.push('var __srcProp = __twLayer.property("Source Text");');
        lines.push('var __stepDoc = __srcProp.value;');
        lines.push('var __anchorProp = __twLayer.property("Anchor Point");');
        lines.push('for (var __ci = 0; __ci <= __full.length; __ci++) {');
        lines.push('  __stepDoc.text = __full.substring(0, __ci);');
        lines.push('  var __t = anchorTime + __ci * __charDelay;');
        lines.push('  __srcProp.setValueAtTime(__t, __stepDoc);');
        lines.push('  try {');
        lines.push('    var __stepRect = __twLayer.sourceRectAtTime(__t, false);');
        lines.push('    __anchorProp.setValueAtTime(__t, [__stepRect.left + __stepRect.width / 2, __stepRect.top + __stepRect.height / 2]);');
        lines.push('  } catch (eStepAnchor) {}');
        lines.push('}');
    } else {
        lines.push('try {');
        lines.push('  __twLayer.property("Anchor Point").setValue([__twRect.left, __twRect.top + __twRect.height / 2]);');
        lines.push('} catch (eAnchor) {}');
        lines.push('__twLayer.property("Position").setValue([comp.width / 2 - __twRect.width / 2, comp.height / 2]);');
        lines.push('var __charDelay = Math.max(0.02, Math.min(0.09, 1.6 / Math.max(1, __full.length)));');
        lines.push('var __srcProp = __twLayer.property("Source Text");');
        lines.push('var __stepDoc = __srcProp.value;');
        lines.push('for (var __ci = 0; __ci <= __full.length; __ci++) {');
        lines.push('  __stepDoc.text = __full.substring(0, __ci);');
        lines.push('  __srcProp.setValueAtTime(anchorTime + __ci * __charDelay, __stepDoc);');
        lines.push('}');
    }
    return lines.join('\n');
}

// One text layer, one whole phrase, animated in from a starting offset
// to its final centered rest position — the simplest possible variant
// of the "create it, then keyframe it" approach, parameterized by a
// declarative spec (prop + keyframe list) instead of a bespoke
// function per look. Same declarative shape CreatorStash's AE presets
// already use for plain transform animations, so this reuses a
// pattern already proven reliable rather than inventing a new one.
var SINGLE_BLOCK_SPECS = {
    slideLeft: [
        { prop: "Position", keys: [{ t: 0, v: [-140, 0] }, { t: 0.3, v: [0, 0] }] },
        { prop: "Opacity", keys: [{ t: 0, v: 0 }, { t: 0.14, v: 100 }] }
    ],
    slideRight: [
        { prop: "Position", keys: [{ t: 0, v: [140, 0] }, { t: 0.3, v: [0, 0] }] },
        { prop: "Opacity", keys: [{ t: 0, v: 0 }, { t: 0.14, v: 100 }] }
    ],
    dropTop: [
        { prop: "Position", keys: [{ t: 0, v: [0, -110] }, { t: 0.3, v: [0, 0] }] },
        { prop: "Opacity", keys: [{ t: 0, v: 0 }, { t: 0.14, v: 100 }] }
    ],
    pop: [
        { prop: "Scale", keys: [{ t: 0, v: [0, 0] }, { t: 0.18, v: [115, 115] }, { t: 0.28, v: [100, 100] }] },
        { prop: "Opacity", keys: [{ t: 0, v: 0 }, { t: 0.08, v: 100 }] }
    ],
    fade: [
        { prop: "Opacity", keys: [{ t: 0, v: 0 }, { t: 0.4, v: 100 }] }
    ],
    rotate: [
        { prop: "Rotation", keys: [{ t: 0, v: -25 }, { t: 0.32, v: 0 }] },
        { prop: "Scale", keys: [{ t: 0, v: [88, 88] }, { t: 0.32, v: [100, 100] }] },
        { prop: "Opacity", keys: [{ t: 0, v: 0 }, { t: 0.14, v: 100 }] }
    ],
    bounce: [
        { prop: "Scale", keys: [{ t: 0, v: [0, 0] }, { t: 0.16, v: [130, 130] }, { t: 0.26, v: [85, 85] }, { t: 0.34, v: [108, 108] }, { t: 0.42, v: [100, 100] }] },
        { prop: "Opacity", keys: [{ t: 0, v: 0 }, { t: 0.08, v: 100 }] }
    ]
};

function buildSingleBlockPropKeyframeJSX(spec, idx) {
    var prop = spec.prop;
    var varName = "sbp" + idx;
    var lines = [];
    lines.push('var ' + varName + ' = __sbLayer.property(' + jsxStringLiteral(prop) + ');');
    for (var i = 0; i < spec.keys.length; i++) {
        var k = spec.keys[i];
        var valExpr;
        if (prop === "Position") {
            valExpr = '[__sbBaseX + (' + k.v[0] + '), __sbBaseY + (' + k.v[1] + ')]';
        } else if (prop === "Scale") {
            valExpr = '[' + k.v[0] + ', ' + k.v[1] + ']';
        } else if (prop === "Rotation") {
            valExpr = String(k.v);
        } else { // Opacity
            valExpr = String(k.v);
        }
        lines.push(varName + '.setValueAtTime(anchorTime + ' + k.t + ', ' + valExpr + ');');
    }
    lines.push('easyEaseAll(' + varName + ');');
    return lines.join('\n');
}

function buildSingleBlockJSX_AE(text, style) {
    if (!text) {
        return 'return "ERR:No text entered.";';
    }
    var animSpecs = SINGLE_BLOCK_SPECS[style] || SINGLE_BLOCK_SPECS.fade;
    var lines = [];
    lines.push('var __sbLayer = comp.layers.addText(' + jsxStringLiteral(text) + ');');
    lines.push('try {');
    lines.push('  var __sbStyle = __sbLayer.property("Source Text").value;');
    lines.push('  __sbStyle.fontSize = Math.max(24, Math.min(90, comp.width / 14));');
    lines.push('  __sbStyle.fillColor = [1, 1, 1];');
    lines.push('  __sbStyle.justification = ParagraphJustification.CENTER_JUSTIFY;');
    lines.push('  __sbLayer.property("Source Text").setValue(__sbStyle);');
    lines.push('} catch (eFmt) {}');
    lines.push('__sbLayer.startTime = anchorTime;');
    lines.push('try {');
    lines.push('  var __sbRect = __sbLayer.sourceRectAtTime(anchorTime, false);');
    lines.push('  __sbLayer.property("Anchor Point").setValue([__sbRect.left + __sbRect.width / 2, __sbRect.top + __sbRect.height / 2]);');
    lines.push('} catch (eAnchor) {}');
    lines.push('var __sbBaseX = comp.width / 2, __sbBaseY = comp.height / 2;');
    lines.push('__sbLayer.property("Position").setValue([__sbBaseX, __sbBaseY]);');
    for (var i = 0; i < animSpecs.length; i++) {
        lines.push(buildSingleBlockPropKeyframeJSX(animSpecs[i], i));
    }
    return lines.join('\n');
}

function buildAeBranch(item) {
    var lines = [];
    lines.push('var comp = app.project.activeItem;');
    lines.push('if (!comp || !(comp instanceof CompItem)) return "ERR:Open a composition first.";');
    lines.push('function easyEaseAll(prop) {');
    lines.push('  try {');
    lines.push('    var dim = (prop.value instanceof Array) ? prop.value.length : 1;');
    lines.push('    var easeArr = [];');
    lines.push('    for (var d = 0; d < dim; d++) easeArr.push(new KeyframeEase(0, 33));');
    lines.push('    for (var k = 1; k <= prop.numKeys; k++) prop.setTemporalEaseAtKey(k, easeArr, easeArr);');
    lines.push('  } catch (eEase) {}');
    lines.push('}');
    lines.push('var anchorTime = comp.time;');

    if (item.mechanism === "multiLineReveal") {
        lines.push(buildMultiLineRevealJSX_AE(item.lines || [], item.style));
    } else if (item.mechanism === "wordPop") {
        lines.push(buildWordPopJSX_AE(item.words || [], item.style));
    } else if (item.mechanism === "typewriterLine") {
        lines.push(buildTypewriterLineJSX_AE(item.text || "", !!item.centerMode));
    } else if (item.mechanism === "singleBlock") {
        lines.push(buildSingleBlockJSX_AE(item.text || "", item.style));
    } else {
        lines.push('return "ERR:Unknown preset.";');
    }

    return lines.join("\n");
}

// Same always-close-the-undo-group shape used across Kreevo's CEP
// extensions: branch logic runs in its own inner function, so an early
// `return "ERR:...";` validation exit never skips app.endUndoGroup().
function buildApplyScript(item) {
    var aeBody = buildAeBranch(item);
    var script =
        '(function () {\n' +
        '  if (typeof app === "undefined" || !app.project) return "ERR:No active project.";\n' +
        '  app.beginUndoGroup(' + jsxStringLiteral("MotionType: Apply " + item.name) + ');\n' +
        '  var resultMsg;\n' +
        '  try {\n' +
        '    resultMsg = (function () {\n' +
        '      ' + aeBody.split("\n").join("\n      ") + '\n' +
        '      return "OK";\n' +
        '    })();\n' +
        '  } catch (eApply) {\n' +
        '    resultMsg = "ERR:" + eApply.toString();\n' +
        '  }\n' +
        '  app.endUndoGroup();\n' +
        '  return resultMsg;\n' +
        '})();';
    return script;
}

// ---------------------------------------------------------------
// Toast — brief status feedback, since there's no other feedback
// channel back from the host script. Error toasts persist until
// tapped, so there's time to screenshot the exact message.
// ---------------------------------------------------------------
var toastTimer = null;
function showToast(message, isError, durationMs, onTap) {
    var toast = document.getElementById("toast");
    if (!toast) return;
    toast.textContent = message + (isError ? "  (tap to dismiss)" : "");
    toast.classList.toggle("toast-error", !!isError);
    toast.classList.add("visible");
    toast.onclick = onTap || null;
    if (toastTimer) clearTimeout(toastTimer);
    if (isError) return;
    toastTimer = setTimeout(function () {
        toast.classList.remove("visible");
    }, durationMs || 2600);
}

(function () {
    var toastEl = document.getElementById("toast");
    if (toastEl) {
        toastEl.addEventListener("click", function () {
            toastEl.classList.remove("visible");
        });
    }
})();

function copyToClipboard(text) {
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text);
            return true;
        }
    } catch (e) {}
    try {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        var ok = document.execCommand("copy");
        document.body.removeChild(ta);
        return ok;
    } catch (e2) {
        return false;
    }
}

// `rawText` comes from the shared input bar at the bottom of the panel
// (typed once, read fresh on every card click) instead of a
// window.prompt() popup per click — each mechanism parses the SAME raw
// string the way that fits it: "|"-separated for anything line-based,
// whitespace-separated for word rows, or as one whole phrase for the
// single-block/typewriter presets.
function applyPreset(item, rawText) {
    try {
        if (typeof CSInterface === "undefined") {
            showToast("Apply only works inside After Effects.", true);
            return;
        }
        rawText = rawText || "";
        var runtimeItem = item;
        if (item.mechanism === "multiLineReveal") {
            var userLines = rawText.split("|")
                .map(function (s) { return s.replace(/^\s+|\s+$/g, ""); })
                .filter(function (s) { return s.length > 0; })
                .slice(0, 3);
            if (!userLines.length) {
                showToast("Type some text in the box below first.", true);
                return;
            }
            runtimeItem = Object.assign({}, item, { lines: userLines });
        } else if (item.mechanism === "wordPop") {
            // All three wordPop styles ("pop"/"slide"/"stack") split on
            // plain whitespace — they're all "type a phrase, one word
            // per layer" presets that only differ in LAYOUT (row vs
            // stacked column), so they should all read the same input
            // the same way. (This used to split "stack" on "|" instead,
            // which meant typing the same phrase and clicking between
            // Word Pop and Word Stack Pop gave inconsistent results —
            // a real bug, not just a style choice.)
            var userWords = rawText.split(/\s+/)
                .map(function (s) { return s.replace(/^\s+|\s+$/g, ""); })
                .filter(function (s) { return s.length > 0; })
                .slice(0, 8);
            if (!userWords.length) {
                showToast("Type some text in the box below first.", true);
                return;
            }
            runtimeItem = Object.assign({}, item, { words: userWords });
        } else if (item.mechanism === "typewriterLine" || item.mechanism === "singleBlock") {
            // These take the whole phrase as one block — "|" (used to
            // separate lines/words for the other presets) is treated as
            // a space here instead of silently dropping everything
            // after the first one, so switching from a line/word preset
            // to one of these doesn't lose part of what was typed.
            var trimmedText = rawText.replace(/\|/g, " ").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "").slice(0, 60);
            if (!trimmedText.length) {
                showToast("Type some text in the box below first.", true);
                return;
            }
            runtimeItem = Object.assign({}, item, { text: trimmedText });
        }
        var cs = new CSInterface();
        var script = buildApplyScript(runtimeItem);
        cs.evalScript(script, function (result) {
            if (!result || result.indexOf("ERR:") === 0) {
                showToast(result ? result.slice(4) : "Apply failed — unknown error.", true);
            } else {
                showToast("Applied “" + item.name + "” ✓", false);
            }
        });
    } catch (e) {
        showToast("Apply failed: " + e.message, true);
    }
}
