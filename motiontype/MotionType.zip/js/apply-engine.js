// ---------------------------------------------------------------
// APPLY ENGINE — MotionType is After Effects–only, so this is much
// smaller than a dual-host engine: one preset mechanism (so far),
// applied by generating ExtendScript and running it via
// CSInterface.evalScript, wrapped in a single undo group.
// ---------------------------------------------------------------

function getExtensionRootPath() {
    try {
        if (typeof CSInterface !== "undefined" && typeof SystemPath !== "undefined") {
            var cs = new CSInterface();
            return cs.getSystemPath(SystemPath.EXTENSION);
        }
    } catch (e) {}
    return "";
}

function jsxStringLiteral(str) {
    return '"' + String(str).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
}

// Creates brand-new text layers via AE's own documented
// LayerCollection.addText() call — not a pre-authored/duplicated
// composition and not a modification of an already-selected layer, so
// there's no property-name guessing risk and no "select a layer first"
// requirement. Each line gets its own layer, keyframed with the same
// Position/Opacity approach proven reliable across every AE preset in
// this product line, staggered so lines cascade in one after another.
function buildMultiLineRevealJSX_AE(userLines) {
    if (!userLines || !userLines.length) {
        return 'return "ERR:No text entered.";';
    }
    var linesArr = '[' + userLines.map(jsxStringLiteral).join(', ') + ']';
    var lines = [];
    lines.push('var __lines = ' + linesArr + ';');
    lines.push('var __lineGap = 90;');
    lines.push('var __totalH = (__lines.length - 1) * __lineGap;');
    lines.push('for (var __li = 0; __li < __lines.length; __li++) {');
    lines.push('  var __txtLayer = comp.layers.addText(__lines[__li]);');
    lines.push('  try {');
    lines.push('    var __td = __txtLayer.property("Source Text").value;');
    lines.push('    __td.fontSize = Math.max(24, Math.min(90, comp.width / 14));');
    lines.push('    __td.fillColor = [1, 1, 1];');
    lines.push('    __td.justification = ParagraphJustification.CENTER_JUSTIFY;');
    lines.push('    __txtLayer.property("Source Text").setValue(__td);');
    lines.push('  } catch (eFmt) {}');
    lines.push('  __txtLayer.startTime = anchorTime;');
    lines.push('  try {');
    lines.push('    var __rect = __txtLayer.sourceRectAtTime(anchorTime, false);');
    lines.push('    __txtLayer.property("Anchor Point").setValue([__rect.left + __rect.width / 2, __rect.top + __rect.height / 2]);');
    lines.push('  } catch (eAnchor) {}');
    lines.push('  var __baseX = comp.width / 2;');
    lines.push('  var __baseY = comp.height / 2 - __totalH / 2 + __li * __lineGap;');
    lines.push('  var __posProp = __txtLayer.property("Position");');
    lines.push('  var __opProp = __txtLayer.property("Opacity");');
    lines.push('  var __delay = 0.15 * __li;');
    lines.push('  __opProp.setValueAtTime(anchorTime + __delay, 0);');
    lines.push('  __opProp.setValueAtTime(anchorTime + __delay + 0.22, 100);');
    lines.push('  __posProp.setValueAtTime(anchorTime + __delay, [__baseX, __baseY + 34]);');
    lines.push('  __posProp.setValueAtTime(anchorTime + __delay + 0.3, [__baseX, __baseY]);');
    lines.push('  easyEaseAll(__posProp);');
    lines.push('  easyEaseAll(__opProp);');
    lines.push('}');
    return lines.join('\n');
}

// Same creation-only approach as buildMultiLineRevealJSX_AE, at word
// granularity instead of line granularity: each word becomes its own
// freshly-created text layer (no pre-authored file, no guessing at an
// existing layer's shape), measured with sourceRectAtTime() so the
// whole row can be centered and laid out left-to-right with even
// spacing, then punched in with a staggered scale+opacity keyframe.
function buildWordPopJSX_AE(words) {
    if (!words || !words.length) {
        return 'return "ERR:No text entered.";';
    }
    var wordsArr = '[' + words.map(jsxStringLiteral).join(', ') + ']';
    var lines = [];
    lines.push('var __words = ' + wordsArr + ';');
    lines.push('var __wordSpacing = 22;');
    lines.push('var __wordLayers = [];');
    lines.push('var __wordWidths = [];');
    lines.push('for (var __wi = 0; __wi < __words.length; __wi++) {');
    lines.push('  var __wLayer = comp.layers.addText(__words[__wi]);');
    lines.push('  try {');
    lines.push('    var __wtd = __wLayer.property("Source Text").value;');
    lines.push('    __wtd.fontSize = Math.max(28, Math.min(100, comp.width / 12));');
    lines.push('    __wtd.fillColor = [1, 1, 1];');
    lines.push('    __wLayer.property("Source Text").setValue(__wtd);');
    lines.push('  } catch (eFmt) {}');
    lines.push('  __wLayer.startTime = anchorTime;');
    lines.push('  var __wRect = __wLayer.sourceRectAtTime(anchorTime, false);');
    lines.push('  try {');
    lines.push('    __wLayer.property("Anchor Point").setValue([__wRect.left + __wRect.width / 2, __wRect.top + __wRect.height / 2]);');
    lines.push('  } catch (eAnchor) {}');
    lines.push('  __wordLayers.push(__wLayer);');
    lines.push('  __wordWidths.push(__wRect.width);');
    lines.push('}');
    lines.push('var __totalW = 0;');
    lines.push('for (var __wsum = 0; __wsum < __wordWidths.length; __wsum++) {');
    lines.push('  __totalW += __wordWidths[__wsum];');
    lines.push('  if (__wsum > 0) __totalW += __wordSpacing;');
    lines.push('}');
    lines.push('var __cursorX = comp.width / 2 - __totalW / 2;');
    lines.push('for (var __wj = 0; __wj < __wordLayers.length; __wj++) {');
    lines.push('  var __wl = __wordLayers[__wj];');
    lines.push('  var __wCenterX = __cursorX + __wordWidths[__wj] / 2;');
    lines.push('  var __wY = comp.height / 2;');
    lines.push('  __wl.property("Position").setValue([__wCenterX, __wY]);');
    lines.push('  var __scaleProp = __wl.property("Scale");');
    lines.push('  var __opProp = __wl.property("Opacity");');
    lines.push('  var __wDelay = 0.12 * __wj;');
    lines.push('  __scaleProp.setValueAtTime(anchorTime + __wDelay, [0, 0]);');
    lines.push('  __scaleProp.setValueAtTime(anchorTime + __wDelay + 0.18, [118, 118]);');
    lines.push('  __scaleProp.setValueAtTime(anchorTime + __wDelay + 0.28, [100, 100]);');
    lines.push('  __opProp.setValueAtTime(anchorTime + __wDelay, 0);');
    lines.push('  __opProp.setValueAtTime(anchorTime + __wDelay + 0.08, 100);');
    lines.push('  easyEaseAll(__scaleProp);');
    lines.push('  easyEaseAll(__opProp);');
    lines.push('  __cursorX += __wordWidths[__wj] + __wordSpacing;');
    lines.push('}');
    return lines.join('\n');
}

// One layer, left-justified, built with the FULL text first so its
// final centered position can be measured up front — then Source Text
// itself is keyframed with progressively longer substrings ("H", "He",
// "Hel", ...), a plain, well-documented way to fake a per-character
// typewriter reveal without AE's per-character Animator/Range Selector
// API (the one that caused real match-name errors in CreatorStash
// before real .ffx files fixed it). Left-justified + a position fixed
// to the FINAL text's width is what keeps the growing text anchored on
// its left edge instead of visibly re-centering every frame.
function buildTypewriterLineJSX_AE(fullText) {
    if (!fullText) {
        return 'return "ERR:No text entered.";';
    }
    var lines = [];
    lines.push('var __full = ' + jsxStringLiteral(fullText) + ';');
    lines.push('var __twLayer = comp.layers.addText(__full);');
    lines.push('try {');
    lines.push('  var __twStyle = __twLayer.property("Source Text").value;');
    lines.push('  __twStyle.fontSize = Math.max(24, Math.min(90, comp.width / 14));');
    lines.push('  __twStyle.fillColor = [1, 1, 1];');
    lines.push('  __twStyle.justification = ParagraphJustification.LEFT_JUSTIFY;');
    lines.push('  __twLayer.property("Source Text").setValue(__twStyle);');
    lines.push('} catch (eFmt) {}');
    lines.push('__twLayer.startTime = anchorTime;');
    lines.push('var __twRect = __twLayer.sourceRectAtTime(anchorTime, false);');
    lines.push('try {');
    lines.push('  __twLayer.property("Anchor Point").setValue([__twRect.left, __twRect.top + __twRect.height / 2]);');
    lines.push('} catch (eAnchor) {}');
    lines.push('__twLayer.property("Position").setValue([comp.width / 2 - __twRect.width / 2, comp.height / 2]);');
    lines.push('var __charDelay = Math.max(0.02, Math.min(0.09, 1.6 / Math.max(1, __full.length)));');
    lines.push('var __srcProp = __twLayer.property("Source Text");');
    lines.push('var __stepDoc = __srcProp.value;');
    lines.push('for (var __ci = 0; __ci <= __full.length; __ci++) {');
    lines.push('  __stepDoc.text = __full.substring(0, __ci);');
    lines.push('  __srcProp.setValueAtTime(anchorTime + __ci * __charDelay, __stepDoc);');
    lines.push('}');
    return lines.join('\n');
}

function buildAeBranch(item) {
    var lines = [];
    lines.push('var comp = app.project.activeItem;');
    lines.push('if (!comp || !(comp instanceof CompItem)) return "ERR:Open a composition first.";');
    lines.push('function easyEaseAll(prop) {');
    lines.push('  try {');
    lines.push('    var dim = (prop.value instanceof Array) ? prop.value.length : 1;');
    lines.push('    var easeArr = [];');
    lines.push('    for (var d = 0; d < dim; d++) easeArr.push(new KeyframeEase(0, 33));');
    lines.push('    for (var k = 1; k <= prop.numKeys; k++) prop.setTemporalEaseAtKey(k, easeArr, easeArr);');
    lines.push('  } catch (eEase) {}');
    lines.push('}');
    lines.push('var anchorTime = comp.time;');

    if (item.mechanism === "multiLineReveal") {
        lines.push(buildMultiLineRevealJSX_AE(item.lines || []));
    } else if (item.mechanism === "wordPop") {
        lines.push(buildWordPopJSX_AE(item.words || []));
    } else if (item.mechanism === "typewriterLine") {
        lines.push(buildTypewriterLineJSX_AE(item.text || ""));
    } else {
        lines.push('return "ERR:Unknown preset.";');
    }

    return lines.join("\n");
}

// Same always-close-the-undo-group shape used across Kreevo's CEP
// extensions: branch logic runs in its own inner function, so an early
// `return "ERR:...";` validation exit never skips app.endUndoGroup().
function buildApplyScript(item) {
    var aeBody = buildAeBranch(item);
    var script =
        '(function () {\n' +
        '  if (typeof app === "undefined" || !app.project) return "ERR:No active project.";\n' +
        '  app.beginUndoGroup(' + jsxStringLiteral("MotionType: Apply " + item.name) + ');\n' +
        '  var resultMsg;\n' +
        '  try {\n' +
        '    resultMsg = (function () {\n' +
        '      ' + aeBody.split("\n").join("\n      ") + '\n' +
        '      return "OK";\n' +
        '    })();\n' +
        '  } catch (eApply) {\n' +
        '    resultMsg = "ERR:" + eApply.toString();\n' +
        '  }\n' +
        '  app.endUndoGroup();\n' +
        '  return resultMsg;\n' +
        '})();';
    return script;
}

// ---------------------------------------------------------------
// Toast — brief status feedback, since there's no other feedback
// channel back from the host script. Error toasts persist until
// tapped, so there's time to screenshot the exact message.
// ---------------------------------------------------------------
var toastTimer = null;
function showToast(message, isError, durationMs, onTap) {
    var toast = document.getElementById("toast");
    if (!toast) return;
    toast.textContent = message + (isError ? "  (tap to dismiss)" : "");
    toast.classList.toggle("toast-error", !!isError);
    toast.classList.add("visible");
    toast.onclick = onTap || null;
    if (toastTimer) clearTimeout(toastTimer);
    if (isError) return;
    toastTimer = setTimeout(function () {
        toast.classList.remove("visible");
    }, durationMs || 2600);
}

(function () {
    var toastEl = document.getElementById("toast");
    if (toastEl) {
        toastEl.addEventListener("click", function () {
            toastEl.classList.remove("visible");
        });
    }
})();

function copyToClipboard(text) {
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text);
            return true;
        }
    } catch (e) {}
    try {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        var ok = document.execCommand("copy");
        document.body.removeChild(ta);
        return ok;
    } catch (e2) {
        return false;
    }
}

function applyPreset(item) {
    try {
        if (typeof CSInterface === "undefined") {
            showToast("Apply only works inside After Effects.", true);
            return;
        }
        var runtimeItem = item;
        if (item.mechanism === "multiLineReveal") {
            var raw = window.prompt("Enter up to 3 lines (separate with |):", "");
            if (raw === null) return; // cancelled
            var userLines = raw.split("|")
                .map(function (s) { return s.replace(/^\s+|\s+$/g, ""); })
                .filter(function (s) { return s.length > 0; })
                .slice(0, 3);
            if (!userLines.length) {
                showToast("Enter at least one line of text.", true);
                return;
            }
            runtimeItem = Object.assign({}, item, { lines: userLines });
        } else if (item.mechanism === "wordPop") {
            var rawWords = window.prompt("Enter your text (each word pops in one after another):", "");
            if (rawWords === null) return; // cancelled
            var userWords = rawWords.split(/\s+/)
                .map(function (s) { return s.replace(/^\s+|\s+$/g, ""); })
                .filter(function (s) { return s.length > 0; })
                .slice(0, 8);
            if (!userWords.length) {
                showToast("Enter at least one word.", true);
                return;
            }
            runtimeItem = Object.assign({}, item, { words: userWords });
        } else if (item.mechanism === "typewriterLine") {
            var rawText = window.prompt("Enter your text (types out letter by letter):", "");
            if (rawText === null) return; // cancelled
            var trimmedText = rawText.replace(/^\s+|\s+$/g, "").slice(0, 60);
            if (!trimmedText.length) {
                showToast("Enter some text.", true);
                return;
            }
            runtimeItem = Object.assign({}, item, { text: trimmedText });
        }
        var cs = new CSInterface();
        var script = buildApplyScript(runtimeItem);
        cs.evalScript(script, function (result) {
            if (!result || result.indexOf("ERR:") === 0) {
                showToast(result ? result.slice(4) : "Apply failed — unknown error.", true);
            } else {
                showToast("Applied “" + item.name + "” ✓", false);
            }
        });
    } catch (e) {
        showToast("Apply failed: " + e.message, true);
    }
}
