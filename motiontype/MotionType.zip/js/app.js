// MotionType by Kreevo — type-driven motion presets for After Effects.

var APP_VERSION = "1.3.0";

var CONFIG = {
    SUPPORT_EMAIL: "kreevoassets@gmail.com",
    UPDATE_CHECK_URL: "https://kreevo.github.io/motiontype/version.json",
    RELEASE_PAGE_URL: "https://kreevo.github.io/motiontype/MotionType.zip",
    // TODO: fill in once a separate Gumroad product exists for
    // MotionType (this is its OWN product, not CreatorStash's —
    // needs its own Gumroad ID/purchase link).
    GUMROAD_PRODUCT_ID: "",
    PURCHASE_URL: ""
};

// ---------------------------------------------------------------
// LICENSE — same proven Gumroad license-key pattern as CreatorStash
// and Crash Guard: verified once via Gumroad's public v2/licenses/
// verify endpoint, cached locally so every later panel open just reads
// it back.
// ---------------------------------------------------------------
var LICENSE_STORAGE_KEY = "motiontype_license";

function loadLicenseState() {
    try {
        var raw = localStorage.getItem(LICENSE_STORAGE_KEY);
        if (!raw) return { status: "free", key: "" };
        var obj = JSON.parse(raw);
        return (obj && obj.status === "licensed" && obj.key) ? obj : { status: "free", key: "" };
    } catch (e) {
        return { status: "free", key: "" };
    }
}

function saveLicenseState(status, key) {
    try {
        localStorage.setItem(LICENSE_STORAGE_KEY, JSON.stringify({ status: status, key: key || "" }));
    } catch (e) {}
}

var licenseState = loadLicenseState();
var LICENSE_STATUS = licenseState.status; // "free" | "licensed"

function verifyLicenseWithGumroad(key, callback) {
    var trimmedKey = String(key || "").replace(/^\s+|\s+$/g, "");
    if (!trimmedKey) { callback({ success: false, message: "Enter a license key first." }); return; }
    if (!CONFIG.GUMROAD_PRODUCT_ID) {
        callback({ success: false, message: "License verification isn't set up yet — contact support." });
        return;
    }
    var body = "product_id=" + encodeURIComponent(CONFIG.GUMROAD_PRODUCT_ID) +
        "&license_key=" + encodeURIComponent(trimmedKey) +
        "&increment_uses_count=true";
    fetch("https://api.gumroad.com/v2/licenses/verify", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: body
    })
        .then(function (res) { return res.json(); })
        .then(function (data) {
            if (data && data.success) {
                callback({ success: true });
            } else {
                callback({ success: false, message: (data && data.message) || "That license key isn't valid for MotionType." });
            }
        })
        .catch(function () {
            callback({ success: false, message: "Couldn't reach Gumroad — check your internet connection and try again." });
        });
}

// ---------------------------------------------------------------
// PRESETS — the only one that exists so far is "free": with just one
// feature in the whole product, gating it behind a purchase would
// leave nothing to actually try. Future additions can be tier:
// "premium" once there's more than one thing to compare against.
// ---------------------------------------------------------------
// Every tier below is "free" for now, on request, purely for testing
// the full set before deciding real pricing — see the tier comment
// further down for how to re-split these once that's decided.
var PRESETS = [
    {
        name: "Multi-Line Reveal",
        tier: "free",
        mechanism: "multiLineReveal",
        style: "bottom",
        preview: "cascade",
        desc: "Type up to 3 lines of text — each one slides up + fades in, staggered top to bottom."
    },
    {
        name: "Fade Stack",
        tier: "free",
        mechanism: "multiLineReveal",
        style: "fade",
        preview: "cascade",
        desc: "Type up to 3 lines — each one simply fades in, staggered, no motion. Subtle and minimal."
    },
    {
        name: "Slide Stack Sides",
        tier: "free",
        mechanism: "multiLineReveal",
        style: "sides",
        preview: "cascade",
        desc: "Type up to 3 lines — each one slides in from alternating left/right sides as it stacks."
    },
    {
        name: "Word Pop",
        tier: "free",
        mechanism: "wordPop",
        style: "pop",
        preview: "pop",
        desc: "Type a phrase — each word pops in one after another, auto-centered in a row. Great for punchy titles and callouts."
    },
    {
        name: "Word Slide Row",
        tier: "free",
        mechanism: "wordPop",
        style: "slide",
        preview: "pop",
        desc: "Type a phrase — each word slides up + fades in, one after another, auto-centered in a row."
    },
    {
        name: "Word Stack Pop",
        tier: "free",
        mechanism: "wordPop",
        style: "stack",
        preview: "pop",
        desc: "Type a phrase — each word pops in on its own line, stacked vertically instead of a row."
    },
    {
        name: "Typewriter Line",
        tier: "free",
        mechanism: "typewriterLine",
        centerMode: false,
        preview: "type",
        desc: "Type your text — it types itself out letter by letter, growing from a fixed left edge."
    },
    {
        name: "Typewriter Center",
        tier: "free",
        mechanism: "typewriterLine",
        centerMode: true,
        preview: "type",
        desc: "Same letter-by-letter typing, but the whole line stays centered as it grows instead of anchored left."
    },
    {
        name: "Slide In Left",
        tier: "free",
        mechanism: "singleBlock",
        style: "slideLeft",
        preview: "block",
        desc: "Type a phrase — it slides in from the left and settles centered."
    },
    {
        name: "Slide In Right",
        tier: "free",
        mechanism: "singleBlock",
        style: "slideRight",
        preview: "block",
        desc: "Type a phrase — it slides in from the right and settles centered."
    },
    {
        name: "Drop In Top",
        tier: "free",
        mechanism: "singleBlock",
        style: "dropTop",
        preview: "block",
        desc: "Type a phrase — it drops in from above and settles centered."
    },
    {
        name: "Pop In",
        tier: "free",
        mechanism: "singleBlock",
        style: "pop",
        preview: "block",
        desc: "Type a phrase — the whole line scale-punches in as one block."
    },
    {
        name: "Fade In",
        tier: "free",
        mechanism: "singleBlock",
        style: "fade",
        preview: "block",
        desc: "Type a phrase — it simply fades in, no motion. Clean and minimal."
    },
    {
        name: "Rotate In",
        tier: "free",
        mechanism: "singleBlock",
        style: "rotate",
        preview: "block",
        desc: "Type a phrase — it rotates in from an angle while fading and scaling up."
    },
    {
        name: "Bounce In",
        tier: "free",
        mechanism: "singleBlock",
        style: "bounce",
        preview: "block",
        desc: "Type a phrase — it scale-bounces in with an overshoot before settling."
    }
];

function isLocked(item) {
    return item.tier === "premium" && LICENSE_STATUS !== "licensed";
}

function showLockedToast(item) {
    var hasPurchaseUrl = !!CONFIG.PURCHASE_URL;
    var msg = "🔒 “" + item.name + "” is a Premium preset" +
        (hasPurchaseUrl ? " — tap to buy MotionType" : " — purchasing isn’t set up yet.") +
        "\nAlready bought it? Enter your license key under ⚙️ Settings.";
    showToast(msg, true, 0, hasPurchaseUrl ? function () { openExternal(CONFIG.PURCHASE_URL); } : null);
}

var presetListEl = document.getElementById("presetList");

function render() {
    presetListEl.innerHTML = "";
    for (var i = 0; i < PRESETS.length; i++) {
        // `let`, not `var`: `var` is function-scoped, not per-iteration —
        // every card's click handler below would end up sharing the SAME
        // `item` binding, all firing with whatever the LAST loop
        // iteration left it as (this exact bug already happened once in
        // CreatorStash's card grid). `let` gives each iteration its own
        // binding.
        let item = PRESETS[i];
        var locked = isLocked(item);
        var card = document.createElement("div");
        card.className = "preset-card";
        var previewHTML;
        if (item.preview === "pop") {
            previewHTML = '<div class="preset-anim"><div class="preset-anim-words">' +
                '<div class="preset-anim-chip"></div><div class="preset-anim-chip"></div><div class="preset-anim-chip"></div><div class="preset-anim-chip"></div>' +
                '</div></div>';
        } else if (item.preview === "type") {
            previewHTML = '<div class="preset-anim"><div class="preset-anim-type">' +
                '<span class="preset-anim-type-text"></span><span class="preset-anim-type-cursor"></span>' +
                '</div></div>';
        } else if (item.preview === "block") {
            previewHTML = '<div class="preset-anim"><div class="preset-anim-block preset-anim-block--' + item.style + '"></div></div>';
        } else {
            previewHTML = '<div class="preset-anim"><div class="preset-anim-line"></div><div class="preset-anim-line"></div><div class="preset-anim-line"></div></div>';
        }
        card.innerHTML =
            '<div class="preset-card-head">' +
                '<span class="preset-card-icon">' +
                    '<svg width="12" height="12" viewBox="0 0 16 16" fill="none">' +
                        '<path d="M2 4h12M2 8h8M2 12h10" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>' +
                    '</svg>' +
                '</span>' +
                '<span class="preset-card-name">' + item.name + '</span>' +
                (item.tier === "premium" ? '<span class="tier-tag">PRO</span>' : '') +
            '</div>' +
            '<p class="preset-card-desc">' + item.desc + '</p>' +
            previewHTML +
            '<button class="apply-btn' + (locked ? ' locked' : '') + '">Apply</button>';

        var applyBtn = card.querySelector(".apply-btn");
        applyBtn.addEventListener("click", function () {
            if (isLocked(item)) { showLockedToast(item); return; }
            applyPreset(item);
        });

        presetListEl.appendChild(card);
    }
}
render();

// ---------------------------------------------------------------
// LICENSE STATUS BADGE + SETTINGS MENU
// ---------------------------------------------------------------
var tierBadge = document.getElementById("tierBadge");
var buyLink = document.getElementById("buyLink");
var licenseSection = document.getElementById("licenseSection");
var licenseInput = document.getElementById("licenseInput");
var licenseActivateBtn = document.getElementById("licenseActivateBtn");
var licenseStatusMsg = document.getElementById("licenseStatusMsg");

function refreshLicenseUI() {
    if (LICENSE_STATUS === "licensed") {
        tierBadge.textContent = "Licensed";
        tierBadge.classList.add("licensed");
        buyLink.hidden = true;
        licenseSection.hidden = true;
    } else {
        tierBadge.textContent = "Free tier";
        tierBadge.classList.remove("licensed");
        buyLink.hidden = !CONFIG.PURCHASE_URL;
        licenseSection.hidden = false;
    }
}
refreshLicenseUI();

buyLink.addEventListener("click", function (e) {
    e.preventDefault();
    if (CONFIG.PURCHASE_URL) openExternal(CONFIG.PURCHASE_URL);
});

licenseActivateBtn.addEventListener("click", function () {
    var key = licenseInput.value;
    licenseActivateBtn.disabled = true;
    licenseStatusMsg.textContent = "Verifying with Gumroad…";
    licenseStatusMsg.className = "license-status-msg";
    verifyLicenseWithGumroad(key, function (result) {
        licenseActivateBtn.disabled = false;
        if (result.success) {
            LICENSE_STATUS = "licensed";
            saveLicenseState("licensed", key.replace(/^\s+|\s+$/g, ""));
            licenseStatusMsg.textContent = "Activated ✓";
            licenseStatusMsg.className = "license-status-msg ok";
            refreshLicenseUI();
            render();
        } else {
            licenseStatusMsg.textContent = result.message;
            licenseStatusMsg.className = "license-status-msg err";
        }
    });
});

var settingsBtn = document.getElementById("settingsBtn");
var settingsMenu = document.getElementById("settingsMenu");
var supportLink = document.getElementById("supportLink");

// mailto: links proved unreliable in real testing (crashed the CEP
// panel outright as a raw <a href>, and even routed through
// openURLInDefaultBrowser() just opened the OS default browser's home
// page instead of a mail client on a real Windows test). Copying the
// email to the clipboard is the one mechanism that's actually proven
// reliable — same fix already shipped in CreatorStash.
supportLink.addEventListener("click", function (e) {
    e.preventDefault();
    var copied = copyToClipboard(CONFIG.SUPPORT_EMAIL);
    showToast(
        copied ? "Support email copied: " + CONFIG.SUPPORT_EMAIL : CONFIG.SUPPORT_EMAIL,
        !copied,
        4200
    );
});

settingsBtn.addEventListener("click", function (e) {
    e.stopPropagation();
    settingsMenu.hidden = !settingsMenu.hidden;
});

document.addEventListener("click", function (e) {
    if (!settingsMenu.hidden && !settingsMenu.contains(e.target) && e.target !== settingsBtn) {
        settingsMenu.hidden = true;
    }
});

// ---------------------------------------------------------------
// AUTO-UPDATE — a single, quiet, one-time check on open.
// ---------------------------------------------------------------
function compareVersions(a, b) {
    var pa = String(a).split(".").map(Number);
    var pb = String(b).split(".").map(Number);
    var len = Math.max(pa.length, pb.length);
    for (var i = 0; i < len; i++) {
        var na = pa[i] || 0, nb = pb[i] || 0;
        if (na > nb) return 1;
        if (na < nb) return -1;
    }
    return 0;
}

function openExternal(url) {
    try {
        if (typeof CSInterface !== "undefined") {
            var cs = new CSInterface();
            cs.openURLInDefaultBrowser(url);
            return;
        }
    } catch (e) {}
    window.open(url, "_blank");
}

function showUpdateBanner(remote) {
    var banner = document.getElementById("updateBanner");
    var text = document.getElementById("updateText");
    var btn = document.getElementById("updateBtn");
    var dismiss = document.getElementById("updateDismiss");

    text.textContent = "Update available — v" + remote.version + (remote.notes ? ": " + remote.notes : "");
    banner.hidden = false;

    btn.onclick = function () {
        openExternal(remote.url || CONFIG.RELEASE_PAGE_URL);
    };
    dismiss.onclick = function () {
        banner.hidden = true;
    };
}

function checkForUpdate() {
    var url = CONFIG.UPDATE_CHECK_URL + (CONFIG.UPDATE_CHECK_URL.indexOf("?") === -1 ? "?" : "&") + "_=" + Date.now();
    fetch(url, { cache: "no-store" })
        .then(function (res) { return res.ok ? res.json() : null; })
        .then(function (remote) {
            if (!remote || !remote.version) return;
            if (compareVersions(remote.version, APP_VERSION) > 0) {
                showUpdateBanner(remote);
            }
        })
        .catch(function () { /* offline or repo not reachable yet — stay silent */ });
}

// Disabled for now — same reasoning as CreatorStash: only one real
// version exists so far, so there's nothing meaningful for an "update
// available" banner to announce yet. Call checkForUpdate() once there's
// an actual second release.
// checkForUpdate();
