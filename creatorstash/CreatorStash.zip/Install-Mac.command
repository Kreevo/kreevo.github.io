#!/bin/bash
# CreatorStash by Kreevo - installer (macOS)
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/CreatorStash"

echo ""
echo "  ==============================================="
echo "    CreatorStash by Kreevo - installer (macOS)"
echo "  ==============================================="
echo ""
echo "  Please close After Effects and Premiere Pro first."
read -r -p "  Press Enter to continue..."

if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
    echo ""
    echo "  ERROR: unzip CreatorStash.zip first, then run this file from the unzipped folder."
    read -r -p "  Press Enter to close..."
    exit 1
fi

if [ "$SRC" != "$DEST" ]; then
    echo "  Copying files to:"
    echo "  $DEST"
    rm -rf "$DEST"
    mkdir -p "$DEST"
    if ! cp -R "$SRC/." "$DEST/"; then
        echo ""
        echo "  ERROR: could not copy the files. Follow the manual steps in INSTALL.txt."
        read -r -p "  Press Enter to close..."
        exit 1
    fi
    xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
else
    echo "  Already installed in the right place."
fi

echo "  Enabling PlayerDebugMode..."
for v in 9 10 11 12; do
    defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1
done
killall cfprefsd 2>/dev/null

echo ""
echo "  Done! Open After Effects or Premiere Pro and go to:"
echo "  Window > Extensions > CreatorStash by Kreevo"
echo ""
read -r -p "  Press Enter to close..."
