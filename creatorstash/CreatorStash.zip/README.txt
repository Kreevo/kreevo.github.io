==========================================================
  CreatorStash by Kreevo
  SFX + text animation presets inside After Effects & Premiere Pro
==========================================================

Thanks for downloading CreatorStash!

----------------------------------------------------------
WHAT'S INSIDE
----------------------------------------------------------
  - 45 sound effects (whooshes, swipes, pops, clicks, impacts, risers...)
  - 21 text animation presets (Pop Up, Bounce In, Typewriter,
    Character Pop, Apple Text and more)
  - Search, preview, favorites
  - One click: the sound or preset goes straight into your project

  FREE tier: 2 sound effects (Whoosh In, UI Tap) + 1 text preset (Apple Text 1)
  PREMIUM:   everything unlocked with a license key

----------------------------------------------------------
REQUIREMENTS
----------------------------------------------------------
  - Adobe After Effects CC 2019 or newer
  - Adobe Premiere Pro CC 2019 or newer
  - Windows or macOS

----------------------------------------------------------
QUICK START
----------------------------------------------------------
  1. Install the panel. Easiest way:
        Windows: double-click  Install-Windows.bat
        macOS:   double-click  Install-Mac.command
     Step-by-step manual install: see INSTALL.txt
  2. Restart After Effects / Premiere Pro.
  3. Open:  Window > Extensions > CreatorStash by Kreevo

----------------------------------------------------------
HOW TO USE
----------------------------------------------------------
  SFX tab
    - Search a sound, hover a card, press PLAY to preview it.
    - Press the DOWNLOAD (green) button to add it:
        After Effects: lands as a layer at the playhead of the active comp
        Premiere Pro:  lands on an audio track of the active sequence

  Text tab
    - Select a text layer in your timeline.
    - Hover a preset and press the check button. Done.

  Star a card to add it to Favorites.

----------------------------------------------------------
UNLOCK PREMIUM
----------------------------------------------------------
  1. Buy premium:  https://kreevo.gumroad.com/l/CreatorStashPremium
  2. Copy the license key from your Gumroad receipt email.
  3. In the panel: Settings (top-right icon) > "Have a license key?"
     > paste the key > Activate.

----------------------------------------------------------
UPDATES
----------------------------------------------------------
  When a new version is out, the panel shows an "Update available"
  banner. Download the latest zip and install it the same way.
  Latest version: https://kreevo.github.io/creatorstash/CreatorStash.zip

----------------------------------------------------------
LICENSE
----------------------------------------------------------
  Use the sounds and presets in any personal or commercial project.
  No royalties. Please don't resell or re-share the files themselves.

----------------------------------------------------------
SUPPORT
----------------------------------------------------------
  Email: kreevoassets@gmail.com
  (or Settings > Support inside the panel)

Made by Kreevo  -  https://kreevo.github.io
