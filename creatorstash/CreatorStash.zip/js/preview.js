// ---------------------------------------------------------------
// CARD PREVIEWS
//
// Text presets: each card shows a real sample word that plays the
// preset's own animation spec on hover, using the very same curves
// as the After Effects expression selector in js/apply-engine.js
// (quart-out "smooth", damped "bounce", instant "hold", "punch"), so
// what you see on the card is what lands in your comp.
//
// SFX: the card's waveform is drawn from the actual audio file
// (decoded once with Web Audio, cached), and a playhead colours the
// bars while the preview plays. If decoding isn't possible the
// original placeholder bars simply stay.
// ---------------------------------------------------------------

var PREVIEW_PX = 0.3; // preview text is ~1/3 the size of typical comp text

function textPreviewSpec(item) {
    if (item.mechanism === "animator") return item;
    if (item.preview) return item.preview;
    if (item.mechanism === "karaoke") return { karaoke: true, unit: "letter", delay: 0.07, dur: 0.2 };
    return { unit: "letter", mode: "smooth", delay: 0.04, dur: 0.5, amount: 0, blur: 0, a: { op: true } };
}

function previewSample(spec) {
    if (spec.unit === "word") return "Make it move";
    if (spec.unit === "line") return "Big news";
    return "Motion";
}

// Same curves as csProgressExpr() in apply-engine.js; returns the
// selector amount (1 = fully "from" state, 0 = settled).
function previewSelector(mode, t, dur) {
    var p = Math.min(Math.max(t / Math.max(dur, 0.01), 0), 1);
    if (mode === "hold") return t >= 0 ? 0 : 1;
    if (mode === "punch") return (p > 0 && p < 1) ? Math.sin(Math.PI * p) : 0;
    if (mode === "bounce") return 1 - ((p >= 1) ? 1 : 1 - Math.exp(-6 * p) * Math.cos(12 * p));
    return 1 - (1 - Math.pow(1 - p, 4));
}

function buildPreviewText(el, spec) {
    var text = previewSample(spec);
    var parts = spec.unit === "letter" ? text.split("") : spec.unit === "word" ? text.split(/(\s+)/) : [text];
    el.innerHTML = "";
    var units = [];
    for (var i = 0; i < parts.length; i++) {
        var s = document.createElement("span");
        if (/^\s+$/.test(parts[i])) { s.innerHTML = "&nbsp;"; el.appendChild(s); continue; }
        s.textContent = parts[i];
        s.className = "pt-unit";
        el.appendChild(s);
        units.push(s);
    }
    el._units = units;
}

function stylePreviewUnit(s, spec, v) {
    var a = spec.a || {}, k = PREVIEW_PX;
    var tf = "";
    if (a.pos) tf += "translate(" + (a.pos[0] * (spec.amount || 0) * k * v).toFixed(2) + "px," + (a.pos[1] * (spec.amount || 0) * k * v).toFixed(2) + "px) ";
    if (a.scale !== undefined && a.scale !== null) {
        var sv = (a.scale instanceof Array) ? a.scale : [a.scale, a.scale];
        tf += "scale(" + (1 + (sv[0] / 100 - 1) * v).toFixed(4) + "," + (1 + (sv[1] / 100 - 1) * v).toFixed(4) + ") ";
    }
    if (a.rot) tf += "rotate(" + (a.rot * v).toFixed(2) + "deg)";
    s.style.transform = tf;
    s.style.opacity = a.op ? String(Math.min(1, Math.max(0, 1 - v))) : "";
    var b = (spec.blur || 0) * k * Math.max(0, v);
    s.style.filter = b > 0.05 ? "blur(" + b.toFixed(2) + "px)" : "";
}

function settlePreview(el) {
    var units = el._units || [];
    for (var i = 0; i < units.length; i++) {
        units[i].style.transform = ""; units[i].style.opacity = ""; units[i].style.filter = ""; units[i].style.color = "";
    }
}

function startTextPreview(el, item) {
    stopTextPreview(el);
    var spec = textPreviewSpec(item), units = el._units || [];
    var n = units.length, total = (spec.dur || 0.5) + Math.max(0, n - 1) * (spec.delay || 0), loop = total + 0.9;
    var t0 = performance.now();
    function frame(now) {
        var t = ((now - t0) / 1000) % loop;
        for (var i = 0; i < n; i++) {
            var ti = t - i * (spec.delay || 0);
            if (spec.karaoke) {
                units[i].style.color = ti >= 0 ? "var(--accent)" : "";
            } else {
                stylePreviewUnit(units[i], spec, previewSelector(spec.mode, ti, spec.dur));
            }
        }
        el._raf = requestAnimationFrame(frame);
    }
    el._raf = requestAnimationFrame(frame);
}

function stopTextPreview(el) {
    if (el._raf) cancelAnimationFrame(el._raf);
    el._raf = null;
    settlePreview(el);
}

function setupTextCardPreview(card, item) {
    var el = card.querySelector(".pt-text");
    if (!el) return;
    buildPreviewText(el, textPreviewSpec(item));
    card.addEventListener("mouseenter", function () { startTextPreview(el, item); });
    card.addEventListener("mouseleave", function () { stopTextPreview(el); });
}

// ---------------------------------------------------------------
// SFX waveform from the real file
// ---------------------------------------------------------------
var WAVE_BARS = 34;
var waveCache = {};
var waveCtx = null;

function loadWavePeaks(file, cb) {
    if (waveCache[file]) { cb(waveCache[file]); return; }
    try {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        if (!waveCtx) waveCtx = new AC();
        var xhr = new XMLHttpRequest();
        xhr.open("GET", file, true);
        xhr.responseType = "arraybuffer";
        xhr.onload = function () {
            if (!xhr.response) return;
            waveCtx.decodeAudioData(xhr.response, function (buf) {
                var ch = buf.getChannelData(0), n = ch.length, i, gmax = 0;
                for (i = 0; i < n; i += 8) { var av = Math.abs(ch[i]); if (av > gmax) gmax = av; }
                // trim leading/trailing silence so short hits fill the card
                var thr = gmax * 0.04, s0 = 0, s1 = n - 1;
                while (s0 < n - 1 && Math.abs(ch[s0]) < thr) s0++;
                while (s1 > s0 && Math.abs(ch[s1]) < thr) s1--;
                var len = Math.max(1, s1 - s0 + 1), step = Math.max(1, Math.floor(len / WAVE_BARS)), peaks = [], max = 0;
                for (var b = 0; b < WAVE_BARS; b++) {
                    var m = 0;
                    for (var j = s0 + b * step; j < Math.min(s1 + 1, s0 + (b + 1) * step); j += 2) { var v = Math.abs(ch[j]); if (v > m) m = v; }
                    peaks.push(m); if (m > max) max = m;
                }
                // perceptual (square-root) scaling so quieter tails stay visible
                for (var q = 0; q < peaks.length; q++) peaks[q] = Math.max(0.1, Math.sqrt(peaks[q] / (max || 1)));
                // where the drawn bars start/end inside the file (0..1), so the
                // playhead lines up with the trimmed waveform
                var res = { peaks: peaks, a: s0 / n, b: (s1 + 1) / n };
                waveCache[file] = res;
                cb(res);
            }, function () { /* undecodable: keep placeholder bars */ });
        };
        xhr.send();
    } catch (e) { /* keep placeholder bars */ }
}

function setupSfxCardPreview(card, item) {
    var wf = card.querySelector(".waveform");
    if (!wf || !item.file) return;
    loadWavePeaks(item.file, function (res) {
        var peaks = res.peaks, html = "";
        for (var i = 0; i < peaks.length; i++) html += '<span style="height:' + Math.round(peaks[i] * 100) + '%"></span>';
        wf.innerHTML = html;
        wf.classList.add("real");
        wf.setAttribute("data-a", res.a);
        wf.setAttribute("data-b", res.b);
    });
}

// Colours the bars up to the playhead while a preview plays.
function trackSfxProgress(audio, previewEl) {
    var wf = previewEl.querySelector(".waveform");
    if (!wf) return;
    function frame() {
        if (!audio || audio.paused || !previewEl.classList.contains("playing")) {
            var all = wf.querySelectorAll("span");
            for (var k = 0; k < all.length; k++) all[k].classList.remove("played");
            return;
        }
        var bars = wf.querySelectorAll("span"), f = audio.duration ? audio.currentTime / audio.duration : 0;
        var ra = parseFloat(wf.getAttribute("data-a")), rb = parseFloat(wf.getAttribute("data-b"));
        if (!isNaN(ra) && !isNaN(rb) && rb > ra) f = (f - ra) / (rb - ra);
        for (var i = 0; i < bars.length; i++) bars[i].classList.toggle("played", (i + 0.5) / bars.length <= f);
        requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
}
