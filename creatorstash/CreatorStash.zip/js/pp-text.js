// ---------------------------------------------------------------
// TEXT PRESETS IN PREMIERE PRO (CreatorStash 1.7)
//
// Premiere has no Text Animators, so here the panel draws the preset
// itself, frame by frame, on a canvas (the same curves as the card
// preview and the After Effects expression selector), saves a
// transparent PNG sequence next to the project and puts it at the
// playhead on a free video track. "Edit selected" loads a clip's
// text and look back from the small JSON saved beside its frames,
// and Add then replaces that clip in place.
// ---------------------------------------------------------------

var PPT = (function () {
    var STORE = "creatorstash_pp_text";
    var FONTS = [
        ["CS Montserrat|900", "Montserrat Black"], ["CS Montserrat|800", "Montserrat Bold"], ["CS Poppins|800", "Poppins"],
        ["CS Inter|800", "Inter"], ["CS Bebas|400", "Bebas Neue"], ["CS Oswald|700", "Oswald"],
        ["CS Playfair|700i", "Playfair Italic"], ["CS Marker|400", "Marker"], ["CS Caveat|700", "Caveat"]
    ];
    var SWATCH = ["#FFFFFF", "#FFD43B", "#D85A30", "#3DDC84", "#4DA3FF", "#111111"];
    var ST = { text: "Your text here", font: "CS Montserrat|900", custom: "", size: 9, color: "#FFFFFF", place: "mid", len: 3, shadow: true, stroke: false };
    try { var saved = JSON.parse(localStorage.getItem(STORE) || "null"); if (saved) for (var k in saved) ST[k] = saved[k]; } catch (e) {}
    function save() { try { localStorage.setItem(STORE, JSON.stringify(ST)); } catch (e) {} }
    var EDIT = null; // {node, track, start, name} of the clip being edited
    var SEQ = null;

    // ----------------------------------------------------------- render
    var RTL_RE = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/;
    function isMark(c) { return /[\u0300-\u036F\u0591-\u05C7\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u200C\u200D\uFE00-\uFE0F]/.test(c); }
    function clusters(line) {
        var out = [], i = 0;
        while (i < line.length) {
            var j = i + 1;
            if (/[\uD800-\uDBFF]/.test(line[i]) && j < line.length) j++;
            while (j < line.length && isMark(line[j])) j++;
            out.push({ i0: i, i1: j, s: line.slice(i, j) });
            i = j;
        }
        return out;
    }
    function specFor(item) {
        if (item.mechanism === "animator") return item;
        if (item.mechanism === "karaoke") return { karaoke: true, unit: "letter", delay: 0.07, dur: 0.2, a: {} };
        if (item.preview) return item.preview;
        return { unit: "letter", mode: "smooth", delay: 0.04, dur: 0.5, amount: 0, blur: 0, a: { op: true } };
    }
    // same curves as previewSelector() / the AE expression selector: 1 = start state, 0 = settled
    function sel(mode, t, dur) {
        var p = Math.min(Math.max(t / Math.max(dur, 0.01), 0), 1);
        if (mode === "hold") return t >= 0 ? 0 : 1;
        if (mode === "punch") return (p > 0 && p < 1) ? Math.sin(Math.PI * p) : 0;
        if (mode === "bounce") return 1 - ((p >= 1) ? 1 : 1 - Math.exp(-6 * p) * Math.cos(12 * p));
        return Math.pow(1 - p, 4);
    }
    function fontParts(st) {
        if (st.font === "__custom" && st.custom) return { fam: '"' + st.custom.replace(/"/g, "") + '"', w: "700", it: "" };
        var b = (st.font || FONTS[0][0]).split("|"), w = b[1] || "800";
        return { fam: '"' + b[0] + '"', w: w.replace("i", ""), it: /i$/.test(w) ? "italic " : "" };
    }
    function fontStr(st, px) { var f = fontParts(st); return f.it + f.w + " " + px.toFixed(1) + "px " + f.fam + ', "CS Montserrat", Arial, sans-serif'; }

    // lay out text into animated units: [{s, x (left), w, y (baseline-middle), i (stagger index)}]
    function layout(ctx, st, spec, W, H) {
        var px = H * st.size / 100, lines = String(st.text || " ").split(/\r?\n/), unit = spec.unit || "letter";
        ctx.font = fontStr(st, px);
        var maxW = 0; lines.forEach(function (l) { maxW = Math.max(maxW, ctx.measureText(l).width); });
        if (maxW > W * 0.9) { px *= (W * 0.9) / maxW; ctx.font = fontStr(st, px); maxW = 0; lines.forEach(function (l) { maxW = Math.max(maxW, ctx.measureText(l).width); }); }
        var lh = px * 1.18, Ht = lh * lines.length;
        var cy = st.place === "top" ? H * 0.2 : st.place === "low" ? H * 0.78 : H * 0.5;
        var y0 = cy - Ht / 2 + lh / 2, units = [], idx = 0;
        lines.forEach(function (line, li) {
            var w = ctx.measureText(line).width, x0 = W / 2 - w / 2, y = y0 + li * lh, rtl = RTL_RE.test(line);
            if (unit === "line" || !line.trim()) { if (line.trim()) units.push({ s: line, x: x0, w: w, y: y, i: idx++ }); return; }
            if (rtl || unit === "word") {
                // words keep their own shaping; right-to-left lines are placed from the right edge
                var parts = line.split(/(\s+)/), pos = 0, acc = [];
                parts.forEach(function (t) { if (!t) return; var tw = ctx.measureText(t).width; acc.push({ t: t, a: pos, b: pos + tw }); pos += tw; });
                var kx = pos > 0 ? w / pos : 1;
                acc.forEach(function (o) {
                    if (!o.t.trim()) return;
                    var x = rtl ? x0 + w - o.b * kx : x0 + o.a * kx;
                    units.push({ s: o.t, x: x, w: (o.b - o.a) * kx, y: y, i: idx++ });
                });
                return;
            }
            clusters(line).forEach(function (c) {
                if (!c.s.trim()) return;
                var a = ctx.measureText(line.slice(0, c.i0)).width, b = ctx.measureText(line.slice(0, c.i1)).width;
                units.push({ s: c.s, x: x0 + a, w: Math.max(1, b - a), y: y, i: idx++ });
            });
        });
        return { units: units, px: px, font: ctx.font };
    }
    function animLength(spec, n) { return (spec.dur || 0.5) + Math.max(0, n - 1) * (spec.delay || 0); }

    function drawFrame(ctx, W, H, st, item, t, lay) {
        var spec = specFor(item), a = spec.a || {};
        lay = lay || layout(ctx, st, spec, W, H);
        var k = lay.px / 100;              // AE amounts are in pixels for ~100 px text
        var hi = (st.color || "").toUpperCase() === "#FFD43B" ? "#D85A30" : "#FFD43B";
        ctx.save(); ctx.font = lay.font; ctx.textBaseline = "middle"; ctx.textAlign = "left";
        lay.units.forEach(function (u) {
            var ti = t - u.i * (spec.delay || 0), v = spec.karaoke ? 0 : sel(spec.mode, ti, spec.dur || 0.5);
            var op = a.op ? Math.min(1, Math.max(0, 1 - v)) : 1;
            if (op <= 0.001) return;
            ctx.save();
            ctx.translate(u.x + u.w / 2, u.y);
            if (a.pos) ctx.translate(a.pos[0] * (spec.amount || 0) * k * v, a.pos[1] * (spec.amount || 0) * k * v);
            if (a.rot) ctx.rotate(a.rot * v * Math.PI / 180);
            if (a.scale !== undefined && a.scale !== null) {
                var sv = (a.scale instanceof Array) ? a.scale : [a.scale, a.scale];
                ctx.scale(Math.max(0.0001, 1 + (sv[0] / 100 - 1) * v), Math.max(0.0001, 1 + (sv[1] / 100 - 1) * v));
            }
            ctx.globalAlpha = op;
            var b = (spec.blur || 0) * k * Math.max(0, v);
            if (b > 0.05) ctx.filter = "blur(" + b.toFixed(2) + "px)";
            if (st.shadow) { ctx.shadowColor = "rgba(0,0,0,0.55)"; ctx.shadowBlur = lay.px * 0.14; ctx.shadowOffsetY = lay.px * 0.05; }
            if (st.stroke) { ctx.lineJoin = "round"; ctx.lineWidth = Math.max(2, lay.px * 0.09); ctx.strokeStyle = "#000"; ctx.strokeText(u.s, -u.w / 2, 0); ctx.shadowColor = "transparent"; }
            ctx.fillStyle = spec.karaoke && ti >= 0 ? hi : (st.color || "#FFFFFF");
            ctx.fillText(u.s, -u.w / 2, 0);
            ctx.restore();
        });
        ctx.restore();
        return lay;
    }

    // ----------------------------------------------------------- host (ExtendScript, Premiere)
    // the ExtendScript side lives in host/csp.jsx; it is loaded with $.evalFile on every call
    var LIB = "";
    function libPath() {
        try {
            var d = decodeURI(new CSInterface().getSystemPath(SystemPath.EXTENSION)).replace(/\\/g, "/");
            d = d.replace(/^file:\/\/\/(?=[A-Za-z]:)/, "").replace(/^file:\/\//, "");
            return d + "/host/csp.jsx";
        } catch (e) { return ""; }
    }
    function host(call, cb) {
        if (typeof CSInterface === "undefined") { cb("err|Open this panel inside Premiere Pro."); return; }
        var p = libPath();
        new CSInterface().evalScript('$.evalFile(' + JSON.stringify(p) + ');' + call, function (r) { cb(r || "err|No answer from Premiere."); });
    }
    function nodeReq() { try { if (typeof cep_node !== "undefined" && cep_node.require) return cep_node.require; } catch (e) {} try { if (typeof require === "function") return require; } catch (e) {} return null; }
    function slug(s) { return String(s).replace(/[^A-Za-z0-9]+/g, "_").replace(/^_|_$/g, "") || "Text"; }
    function pad(n) { return ("00000" + n).slice(-5); }

    function renderFrames(item, onProgress) {
        var req = nodeReq(); if (!req) return Promise.reject(new Error("This needs Premiere Pro (Node.js is off)."));
        var fs = req("fs"), path = req("path"), Buf = req("buffer").Buffer;
        var W = SEQ.w, H = SEQ.h, fps = SEQ.fps || 30;
        var c = document.createElement("canvas"); c.width = W; c.height = H; var x = c.getContext("2d");
        var spec = specFor(item), lay = layout(x, ST, spec, W, H);
        var len = Math.max(ST.len, animLength(spec, lay.units.length) + 0.6), N = Math.max(1, Math.round(len * fps));
        var name = "CS_" + slug(item.name) + "_" + Date.now().toString(36), folder = path.join(SEQ.dir, name);
        try { fs.mkdirSync(folder, { recursive: true }); } catch (e) { return Promise.reject(new Error("Can't write to " + folder)); }
        var i = 0;
        return new Promise(function (res, rej) {
            function next() {
                if (i >= N) {
                    try { fs.writeFileSync(path.join(folder, "creatorstash-text.json"), JSON.stringify({ v: 1, preset: item.name, st: ST })); } catch (e) {}
                    res({ first: path.join(folder, name + "_" + pad(0) + ".png"), frames: N, fps: fps, name: item.name }); return;
                }
                x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, W, H);
                drawFrame(x, W, H, ST, item, i / fps, lay);
                var b64 = c.toDataURL("image/png").split(",")[1];
                fs.writeFile(path.join(folder, name + "_" + pad(i) + ".png"), Buf.from(b64, "base64"), function (err) {
                    if (err) { rej(new Error("Can't write frames: " + err.message)); return; }
                    i++; if (onProgress) onProgress(i / N); setTimeout(next, 0);
                });
            }
            next();
        });
    }

    // ----------------------------------------------------------- UI
    var box = null, busy = false;
    function $(id) { return document.getElementById(id); }
    function build(container) {
        box = document.createElement("div"); box.className = "pp-text"; box.id = "ppText"; box.hidden = true;
        var fontOpts = FONTS.map(function (f) { return '<option value="' + f[0] + '">' + f[1] + '</option>'; }).join("") + '<option value="__custom">Installed font…</option>';
        box.innerHTML =
            '<div class="pp-edit" id="ppEdit" hidden><span id="ppEditInfo">Editing</span><span style="flex:1"></span><button class="pp-link" id="ppEditCancel">Cancel</button></div>' +
            '<div class="pp-row"><b style="font-size:12px">Text for Premiere</b><span style="flex:1"></span><button class="pp-link" id="ppFold">Hide settings</button></div>' +
            '<textarea id="ppTxt" spellcheck="false" placeholder="Type your text"></textarea>' +
            '<div id="ppBody" style="display:flex;flex-direction:column;gap:8px">' +
            '<div class="pp-pv"><canvas id="ppPv"></canvas><span class="pp-pv-name" id="ppPvName"></span></div>' +
            '<div class="pp-row"><span class="pp-lbl">Font</span><select id="ppFont">' + fontOpts + '</select><input type="text" id="ppCustom" placeholder="Font name, e.g. Arial" hidden></div>' +
            '<div class="pp-row"><span class="pp-lbl">Size</span><input type="range" id="ppSize" min="3" max="22" step="0.5"><span class="pp-val" id="ppSizeV"></span></div>' +
            '<div class="pp-row"><span class="pp-lbl">Color</span><span id="ppSw"></span><input type="color" id="ppColor" title="Any colour"></div>' +
            '<div class="pp-row"><span class="pp-lbl">Place</span><span class="pp-seg" id="ppPlace"><button data-v="top">Top</button><button data-v="mid">Middle</button><button data-v="low">Bottom</button></span>' +
            '<label class="pp-check"><input type="checkbox" id="ppShadow"> Shadow</label><label class="pp-check"><input type="checkbox" id="ppStroke"> Outline</label></div>' +
            '<div class="pp-row"><span class="pp-lbl">Length</span><input type="range" id="ppLen" min="1" max="10" step="0.5"><span class="pp-val" id="ppLenV"></span></div>' +
            '</div>' +
            '<div class="pp-row"><span class="pp-hint" style="flex:1">Press <b>✓</b> on a preset to add it at the playhead.</span><button class="pp-btn" id="ppEditBtn" title="Change the text of a CreatorStash clip you already added">Edit selected</button></div>' +
            '<div class="pp-prog" id="ppProg" hidden><i></i></div>';
        container.parentNode.insertBefore(box, container);
        function fold() { $("ppBody").style.display = ST.folded ? "none" : "flex"; $("ppFold").textContent = ST.folded ? "Show settings" : "Hide settings"; }
        $("ppFold").onclick = function () { ST.folded = !ST.folded; save(); fold(); }; fold();
        $("ppTxt").value = ST.text;
        $("ppTxt").oninput = function () { ST.text = this.value; save(); };
        $("ppFont").value = FONTS.some(function (f) { return f[0] === ST.font; }) || ST.font === "__custom" ? ST.font : FONTS[0][0];
        $("ppCustom").hidden = $("ppFont").value !== "__custom"; $("ppCustom").value = ST.custom || "";
        $("ppFont").onchange = function () { ST.font = this.value; $("ppCustom").hidden = this.value !== "__custom"; save(); };
        $("ppCustom").oninput = function () { ST.custom = this.value; save(); };
        function rng(id, key, fmt) { var r = $(id); r.value = ST[key]; var v = $(id + "V"); var upd = function () { ST[key] = parseFloat(r.value); v.textContent = fmt(ST[key]); save(); }; r.oninput = upd; v.textContent = fmt(ST[key]); }
        rng("ppSize", "size", function (n) { return n + "%"; });
        rng("ppLen", "len", function (n) { return n + " s"; });
        var sw = $("ppSw"); sw.style.display = "inline-flex"; sw.style.gap = "6px";
        SWATCH.forEach(function (c) { var d = document.createElement("span"); d.className = "pp-sw"; d.style.background = c; d.dataset.c = c; d.onclick = function () { setColor(c); }; sw.appendChild(d); });
        $("ppColor").oninput = function () { setColor(this.value.toUpperCase()); };
        function setColor(c) { ST.color = c; save(); markColor(); }
        function markColor() { [].forEach.call(sw.children, function (d) { d.classList.toggle("on", d.dataset.c.toUpperCase() === String(ST.color).toUpperCase()); }); $("ppColor").value = ST.color; }
        markColor();
        [].forEach.call($("ppPlace").children, function (b) { b.onclick = function () { ST.place = b.dataset.v; save(); markPlace(); }; });
        function markPlace() { [].forEach.call($("ppPlace").children, function (b) { b.classList.toggle("on", b.dataset.v === ST.place); }); }
        markPlace();
        $("ppShadow").checked = !!ST.shadow; $("ppShadow").onchange = function () { ST.shadow = this.checked; save(); };
        $("ppStroke").checked = !!ST.stroke; $("ppStroke").onchange = function () { ST.stroke = this.checked; save(); };
        $("ppEditBtn").onclick = editSelected;
        $("ppEditCancel").onclick = function () { setEdit(null); };
        startPreview();
        PPT._refresh = function () { $("ppTxt").value = ST.text; $("ppFont").value = ST.font; $("ppCustom").hidden = ST.font !== "__custom"; $("ppCustom").value = ST.custom || "";
            $("ppSize").value = ST.size; $("ppSize").oninput(); $("ppLen").value = ST.len; $("ppLen").oninput(); markColor(); markPlace(); $("ppShadow").checked = !!ST.shadow; $("ppStroke").checked = !!ST.stroke; };
    }
    function setEdit(e) {
        EDIT = e; $("ppEdit").hidden = !e;
        if (e) $("ppEditInfo").textContent = "Editing " + e.preset + (e.trackName ? " on " + e.trackName : "") + " — pick a preset to update it";
    }
    function editSelected() {
        host("csp_selected()", function (r) {
            var b = r.split("|");
            if (b[0] !== "ok") { showToast(b.slice(1).join("|") || "Select a CreatorStash text clip first.", true); return; }
            var info; try { info = JSON.parse(b.slice(1).join("|")); } catch (e) { showToast("Could not read the selected clip.", true); return; }
            var conf = null, req = nodeReq();
            try { var fs = req("fs"), path = req("path"); conf = JSON.parse(fs.readFileSync(path.join(path.dirname(info.path), "creatorstash-text.json"), "utf8")); } catch (e) {}
            if (!conf || !conf.st) { showToast("This clip wasn't made with CreatorStash (or its folder was moved).", true); return; }
            for (var k in conf.st) ST[k] = conf.st[k];
            save(); PPT._refresh(); info.preset = conf.preset; setEdit(info);
            showToast("Change the text or look, then press + on a preset");
        });
    }
    function add(item) {
        if (busy) return;
        if (!String(ST.text || "").trim()) { showToast("Type your text first.", true); $("ppTxt").focus(); return; }
        busy = true; setPreview(item); var prog = $("ppProg"), bar = prog.firstChild;
        host("csp_info()", function (r) {
            if (r.indexOf("ok|") !== 0) { busy = false; showToast(r.split("|").slice(1).join("|") || r, true); return; }
            try { var d = JSON.parse(r.slice(3)); SEQ = { w: d.w, h: d.h, fps: d.fps, dir: d.dir }; } catch (e) { busy = false; showToast("Could not read the sequence.", true); return; }
            prog.hidden = false; bar.style.width = "0%";
            showToast("Rendering " + item.name + "…", false, 60000);
            var t0 = Date.now();
            (document.fonts && document.fonts.load ? document.fonts.load(fontStr(ST, 40), ST.text) : Promise.resolve()).catch(function () {}).then(function () {
                return renderFrames(item, function (p) { bar.style.width = Math.round(p * 100) + "%"; });
            }).then(function (out) {
                var o = { file: out.first, fps: out.fps, frames: out.frames, name: out.name };
                if (EDIT) o.node = EDIT.node;
                host((EDIT ? "csp_replace(" : "csp_place(") + JSON.stringify(o) + ")", function (r2) {
                    busy = false; prog.hidden = true;
                    var b = r2.split("|"), secs = Math.round((Date.now() - t0) / 100) / 10;
                    if (b[0] === "ok") {
                        if (EDIT) { if (b[2]) EDIT.node = b[2]; showToast(out.name + " updated ✓ (" + secs + " s)"); }
                        else showToast(out.name + " added on " + b[1] + " ✓  Press Space to play");
                    } else showToast(b.slice(1).join("|") || r2, true);
                });
            }, function (e) { busy = false; prog.hidden = true; showToast(e.message, true); });
        });
    }
    // ----------------------------------------------------------- live preview
    // Shows YOUR text with the chosen font, size, colour and place, playing the
    // preset under the mouse (or the last one added). Same drawFrame() as the
    // frames that go to the timeline, so what you see is what you get.
    var PV = { item: null, t0: 0, ar: 16 / 9 };
    function firstPreset() { try { return DATA.text[0]; } catch (e) { return { name: "Pop Up", mechanism: "animator", unit: "letter", mode: "bounce", delay: 0.035, dur: 0.5, a: { scale: 0, op: true } }; } }
    function setPreview(item) { if (!item || item === PV.item) return; PV.item = item; PV.t0 = performance.now(); var n = $("ppPvName"); if (n) n.textContent = item.name; }
    function readAspect() {
        host("csp_info()", function (r) {
            if (r.indexOf("ok|") !== 0) return;
            try { var d = JSON.parse(r.slice(3)); if (d.w > 0 && d.h > 0) PV.ar = d.w / d.h; } catch (e) {}
        });
    }
    function startPreview() {
        setPreview(firstPreset());
        readAspect(); window.addEventListener("focus", readAspect);
        var cv = $("ppPv"), x = cv.getContext("2d");
        function frame(now) {
            requestAnimationFrame(frame);
            if (!box || box.hidden || ST.folded || !PV.item) return;
            var dpr = window.devicePixelRatio || 1, maxW = cv.parentNode.clientWidth, maxH = 190;
            var w = Math.min(maxW, maxH * PV.ar), h = w / PV.ar;
            if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
                cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); cv.style.width = w + "px"; cv.style.height = h + "px";
            }
            var W = cv.width, H = cv.height, spec = specFor(PV.item);
            x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, W, H);
            var lay = layout(x, ST, spec, W, H), loop = animLength(spec, lay.units.length) + 1.4;
            drawFrame(x, W, H, ST, PV.item, ((now - PV.t0) / 1000) % loop, lay);
        }
        requestAnimationFrame(frame);
    }

    function onTab(tab) { if (box) box.hidden = tab !== "text"; }
    return { build: build, add: add, onTab: onTab, setPreview: setPreview, drawFrame: drawFrame, layout: layout, specFor: specFor, state: ST, _host: host, _lib: LIB };
})();
