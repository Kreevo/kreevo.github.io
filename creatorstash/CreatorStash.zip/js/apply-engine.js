// ---------------------------------------------------------------
// APPLY ENGINE — Text and Transitions presets have no pre-rendered
// file behind them (there's no such thing as a buildable .ffx/.mogrt
// without a live host session to render through). Instead each preset
// is a declarative animation spec (see DATA.text / DATA.transitions
// in app.js) that this file turns into ExtendScript and runs against
// whatever's selected in the host, via CSInterface.evalScript.
//
// Two hosts, two very different scripting object models:
//   - After Effects: layer.property("Position"/"Scale"/"Rotation"/
//     "Opacity"), keyframed with setValueAtTime(seconds, value).
//     Text presets can also use the per-character Animator API.
//   - Premiere Pro: every clip already carries built-in "Motion" and
//     "Opacity" components; their properties are keyframed through
//     ComponentParam.setTimeVarying(true) + addKey()/setValueAtKey(Time,
//     value) instead — confirmed against a real, shipping Premiere CEP
//     extension's host script (matching by displayName/matchName with
//     substring fallback, real Time objects rather than raw tick
//     strings, and setTimeVarying() as a required first step this file
//     was missing entirely before). Premiere has no per-property
//     expressions and no per-character text animator API, so the 5
//     text-animator presets (Typewriter, Karaoke Highlight, Letter
//     Cascade, Character Pop, Flip In) stay After-Effects-only and
//     return a clear message on Premiere rather than silently doing
//     nothing.
// The generated script detects the host at runtime (app.appName) and
// branches accordingly, all wrapped in one undo group so a bad apply
// is always a single Ctrl/Cmd+Z.
// ---------------------------------------------------------------

var AE_ONLY_MECHANISMS = ["typewriter", "karaoke", "letterCascade", "characterPop", "flip3d", "ffxPreset"];

function getExtensionRootPath() {
    try {
        if (typeof CSInterface !== "undefined" && typeof SystemPath !== "undefined") {
            var cs = new CSInterface();
            return cs.getSystemPath(SystemPath.EXTENSION);
        }
    } catch (e) {}
    return "";
}

function jsxStringLiteral(str) {
    return '"' + String(str).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
}

function getAssetFullPath(relativePath) {
    var extRoot = getExtensionRootPath();
    if (!extRoot || !relativePath) return "";
    var normalizedRoot = extRoot.replace(/\\/g, "/").replace(/\/+$/, "");
    return normalizedRoot + "/" + relativePath;
}

// =================================================================
// AFTER EFFECTS builders
// =================================================================

// Keyframes one transform property (Position/Scale/Rotation/Opacity)
// on `layer`, relative to that property's value at apply-time — so a
// preset always animates FROM/TO the layer's actual current position/
// scale/rotation instead of assuming it starts at [0,0] or 100%.
function buildPropKeyframeJSX_AE(spec, index) {
    var prop = spec.prop;
    var varName = "p" + index;
    var origVar = varName + "Orig";
    var lines = [];
    lines.push('var ' + varName + ' = layer.property("' + prop + '");');
    lines.push('if (' + varName + ') {');
    lines.push('  var ' + origVar + ' = ' + varName + '.value;');
    for (var i = 0; i < spec.keys.length; i++) {
        var k = spec.keys[i];
        var valExpr;
        if (prop === "Position") {
            // 3D layers carry a [x,y,z] Position (and Scale, below) —
            // dropping the 3rd value here throws a dimension-mismatch
            // error in AE and aborts the whole apply, so preserve it
            // when present instead of assuming every layer is 2D.
            valExpr = '(' + origVar + '.length === 3 ? [' + origVar + '[0] + (' + k.v[0] + '), ' + origVar + '[1] + (' + k.v[1] + '), ' + origVar + '[2]] : [' + origVar + '[0] + (' + k.v[0] + '), ' + origVar + '[1] + (' + k.v[1] + ')])';
        } else if (prop === "Scale") {
            valExpr = '(' + origVar + '.length === 3 ? [' + origVar + '[0] * (' + k.v[0] + ') / 100, ' + origVar + '[1] * (' + k.v[1] + ') / 100, ' + origVar + '[2]] : [' + origVar + '[0] * (' + k.v[0] + ') / 100, ' + origVar + '[1] * (' + k.v[1] + ') / 100])';
        } else if (prop === "Rotation") {
            valExpr = '(' + origVar + ' + (' + k.v + '))';
        } else { // Opacity, or any other plain single-value property
            valExpr = String(k.v);
        }
        lines.push('  ' + varName + '.setValueAtTime(anchorTime + ' + k.t + ', ' + valExpr + ');');
    }
    lines.push('  easyEaseAll(' + varName + ');');
    lines.push('}');
    return lines.join("\n");
}

// Effects (Fast Box Blur, Directional Blur, ...) added fresh, so their
// keyframe values are absolute — no "orig" offset needed, they start
// at the effect's own default.
function buildEffectKeyframeJSX_AE(effectSpec, index) {
    var varName = "fx" + index;
    var propVar = varName + "Prop";
    var lines = [];
    lines.push('try {');
    lines.push('  var ' + varName + ' = layer.property("Effects").addProperty(' + jsxStringLiteral(effectSpec.name) + ');');
    lines.push('  var ' + propVar + ' = ' + varName + '.property(' + jsxStringLiteral(effectSpec.prop) + ');');
    for (var i = 0; i < effectSpec.keys.length; i++) {
        var k = effectSpec.keys[i];
        lines.push('  ' + propVar + '.setValueAtTime(anchorTime + ' + k.t + ', ' + k.v + ');');
    }
    lines.push('  easyEaseAll(' + propVar + ');');
    lines.push('} catch (eFx) { /* effect not available on this AE version — skip, keyframes above still apply */ }');
    return lines.join("\n");
}

// A short camera-shake wiggle on Position for the first ~0.25s after
// anchorTime, tapering back to the layer's plain (already-keyframed)
// position. Expressions run every frame the layer is visible, so this
// is written to only be "live" inside that short window and otherwise
// defer to the property's own keyframed value.
function buildShakeExpressionJSX_AE() {
    return (
        'try {\n' +
        '  var posProp = layer.property("Position");\n' +
        '  if (posProp) {\n' +
        '    posProp.expression =\n' +
        '      "var relT = time - " + anchorTime + ";\\n" +\n' +
        '      "relT >= 0 && relT < 0.25 ? value + wiggle(14, 18 * (1 - relT/0.25)) : value;";\n' +
        '  }\n' +
        '} catch (eShake) { /* expression is a bonus flourish — skip if the host rejects it */ }\n'
    );
}

// Text-animator mechanisms — AE's per-character Animator API. A real
// test in AE came back with:
//   "Can not add a property with name 'Animator' to this PropertyGroup"
// — addProperty() on the Animators/Properties/Selectors groups needs
// AE's internal match-name strings ("ADBE Text Animator" etc.), not the
// human-readable menu labels ("Animator") the earlier version used.
// addPropertyTry() below tries the match name first and falls back to
// the plain label if that ever fails on some AE version — belt and
// suspenders now that one of these has already been proven wrong once.
// (.property("Properties")/.property("Selectors")/.property("Start")
// etc. are plain navigation into groups that already exist, not
// creation, so those keep their original names — only the addProperty
// calls needed this fix.)

// Chains addProperty attempts through a list of candidate names, each
// one only tried if the previous one threw — first confirmed failure
// ("Animator" alone wasn't enough) showed candidates need to go deeper
// than a single match-name/display-name pair for some properties (e.g.
// per-character Scale apparently isn't "ADBE Text Scale" OR "Scale" —
// likely needs the " 3D" suffix AE uses internally for animator
// transform properties), so this takes as many candidates as needed
// and lets the LAST one's error surface if every candidate fails.
function addPropertyTryJSX(groupExpr, resultVar, candidates) {
    var assign = function (name) {
        return resultVar + ' = ' + groupExpr + '.addProperty(' + jsxStringLiteral(name) + ');';
    };
    // Build from the innermost (last) candidate outward: the last one is
    // bare (its error, if any, is the one that surfaces), each earlier
    // one wraps the next attempt in its catch block.
    var body = assign(candidates[candidates.length - 1]);
    for (var i = candidates.length - 2; i >= 0; i--) {
        body = 'try { ' + assign(candidates[i]) + ' } catch (e' + resultVar + i + ') { ' + body + ' }';
    }
    return 'var ' + resultVar + ';\n' + body + '\n';
}

function buildTypewriterJSX_AE() {
    return (
        'if (!layer.property("Source Text")) return "ERR:Select a text layer.";\n' +
        'var textProp = layer.property("Source Text");\n' +
        'var charCount = textProp.value.text.length;\n' +
        'var dur = Math.max(0.4, Math.min(2.5, charCount * 0.05));\n' +
        addPropertyTryJSX('layer.property("Text").property("Animators")', 'animator', ['ADBE Text Animator', 'Animator']) +
        'animator.name = "Typewriter";\n' +
        addPropertyTryJSX('animator.property("Properties")', 'opacityProp', ['ADBE Text Opacity', 'Opacity']) +
        'opacityProp.setValue(0);\n' +
        addPropertyTryJSX('animator.property("Selectors")', 'selector', ['ADBE Text Selector', 'Range Selector']) +
        'var startProp = selector.property("Start");\n' +
        'startProp.setValueAtTime(anchorTime, 0);\n' +
        'startProp.setValueAtTime(anchorTime + dur, 100);\n' +
        'easyEaseAll(startProp);\n'
    );
}

function buildKaraokeJSX_AE() {
    return (
        'if (!layer.property("Source Text")) return "ERR:Select a text layer.";\n' +
        'var textProp = layer.property("Source Text");\n' +
        'var charCount = textProp.value.text.length;\n' +
        'var dur = Math.max(0.5, Math.min(3, charCount * 0.06));\n' +
        addPropertyTryJSX('layer.property("Text").property("Animators")', 'animator', ['ADBE Text Animator', 'Animator']) +
        'animator.name = "Karaoke Highlight";\n' +
        addPropertyTryJSX('animator.property("Properties")', 'fillProp', ['ADBE Text Fill Color', 'Fill Color']) +
        'fillProp.setValue([0.847, 0.353, 0.188]);\n' + // brand accent #D85A30
        addPropertyTryJSX('animator.property("Selectors")', 'selector', ['ADBE Text Selector', 'Range Selector']) +
        'var endProp = selector.property("End");\n' +
        'endProp.setValueAtTime(anchorTime, 0);\n' +
        'endProp.setValueAtTime(anchorTime + dur, 100);\n' +
        'easyEaseAll(endProp);\n'
    );
}

function buildLetterCascadeJSX_AE() {
    return (
        'if (!layer.property("Source Text")) return "ERR:Select a text layer.";\n' +
        'var textProp = layer.property("Source Text");\n' +
        'var charCount = textProp.value.text.length;\n' +
        'var dur = Math.max(0.6, Math.min(2.5, charCount * 0.045));\n' +
        addPropertyTryJSX('layer.property("Text").property("Animators")', 'animator', ['ADBE Text Animator', 'Animator']) +
        'animator.name = "Letter Cascade";\n' +
        addPropertyTryJSX('animator.property("Properties")', 'opacityProp', ['ADBE Text Opacity', 'Opacity']) +
        'opacityProp.setValue(0);\n' +
        addPropertyTryJSX('animator.property("Selectors")', 'selector', ['ADBE Text Selector', 'Range Selector']) +
        'try {\n' +
        '  selector.property("Advanced").property("Ease High").setValue(75);\n' +
        '} catch (eEase2) { /* older AE versions nest Advanced differently — cascade still works without it */ }\n' +
        'var startProp = selector.property("Start");\n' +
        'startProp.setValueAtTime(anchorTime, 0);\n' +
        'startProp.setValueAtTime(anchorTime + dur, 100);\n' +
        'easyEaseAll(startProp);\n'
    );
}

function buildCharacterPopJSX_AE() {
    return (
        'if (!layer.property("Source Text")) return "ERR:Select a text layer.";\n' +
        'var textProp = layer.property("Source Text");\n' +
        'var charCount = textProp.value.text.length;\n' +
        'var dur = Math.max(0.6, Math.min(2.5, charCount * 0.05));\n' +
        addPropertyTryJSX('layer.property("Text").property("Animators")', 'animator', ['ADBE Text Animator', 'Animator']) +
        'animator.name = "Character Pop";\n' +
        addPropertyTryJSX('animator.property("Properties")', 'scaleProp', ['ADBE Text Scale 3D', 'ADBE Text Scale', 'Scale']) +
        'scaleProp.setValue([140, 140]);\n' +
        addPropertyTryJSX('animator.property("Properties")', 'opacityProp', ['ADBE Text Opacity', 'Opacity']) +
        'opacityProp.setValue(0);\n' +
        addPropertyTryJSX('animator.property("Selectors")', 'selector', ['ADBE Text Selector', 'Range Selector']) +
        'try { selector.property("Advanced").property("Smoothness").setValue(35); } catch (eSm) {}\n' +
        'var startProp = selector.property("Start");\n' +
        'startProp.setValueAtTime(anchorTime, 0);\n' +
        'startProp.setValueAtTime(anchorTime + dur, 100);\n' +
        'easyEaseAll(startProp);\n'
    );
}

function buildFlip3dJSX_AE() {
    return (
        'if (!layer.property("Source Text")) return "ERR:Select a text layer.";\n' +
        'layer.threeDLayer = true;\n' +
        'var yRotProp = layer.property("Y Rotation");\n' +
        'var opacityProp = layer.property("Opacity");\n' +
        'var origOpacity = opacityProp.value;\n' +
        'yRotProp.setValueAtTime(anchorTime, -100);\n' +
        'yRotProp.setValueAtTime(anchorTime + 0.32, 0);\n' +
        'opacityProp.setValueAtTime(anchorTime, 0);\n' +
        'opacityProp.setValueAtTime(anchorTime + 0.1, origOpacity);\n' +
        'easyEaseAll(yRotProp);\n' +
        'easyEaseAll(opacityProp);\n'
    );
}

// A shipped, real .ffx animation preset (created inside actual After
// Effects, not reconstructed from guessed property names) applied via
// AVLayer.applyPreset() — a plain, well-documented AE scripting call
// that hands the whole job to AE's own preset-loading code. This is
// categorically more reliable than rebuilding a text animator's
// property tree by hand: no match-name guessing at all, since AE reads
// the file itself. Keep using this path for any preset a real .ffx
// exists for.
function buildFfxApplyJSX_AE(ffxRelativePath) {
    var fullPath = getAssetFullPath(ffxRelativePath);
    if (!fullPath) return 'return "ERR:Could not resolve the preset file path.";';
    return (
        'var presetFile = new File(' + jsxStringLiteral(fullPath) + ');\n' +
        'if (!presetFile.exists) return "ERR:Preset file not found: ' + fullPath.replace(/'/g, "") + '";\n' +
        'layer.applyPreset(presetFile);\n'
    );
}

function buildAeBranch(item) {
    var lines = [];
    lines.push('var comp = app.project.activeItem;');
    lines.push('if (!comp || !(comp instanceof CompItem)) return "ERR:Open a composition first.";');
    lines.push('function easyEaseAll(prop) {');
    lines.push('  try {');
    lines.push('    var dim = (prop.value instanceof Array) ? prop.value.length : 1;');
    lines.push('    var easeArr = [];');
    lines.push('    for (var d = 0; d < dim; d++) easeArr.push(new KeyframeEase(0, 33));');
    lines.push('    for (var k = 1; k <= prop.numKeys; k++) prop.setTemporalEaseAtKey(k, easeArr, easeArr);');
    lines.push('  } catch (eEase) {}');
    lines.push('}');

    lines.push('if (comp.selectedLayers.length !== 1) return "ERR:Select exactly one layer in the comp first.";');
    lines.push('var layer = comp.selectedLayers[0];');
    lines.push('var anchorTime = layer.inPoint;');

    if (item.mechanism === "typewriter") {
        lines.push(buildTypewriterJSX_AE());
    } else if (item.mechanism === "karaoke") {
        lines.push(buildKaraokeJSX_AE());
    } else if (item.mechanism === "letterCascade") {
        lines.push(buildLetterCascadeJSX_AE());
    } else if (item.mechanism === "characterPop") {
        lines.push(buildCharacterPopJSX_AE());
    } else if (item.mechanism === "flip3d") {
        lines.push(buildFlip3dJSX_AE());
    } else if (item.mechanism === "ffxPreset") {
        lines.push(buildFfxApplyJSX_AE(item.ffxFile));
    } else {
        var anim = item.anim || [];
        for (var i = 0; i < anim.length; i++) lines.push(buildPropKeyframeJSX_AE(anim[i], i));
        var effects = item.effects || [];
        for (var j = 0; j < effects.length; j++) lines.push(buildEffectKeyframeJSX_AE(effects[j], j));
        if (item.shakeExpression) lines.push(buildShakeExpressionJSX_AE());
    }

    return lines.join("\n");
}

// =================================================================
// PREMIERE PRO builders
// =================================================================
// Two completely different mechanisms live here, for two different
// kinds of preset:
//
// - TEXT presets create brand-new animated content, so they're applied
//   by dropping a real, pre-built .mogrt (Motion Graphics Template)
//   onto a free video track at the playhead via Sequence.importMGT() —
//   confirmed against a real, shipping Premiere CEP extension's host
//   script. No clip selection needed at all, and no guessing at an
//   existing clip's property names: the .mogrt already carries its own
//   animation, authored once inside Premiere's own Essential Graphics
//   panel, the same way a real .ffx solved this for After Effects.
//   Presets without a real .mogrt file yet say so plainly instead of
//   attempting the property-guessing approach below, which repeated
//   real testing showed is not reliable for this case.
//
// - TRANSITIONS modify a clip that's already on the timeline (camera
//   punch/whip/shake on existing footage), which a .mogrt can't do —
//   for these, every clip's built-in "Motion"/"Opacity" components are
//   found by display/match name (there's no addProperty-by-name
//   shortcut here the way AE has) and keyframed via the documented
//   ComponentParam.addKey(Time) / setValueAtKey(Time, value) pair.
//
// Premiere has no per-property expressions and no scriptable
// per-character text animator, so shake/blur/text-animator presets
// degrade gracefully here (baked jitter keyframes instead of a
// wiggle expression; blur/directional-blur effects are skipped
// rather than guessed at) or are refused with a clear message.

// A real .mogrt (Motion Graphics Template), exported once from inside
// Premiere's own Essential Graphics panel, applied via
// Sequence.importMGT(path, ticks, videoTrackIndex, audioTrackIndex) —
// this hands the whole job to Premiere's own template-import code, no
// property-tree guessing at all. Confirmed against a real, shipping
// Premiere CEP extension's host script: insert at the playhead, on the
// lowest-numbered video track that's actually free there, never on top
// of an existing clip.
function buildMogrtApplyJSX_PPRO(mogrtRelativePath) {
    var fullPath = getAssetFullPath(mogrtRelativePath);
    if (!fullPath) return 'return "ERR:Could not resolve the preset file path.";';
    var lines = [];
    lines.push('var seq = app.project.activeSequence;');
    lines.push('if (!seq) return "ERR:Open a sequence first.";');
    lines.push('var mogrtFile = new File(' + jsxStringLiteral(fullPath) + ');');
    lines.push('if (!mogrtFile.exists) return "ERR:Preset file not found: ' + fullPath.replace(/'/g, "") + '";');
    lines.push('var playheadTicks = "0";');
    lines.push('try { var pp = seq.getPlayerPosition(); if (pp && pp.ticks !== undefined && pp.ticks !== null) playheadTicks = String(pp.ticks); } catch (ePP) {}');
    lines.push('var videoTrackCount = 0;');
    lines.push('try { videoTrackCount = seq.videoTracks.numTracks; } catch (eVT) {}');
    lines.push('if (videoTrackCount < 1) return "ERR:Sequence needs at least one video track.";');
    lines.push('function __trackFreeAt(track, ticksStr) {');
    lines.push('  if (!track) return false;');
    lines.push('  var playN = Number(ticksStr) || 0;');
    lines.push('  try {');
    lines.push('    var clips = track.clips;');
    lines.push('    if (!clips) return true;');
    lines.push('    for (var i = 0; i < clips.numItems; i++) {');
    lines.push('      var clip = clips[i]; if (!clip) continue;');
    lines.push('      var start = 0, end = 0;');
    lines.push('      try { start = Number(clip.start.ticks) || 0; } catch (eS) {}');
    lines.push('      try { end = Number(clip.end.ticks) || 0; } catch (eE) {}');
    lines.push('      if (playN >= start && playN < end) return false;');
    lines.push('    }');
    lines.push('  } catch (eTrk) { return false; }');
    lines.push('  return true;');
    lines.push('}');
    lines.push('var targetTrack = -1;');
    lines.push('for (var vt = 0; vt < videoTrackCount; vt++) { if (__trackFreeAt(seq.videoTracks[vt], playheadTicks)) { targetTrack = vt; break; } }');
    lines.push('if (targetTrack === -1) return "ERR:All video tracks are busy at the playhead \\u2014 add an empty video track above and try again.";');
    lines.push('var inserted = false, importErr = "";');
    lines.push('try { inserted = seq.importMGT(mogrtFile.fsName, playheadTicks, targetTrack, 0); } catch (eImportMGT) { importErr = eImportMGT.toString(); }');
    lines.push('if (!inserted) return "ERR:Could not add the preset to the timeline" + (importErr ? " (" + importErr + ")" : "") + ".";');
    lines.push('return "OK:added on V" + (targetTrack + 1);');
    return lines.join('\n');
}

// Matching strategy verified against a real, shipping Premiere CEP
// extension's host script: search every component/property by
// displayName OR matchName, exact match OR substring, case-insensitive
// — not the exact-displayName-only search this used before. Regular
// clips expose transform via a "Motion" component; Essential Graphics/
// MOGRT (text) clips instead expose "Vector Motion" with "Vector
// Position"/"Vector Scale"/"Vector Rotation" — both are tried as
// candidates so text clips resolve correctly instead of silently
// finding nothing.
function buildComponentPropLookup_PPRO(varName, componentCandidates, propCandidates) {
    var compArr = '[' + componentCandidates.map(jsxStringLiteral).join(', ') + ']';
    var propArr = '[' + propCandidates.map(jsxStringLiteral).join(', ') + ']';
    return (
        'function __xLower_' + varName + '(v) { try { return String(v || "").toLowerCase(); } catch (eLower) { return ""; } }\n' +
        'function __xMatch_' + varName + '(dn, mn, needles) {\n' +
        '  for (var n = 0; n < needles.length; n++) {\n' +
        '    var needle = __xLower_' + varName + '(needles[n]);\n' +
        '    if (dn === needle || mn === needle || dn.indexOf(needle) >= 0 || mn.indexOf(needle) >= 0) return true;\n' +
        '  }\n' +
        '  return false;\n' +
        '}\n' +
        'function find_' + varName + '() {\n' +
        '  var compNames = ' + compArr + ';\n' +
        '  var propNames = ' + propArr + ';\n' +
        '  for (var c = 0; c < trackItem.components.numItems; c++) {\n' +
        '    var comp = trackItem.components[c];\n' +
        '    if (!comp) continue;\n' +
        '    var cdn = __xLower_' + varName + '(comp.displayName);\n' +
        '    var cmn = ""; try { cmn = __xLower_' + varName + '(comp.matchName); } catch (eCmn) {}\n' +
        '    if (!__xMatch_' + varName + '(cdn, cmn, compNames)) continue;\n' +
        '    for (var p = 0; p < comp.properties.numItems; p++) {\n' +
        '      var prop = comp.properties[p];\n' +
        '      if (!prop) continue;\n' +
        '      var pdn = __xLower_' + varName + '(prop.displayName);\n' +
        '      var pmn = ""; try { pmn = __xLower_' + varName + '(prop.matchName); } catch (ePmn) {}\n' +
        '      if (__xMatch_' + varName + '(pdn, pmn, propNames)) return prop;\n' +
        '    }\n' +
        '  }\n' +
        '  return null;\n' +
        '}\n' +
        'var ' + varName + ' = find_' + varName + '();\n'
    );
}

function buildPropKeyframeJSX_PPRO(spec, index) {
    var prop = spec.prop;
    var varName = "p" + index;
    var origVar = varName + "Orig";
    var componentCandidates = (prop === "Opacity") ? ["Opacity"] : ["Motion", "Vector Motion"];
    var propCandidates = { Position: ["Position", "Vector Position"], Scale: ["Scale", "Vector Scale"], Rotation: ["Rotation", "Vector Rotation"], Opacity: ["Opacity"] }[prop];
    var lines = [];
    lines.push(buildComponentPropLookup_PPRO(varName, componentCandidates, propCandidates));
    // If this never finds a single property across the whole apply, the
    // code used to just silently do nothing while still returning "OK" —
    // exactly the "says Applied, nothing actually happened" bug a real
    // test surfaced. __anyPropFound tracks whether ANY property lookup
    // succeeded so buildPproBranch can tell the difference between "OK,
    // did the thing" and "OK, but only because everything was silently
    // skipped."
    lines.push('if (' + varName + ') {');
    // setTimeVarying(true) is the step that was missing entirely before
    // — without it, addKey()/setValueAtKey() can silently fail to
    // produce a real animating keyframe track on a Component parameter.
    // Confirmed against a real working Premiere extension's host script.
    lines.push('  try { ' + varName + '.setTimeVarying(true); } catch (eTV' + index + ') { try { ' + varName + '.setTimeVarying(1); } catch (eTV2' + index + ') {} }');
    // .getValue() (not .value) is what the reference implementation
    // reads current values with — kept as the primary read, with .value
    // as a fallback in case a given property type only supports one.
    lines.push('  var ' + origVar + ';');
    lines.push('  try { ' + origVar + ' = ' + varName + '.getValue(); } catch (eGV' + index + ') { ' + origVar + ' = ' + varName + '.value; }');
    lines.push('  __anyPropFound = true;');
    // A property matching by name and setValueAtKey() not throwing is
    // NOT proof it actually did anything visible — a real test found
    // that exact case (found it, "Applied" showed, nothing moved). This
    // logs the found property's original value regardless of outcome,
    // so a wrong match shows up as an implausible value instead of
    // being indistinguishable from success.
    lines.push('  __diagLog.push(' + jsxStringLiteral(prop) + ' + "=" + __fmtVal(' + origVar + '));');
    if (prop === "Position") {
        // Regular "Motion" > Position is in pixels; Essential Graphics'
        // "Vector Motion" > Position is normalized 0..1 of the frame.
        // Every preset's Position deltas in this file are authored in
        // pixels, so on a normalized property they'd be enormous (a
        // "+90" pixel nudge would read as +90 whole frame-widths) —
        // detected here by magnitude (normalized values are never > ~3)
        // and divided down by the sequence's actual frame size instead
        // of guessing a fixed conversion factor.
        lines.push('  var ' + varName + 'IsNormalized = (Math.abs(' + origVar + '[0]) <= 3 && Math.abs(' + origVar + '[1]) <= 3);');
        lines.push('  var ' + varName + 'FrameW = 1920, ' + varName + 'FrameH = 1080;');
        lines.push('  try { if (seq.frameSizeHorizontal) ' + varName + 'FrameW = seq.frameSizeHorizontal; if (seq.frameSizeVertical) ' + varName + 'FrameH = seq.frameSizeVertical; } catch (eFrame' + index + ') {}');
    }
    for (var i = 0; i < spec.keys.length; i++) {
        var k = spec.keys[i];
        var valExpr;
        if (prop === "Position") {
            valExpr = '(' + varName + 'IsNormalized ? [' + origVar + '[0] + (' + k.v[0] + ') / ' + varName + 'FrameW, ' + origVar + '[1] + (' + k.v[1] + ') / ' + varName + 'FrameH] : [' + origVar + '[0] + (' + k.v[0] + '), ' + origVar + '[1] + (' + k.v[1] + ')])';
        } else if (prop === "Scale") {
            // Premiere's default Motion > Scale is a single uniform
            // percentage (not an [x,y] pair) — every spec in this file
            // uses equal x/y anyway, so v[0] alone is lossless here.
            valExpr = '(' + origVar + ' * (' + k.v[0] + ') / 100)';
        } else if (prop === "Rotation") {
            valExpr = '(' + origVar + ' + (' + k.v + '))';
        } else { // Opacity
            valExpr = String(k.v);
        }
        lines.push('  var t' + index + '_' + i + ' = _xTime(anchorSeconds + ' + k.t + ');');
        lines.push('  try { ' + varName + '.addKey(t' + index + '_' + i + '); } catch (eAK' + index + '_' + i + ') {}');
        lines.push('  try { ' + varName + '.setValueAtKey(t' + index + '_' + i + ', ' + valExpr + ', 1); }');
        lines.push('  catch (eSV' + index + '_' + i + ') { try { ' + varName + '.setValueAtKey(t' + index + '_' + i + ', ' + valExpr + '); } catch (eSV2' + index + '_' + i + ') {} }');
    }
    lines.push('} else {');
    lines.push('  __diagLog.push(' + jsxStringLiteral(prop + " not found (tried " + componentCandidates.join("/") + ")") + ');');
    lines.push('}');
    return lines.join("\n");
}

// No expression engine in Premiere, so "camera shake" is baked as a
// handful of small jittered Position keyframes on top of whatever the
// preset's own Position keyframes already set — computed here (panel
// side) as fixed pseudo-random offsets, not generated live in-host.
function buildShakeJitterJSX_PPRO() {
    var jitters = [[3, -2], [-4, 3], [2, -3], [-2, 1]];
    var lines = [];
    lines.push(buildComponentPropLookup_PPRO("shakePos", ["Motion", "Vector Motion"], ["Position", "Vector Position"]));
    lines.push('if (shakePos) {');
    lines.push('  try { shakePos.setTimeVarying(true); } catch (eTVs) { try { shakePos.setTimeVarying(1); } catch (eTVs2) {} }');
    lines.push('  var shakeOrig; try { shakeOrig = shakePos.getValue(); } catch (eGVs) { shakeOrig = shakePos.value; }');
    lines.push('  var shakeNorm = (Math.abs(shakeOrig[0]) <= 3 && Math.abs(shakeOrig[1]) <= 3);');
    lines.push('  var shakeFrameW = 1920, shakeFrameH = 1080;');
    lines.push('  try { if (seq.frameSizeHorizontal) shakeFrameW = seq.frameSizeHorizontal; if (seq.frameSizeVertical) shakeFrameH = seq.frameSizeVertical; } catch (eFrameS) {}');
    for (var i = 0; i < jitters.length; i++) {
        var t = 0.03 + i * 0.06;
        lines.push('  var shakeT' + i + ' = _xTime(anchorSeconds + ' + t + ');');
        lines.push('  try { shakePos.addKey(shakeT' + i + '); } catch (eSAK' + i + ') {}');
        lines.push('  var shakeVal' + i + ' = shakeNorm ? [shakeOrig[0] + (' + jitters[i][0] + ') / shakeFrameW, shakeOrig[1] + (' + jitters[i][1] + ') / shakeFrameH] : [shakeOrig[0] + (' + jitters[i][0] + '), shakeOrig[1] + (' + jitters[i][1] + ')];');
        lines.push('  try { shakePos.setValueAtKey(shakeT' + i + ', shakeVal' + i + ', 1); } catch (eSSV' + i + ') { try { shakePos.setValueAtKey(shakeT' + i + ', shakeVal' + i + '); } catch (eSSV2' + i + ') {} }');
    }
    lines.push('}');
    return lines.join("\n");
}

function buildPproBranch(item, kind) {
    if (AE_ONLY_MECHANISMS.indexOf(item.mechanism) !== -1) {
        return 'return "ERR:\\"' + item.name.replace(/"/g, "") + '\\" is an After Effects\\u2013only preset for now \\u2014 it needs either AE\\u2019s .ffx preset format or per-character text animation, neither of which Premiere\\u2019s scripting API exposes.";';
    }

    if (kind === "text") {
        if (item.mogrtFile) return buildMogrtApplyJSX_PPRO(item.mogrtFile);
        // No real .mogrt exists for this preset yet. The old approach —
        // keyframing whatever clip happens to be selected/under the
        // playhead — is what real testing kept showing as "says Applied,
        // nothing visibly changes" for text specifically (a selected
        // clip isn't guaranteed to even BE a text/graphics clip, and its
        // Motion/Vector Motion shape varies). Saying so plainly beats
        // silently attempting the unreliable path again.
        return 'return "ERR:\\"' + item.name.replace(/"/g, "") + '\\" isn\\u2019t wired for Premiere yet \\u2014 it needs a real .mogrt exported from Premiere\\u2019s Essential Graphics panel, the same way the Apple Text presets needed a real .ffx file in After Effects.";';
    }

    var lines = [];
    lines.push('var seq = app.project.activeSequence;');
    lines.push('if (!seq) return "ERR:Open a sequence first.";');
    // seq.getSelection() is not consistently present across Premiere
    // versions/builds — when it is, use it (a real timeline selection is
    // the more precise, intentional target); when it isn't (or throws),
    // fall back to whatever clip sits under the playhead on the topmost
    // video track that has one there. getPlayerPosition() + track.clips
    // are long-standing, far more reliably documented calls than
    // getSelection(), so this fallback is the higher-confidence path,
    // not an afterthought.
    lines.push('var trackItem = null;');
    lines.push('try {');
    lines.push('  if (typeof seq.getSelection === "function") {');
    lines.push('    var sel = seq.getSelection();');
    lines.push('    if (sel && sel.length === 1) trackItem = sel[0];');
    lines.push('  }');
    lines.push('} catch (eSel) { trackItem = null; }');
    lines.push('if (!trackItem) {');
    lines.push('  try {');
    lines.push('    var playheadSeconds = seq.getPlayerPosition().seconds;');
    lines.push('    for (var vt = 0; vt < seq.videoTracks.numTracks && !trackItem; vt++) {');
    lines.push('      var track = seq.videoTracks[vt];');
    lines.push('      for (var ci = 0; ci < track.clips.numItems; ci++) {');
    lines.push('        var clip = track.clips[ci];');
    lines.push('        if (playheadSeconds >= clip.start.seconds && playheadSeconds < clip.end.seconds) { trackItem = clip; break; }');
    lines.push('      }');
    lines.push('    }');
    lines.push('  } catch (ePlayhead) { trackItem = null; }');
    lines.push('}');
    lines.push('if (!trackItem) return "ERR:Select a clip (or park the playhead over one on a video track), then try again.";');
    lines.push('var anchorSeconds = trackItem.start.seconds;');
    // Real Time objects, not raw tick-count strings — confirmed against
    // a real working Premiere extension's host script, which builds
    // keyframe times this way for Component.addKey()/setValueAtKey().
    lines.push('function _xTime(seconds) {');
    lines.push('  var t = new Time();');
    lines.push('  t.seconds = Math.max(0, Number(seconds) || 0);');
    lines.push('  return t;');
    lines.push('}');
    lines.push('var __anyPropFound = false;');
    lines.push('var __diagLog = [];');
    lines.push('function __fmtVal(v) {');
    lines.push('  if (v instanceof Array) { var s = "["; for (var vi = 0; vi < v.length; vi++) s += (vi ? "," : "") + v[vi]; return s + "]"; }');
    lines.push('  return String(v);');
    lines.push('}');

    var anim = item.anim || [];
    for (var i = 0; i < anim.length; i++) lines.push(buildPropKeyframeJSX_PPRO(anim[i], i));
    // Effects (Fast Box Blur / Directional Blur) have no reliably
    // documented "add new effect to a clip" call in Premiere's basic
    // scripting API, unlike AE's layer.property("Effects").addProperty()
    // — rather than guess at one and risk silently doing the wrong
    // thing, those are skipped here; the core motion still applies.
    if (item.shakeExpression) lines.push(buildShakeJitterJSX_PPRO());

    // If NOTHING was found across every property this preset needed,
    // the trackItem.components/.properties navigation this whole branch
    // is built on is almost certainly not matching Premiere's real object
    // shape on this install — rather than report "OK" for an apply that
    // silently did nothing (confirmed happening in real testing), surface
    // exactly what IS actually on the clip so the real names are known
    // instead of guessed at again.
    if (anim.length > 0) {
        lines.push('if (!__anyPropFound) {');
        lines.push('  var __diag = [];');
        lines.push('  try {');
        lines.push('    for (var __ci = 0; __ci < trackItem.components.numItems; __ci++) {');
        lines.push('      var __c = trackItem.components[__ci];');
        lines.push('      var __pn = [];');
        lines.push('      for (var __pi = 0; __pi < __c.properties.numItems; __pi++) __pn.push(__c.properties[__pi].displayName);');
        lines.push('      __diag.push(__c.displayName + "[" + __pn.join(",") + "]");');
        lines.push('    }');
        lines.push('  } catch (eDiag) { __diag.push("(inspecting components threw: " + eDiag.toString() + ")"); }');
        lines.push('  return "ERR:Found no matching Motion/Opacity property on this clip. Components actually present: " + (__diag.length ? __diag.join(" | ") : "none");');
        lines.push('}');
    }

    // Always report what was actually found and set — "OK" alone was
    // indistinguishable from "found something under the right name that
    // wasn't really the thing" (a real test hit exactly that: no error,
    // 'Applied' shown, nothing visibly moved). This makes every apply
    // self-diagnosing regardless of whether it visibly worked.
    lines.push('return "OK:" + __diagLog.join(" | ");');

    return lines.join("\n");
}

// =================================================================
// Full script assembly.
// =================================================================
// Host detection is two layers, most-reliable first: `hostId` ("AEFT" /
// "PPRO") is determined on the PANEL side via CSInterface's
// getHostEnvironment().appId before this is ever called — the same
// mechanism applyLut()/importSfx() already use successfully — and
// baked into the script as a literal. `app.appName` inside ExtendScript
// is kept only as a fallback for the (unlikely, but unverified) case
// where getHostEnvironment() didn't resolve: relying on app.appName
// ALONE was the previous design, and there's no strong confirmation
// that property reads the same way on both hosts, so a single point of
// failure there could silently break every Text/Transition apply on
// both AE and Premiere at once — worth not depending on it exclusively.
function buildApplyScript(item, hostId, kind) {
    var aeBody = buildAeBranch(item);
    var pproBody = buildPproBranch(item, kind);

    // The AE/Premiere branches below are full of early `return "ERR:...";`
    // validation exits (no layer selected, wrong host, etc.) — those used
    // to `return` straight out of THIS whole function, which skipped
    // app.endUndoGroup() and left AE's undo group open every time someone
    // clicked Apply without the right thing selected (very easy to do
    // while testing). Running the branch logic in its own inner function
    // means every one of those early returns just returns a string to
    // `resultMsg`, and the outer function always reaches endUndoGroup().
    var script =
        '(function () {\n' +
        '  if (typeof app === "undefined" || !app.project) return "ERR:No active project.";\n' +
        '  var hostId = ' + jsxStringLiteral(hostId || "") + ';\n' +
        '  if (hostId !== "AEFT" && hostId !== "PPRO") {\n' +
        '    var appName = "";\n' +
        '    try { appName = String(app.appName || ""); } catch (eName) {}\n' +
        '    if (appName.indexOf("After Effects") !== -1) hostId = "AEFT";\n' +
        '    else if (appName.indexOf("Premiere Pro") !== -1) hostId = "PPRO";\n' +
        '  }\n' +
        '  if (hostId !== "AEFT" && hostId !== "PPRO") return "ERR:Unsupported host.";\n' +
        '  app.beginUndoGroup(' + jsxStringLiteral("CreatorStash: Apply " + item.name) + ');\n' +
        '  var resultMsg;\n' +
        '  try {\n' +
        '    resultMsg = (function () {\n' +
        '      if (hostId === "AEFT") {\n' +
        '        ' + aeBody.split("\n").join("\n        ") + '\n' +
        '      } else {\n' +
        '        ' + pproBody.split("\n").join("\n        ") + '\n' +
        '      }\n' +
        '      return "OK";\n' +
        '    })();\n' +
        '  } catch (eApply) {\n' +
        '    resultMsg = "ERR:" + eApply.toString();\n' +
        '  }\n' +
        '  app.endUndoGroup();\n' +
        '  return resultMsg;\n' +
        '})();';

    return script;
}

// ---------------------------------------------------------------
// Toast — brief status feedback after an Apply click (success/error),
// since there's no other feedback channel back from the host script.
// ---------------------------------------------------------------
var toastTimer = null;
// Error toasts don't auto-dismiss — they stay up until tapped away, so
// there's time to screenshot the exact message (screenshots of the real
// panel/errors have been the single most useful debugging input so far,
// far more than a description after the fact).
// onTap (optional): fires on click IN ADDITION TO the permanent
// dismiss-on-click listener wired up below (that one just hides the
// toast; this one runs first and can do something with the tap, e.g.
// open a purchase link for a locked-item prompt). Reset on every call
// so a leftover handler from a previous toast can never fire on an
// unrelated later one.
function showToast(message, isError, durationMs, onTap) {
    var toast = document.getElementById("toast");
    if (!toast) return;
    toast.textContent = message + (isError ? "  (tap to dismiss)" : "");
    toast.classList.toggle("toast-error", !!isError);
    toast.classList.add("visible");
    toast.onclick = onTap || null;
    if (toastTimer) clearTimeout(toastTimer);
    if (isError) return;
    toastTimer = setTimeout(function () {
        toast.classList.remove("visible");
    }, durationMs || 2600);
}

(function () {
    var toastEl = document.getElementById("toast");
    if (toastEl) {
        toastEl.addEventListener("click", function () {
            toastEl.classList.remove("visible");
        });
    }
})();

function applyPreset(item, kind) {
    try {
        if (typeof CSInterface === "undefined") {
            showToast("Apply only works inside After Effects or Premiere Pro.", true);
            return;
        }
        var cs = new CSInterface();
        var hostId = "";
        try { hostId = cs.getHostEnvironment().appId; } catch (eHost) {}
        var script = buildApplyScript(item, hostId, kind);
        cs.evalScript(script, function (result) {
            if (!result || result.indexOf("ERR:") === 0) {
                showToast(result ? result.slice(4) : "Apply failed — unknown error.", true);
            } else if (result.indexOf("OK:") === 0 && result.length > 3) {
                // Premiere attaches a diagnostic log even on success — "OK"
                // alone already turned out to hide a real failure once
                // (found matching names, set values, nothing visibly
                // moved), so this stays up (persistent, like an error)
                // instead of vanishing in 2 seconds, so it can actually be
                // screenshotted and checked against what should have
                // happened.
                showToast("Applied “" + item.name + "” — " + result.slice(3), true);
            } else {
                showToast("Applied “" + item.name + "” ✓", false);
            }
        });
    } catch (e) {
        showToast("Apply failed: " + e.message, true);
    }
}

// ---------------------------------------------------------------
// LUTs — a raw .cube file isn't something either host recognizes as
// importable media the way an audio file is, and there is no
// reliably-documented ExtendScript call to load a specific file straight
// into Lumetri Color's "Input LUT" slot. So instead of guessing at a
// one-click "apply" that might silently do the wrong thing, this does
// the two parts that ARE solid: (1) in After Effects, add the Lumetri
// Color effect to the selected layer — a plain addProperty() call, the
// same well-tested mechanism already used for Fast Box Blur/Directional
// Blur; (2) on every host, copy the LUT's absolute file path to the
// clipboard, since every OS file-open dialog (including Lumetri's own
// "Browse" button) accepts a pasted path in its filename field — a
// completely standard, host-version-independent way in.
// ---------------------------------------------------------------

function copyToClipboard(text) {
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text);
            return true;
        }
    } catch (e) {}
    try {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        var ok = document.execCommand("copy");
        document.body.removeChild(ta);
        return ok;
    } catch (e2) {
        return false;
    }
}

function buildAddLutEffectScript(hostId, fullLutPath) {
    // Same always-close-the-undo-group shape as buildApplyScript, plus
    // the same dual host-detection (panel-supplied hostId, app.appName
    // fallback) used everywhere else in this file.
    //
    // "Apply Color LUT" (not Lumetri Color) is the effect added here —
    // it's a single-purpose effect with exactly one control ("Choose a
    // 3D LUT..."), so there's far less to get lost in than Lumetri
    // Color's whole multi-section color-grading panel when all you need
    // is "load this one file." Lumetri Color is only the fallback if
    // Apply Color LUT can't be added for some reason.
    //
    // The LUT File control is a file-picker–type property, which
    // classic ExtendScript is NOT reliably documented to support
    // setting via .setValue(path) — but it's wrapped here as a bonus,
    // best-effort attempt (a few plausible property-name candidates)
    // that costs nothing if every one of them throws: the effect is
    // still added and the path is still copied to the clipboard either
    // way, so this can only ever make the outcome better, never worse.
    var candidates = ["LUT File", "ADBE Color Lut-0001", "Lut File"];
    var trySetLines = [];
    for (var i = 0; i < candidates.length; i++) {
        trySetLines.push(
            'if (!autoSet) { try { lutEffect.property(' + jsxStringLiteral(candidates[i]) + ').setValue(' + jsxStringLiteral(fullLutPath) + '); autoSet = true; } catch (eSet' + i + ') {} }'
        );
    }

    return (
        '(function () {\n' +
        '  if (typeof app === "undefined" || !app.project) return "ERR:No active project.";\n' +
        '  var hostId = ' + jsxStringLiteral(hostId || "") + ';\n' +
        '  if (hostId !== "AEFT" && hostId !== "PPRO") {\n' +
        '    var appName = "";\n' +
        '    try { appName = String(app.appName || ""); } catch (eName) {}\n' +
        '    if (appName.indexOf("After Effects") !== -1) hostId = "AEFT";\n' +
        '    else if (appName.indexOf("Premiere Pro") !== -1) hostId = "PPRO";\n' +
        '  }\n' +
        '  if (hostId === "PPRO") return "SKIP:not-ae";\n' +
        '  if (hostId !== "AEFT") return "ERR:Unsupported host.";\n' +
        '  var comp = app.project.activeItem;\n' +
        '  if (!comp || !(comp instanceof CompItem)) return "ERR:Open a composition first.";\n' +
        '  if (comp.selectedLayers.length !== 1) return "ERR:Select exactly one layer in the comp first.";\n' +
        '  var layer = comp.selectedLayers[0];\n' +
        '  app.beginUndoGroup("CreatorStash: Apply LUT");\n' +
        '  var resultMsg;\n' +
        '  try {\n' +
        '    var effects = layer.property("Effects");\n' +
        '    var lutEffect = null;\n' +
        '    var already = false;\n' +
        '    for (var ei = 1; ei <= effects.numProperties; ei++) {\n' +
        '      var existingName = effects.property(ei).name;\n' +
        '      if (existingName === "Apply Color LUT" || existingName === "Lumetri Color") { lutEffect = effects.property(ei); already = true; break; }\n' +
        '    }\n' +
        '    var effectKind;\n' +
        '    if (lutEffect) {\n' +
        '      effectKind = lutEffect.name;\n' +
        '    } else {\n' +
        '      try { lutEffect = effects.addProperty("Apply Color LUT"); effectKind = "Apply Color LUT"; }\n' +
        '      catch (eAcl) { lutEffect = effects.addProperty("Lumetri Color"); effectKind = "Lumetri Color"; }\n' +
        '    }\n' +
        '    var autoSet = false;\n' +
        (fullLutPath ? '    ' + trySetLines.join('\n    ') + '\n' : '') +
        '    resultMsg = (already ? "ALREADY:" : "ADDED:") + effectKind + (autoSet ? ":AUTOSET" : "");\n' +
        '  } catch (eFx) {\n' +
        '    resultMsg = "ERR:" + eFx.toString();\n' +
        '  }\n' +
        '  app.endUndoGroup();\n' +
        '  return resultMsg;\n' +
        '})();'
    );
}

function applyLut(item) {
    var fullPath = getAssetFullPath(item.file);
    var copied = fullPath ? copyToClipboard(fullPath) : false;
    var pathHint = copied
        ? "LUT path copied — paste it into the file browser."
        : "Open this inside After Effects or Premiere Pro to copy the LUT path.";

    if (typeof CSInterface === "undefined") {
        showToast(pathHint, !copied, 4200);
        return;
    }

    var cs = new CSInterface();
    var hostId = "";
    try { hostId = cs.getHostEnvironment().appId; } catch (eHost) {}

    cs.evalScript(buildAddLutEffectScript(hostId, fullPath), function (result) {
        if (result === "SKIP:not-ae") {
            // Premiere: no reliably-documented "add a new effect to a
            // clip" call, so the clipboard copy is the whole story here
            // — add Lumetri Color yourself, then paste.
            showToast(pathHint, !copied, 4200);
            return;
        }
        if (!result || result.indexOf("ERR:") === 0) {
            var reason = result ? result.slice(4) : "unknown error";
            showToast("Couldn't add a LUT effect (" + reason + ") — " + pathHint, true, 4200);
            return;
        }
        var autoSet = result.indexOf(":AUTOSET") !== -1;
        var effectKind = result.split(":")[1] || "the LUT effect";
        var wasAlready = result.indexOf("ALREADY:") === 0;
        if (autoSet) {
            showToast("“" + item.name + "” loaded ✓ — done, nothing else to do.", false, 3000);
        } else if (wasAlready) {
            showToast("This layer already has " + effectKind + " — " + pathHint, !copied, 4200);
        } else {
            showToast(effectKind + " added ✓ — " + pathHint, !copied, 4200);
        }
    });
}

// ---------------------------------------------------------------
// SFX import — lands the audio file in the host's own Project panel
// via plain ExtendScript file import (app.project.importFile in AE,
// app.project.importFiles in Premiere — the same well-tested call
// already used elsewhere in this file). Dragging straight from an
// HTML panel onto the host's native timeline was tried first and
// turned out not to work reliably in real testing; importing into the
// Project panel instead sidesteps that entirely, because the last
// step — dragging from the Project panel onto the timeline — is a
// native-to-native drag inside the host itself, which always works.
// ---------------------------------------------------------------

// One script, both hosts — same dual host-detection (panel-supplied
// hostId first, app.appName fallback) as buildApplyScript, instead of
// picking between two separate scripts on the panel side alone. That
// way a wrong/empty hostId can't silently send AE the Premiere-shaped
// import code (or vice versa) and fail for a reason that looks like
// "nothing happened."
function buildImportSfxScript(fullPath, hostId) {
    var fullPathEscaped = fullPath.replace(/'/g, "");
    return (
        '(function () {\n' +
        '  if (typeof app === "undefined" || !app.project) return "ERR:No active project.";\n' +
        '  var hostId = ' + jsxStringLiteral(hostId || "") + ';\n' +
        '  if (hostId !== "AEFT" && hostId !== "PPRO") {\n' +
        '    var appName = "";\n' +
        '    try { appName = String(app.appName || ""); } catch (eName) {}\n' +
        '    if (appName.indexOf("After Effects") !== -1) hostId = "AEFT";\n' +
        '    else if (appName.indexOf("Premiere Pro") !== -1) hostId = "PPRO";\n' +
        '  }\n' +
        '  if (hostId !== "AEFT" && hostId !== "PPRO") return "ERR:Unsupported host.";\n' +
        '  var sfxFile = new File(' + jsxStringLiteral(fullPath) + ');\n' +
        '  if (!sfxFile.exists) return "ERR:File not found: ' + fullPathEscaped + '";\n' +
        '  var resultMsg;\n' +
        '  try {\n' +
        '    var existing = null, sfxItem = null;\n' +
        '    if (hostId === "AEFT") {\n' +
        '      for (var fi = 1; fi <= app.project.numItems; fi++) {\n' +
        '        var it = app.project.item(fi);\n' +
        '        if (it instanceof FootageItem && it.mainSource && it.mainSource.file && it.mainSource.file.fsName === sfxFile.fsName) { existing = it; break; }\n' +
        '      }\n' +
        '      sfxItem = existing || app.project.importFile(new ImportOptions(sfxFile));\n' +
        // Landed in the project either way — now try to also drop it
        // directly on the timeline, at the selected layer's start if
        // exactly one is selected, otherwise at the current playhead.
        // That "also" matters: a comp isn't always open, so this can't
        // be the ONLY path in, but when one is open this is what makes
        // it show up right where you're working instead of leaving a
        // manual Project-panel-to-timeline drag as the only way in.\n' +
        '      var comp = app.project.activeItem;\n' +
        '      if (comp instanceof CompItem) {\n' +
        '        var anchorTime = (comp.selectedLayers.length === 1) ? comp.selectedLayers[0].inPoint : comp.time;\n' +
        '        for (var li = comp.layers.length; li >= 1; li--) {\n' +
        '          var existingLayer = comp.layers[li];\n' +
        '          if (existingLayer.name === "CreatorStash SFX" && Math.abs(existingLayer.startTime - anchorTime) < 0.001) existingLayer.remove();\n' +
        '        }\n' +
        '        var sfxLayer = comp.layers.add(sfxItem);\n' +
        '        sfxLayer.startTime = anchorTime;\n' +
        '        sfxLayer.name = "CreatorStash SFX";\n' +
        '        resultMsg = "OK:timeline";\n' +
        '      } else {\n' +
        '        resultMsg = existing ? "OK:already" : "OK:imported";\n' +
        '      }\n' +
        '    } else {\n' +
        '      for (var pi = 0; pi < app.project.rootItem.children.numItems; pi++) {\n' +
        '        var pit = app.project.rootItem.children[pi];\n' +
        '        if (pit.getMediaPath && pit.getMediaPath() === sfxFile.fsName) { existing = pit; break; }\n' +
        '      }\n' +
        '      if (!existing) {\n' +
        '        var beforeCount = app.project.rootItem.children.numItems;\n' +
        '        app.project.importFiles([sfxFile.fsName]);\n' +
        '        if (app.project.rootItem.children.numItems > beforeCount) sfxItem = app.project.rootItem.children[app.project.rootItem.children.numItems - 1];\n' +
        '      } else {\n' +
        '        sfxItem = existing;\n' +
        '      }\n' +
        '      var seq = app.project.activeSequence;\n' +
        // anchorSeconds defaults to 0 (sequence start), NOT null — a
        // precise position from a real selection/playhead is preferred
        // when it can be found, but giving up on landing on the
        // timeline entirely just because detection failed was worse
        // than landing at 0:00 and letting it be dragged into place:
        // "on the timeline somewhere" beats "only in the Project panel"
        // every time this preset actually gets applied.
        '      var anchorSeconds = 0;\n' +
        '      var usedFallbackPosition = true;\n' +
        '      if (seq) {\n' +
        '        var trackItem = null;\n' +
        '        try {\n' +
        '          if (typeof seq.getSelection === "function") {\n' +
        '            var sel = seq.getSelection();\n' +
        '            if (sel && sel.length === 1) trackItem = sel[0];\n' +
        '          }\n' +
        '        } catch (eSel) { trackItem = null; }\n' +
        '        if (trackItem) {\n' +
        '          anchorSeconds = trackItem.start.seconds;\n' +
        '          usedFallbackPosition = false;\n' +
        '        } else {\n' +
        '          try {\n' +
        '            var pp = seq.getPlayerPosition();\n' +
        '            if (pp && typeof pp.seconds === "number") { anchorSeconds = pp.seconds; usedFallbackPosition = false; }\n' +
        '          } catch (ePh) {}\n' +
        '        }\n' +
        '      }\n' +
        '      var whyNotTimeline = "";\n' +
        '      if (!seq) whyNotTimeline = "no active sequence";\n' +
        '      else if (!seq.audioTracks || seq.audioTracks.numTracks === 0) whyNotTimeline = "sequence has no audio track";\n' +
        '      if (sfxItem && seq && seq.audioTracks && seq.audioTracks.numTracks > 0) {\n' +
        '        try {\n' +
        '          var audioTrack = seq.audioTracks[seq.audioTracks.numTracks - 1];\n' +
        // overwriteClip's 2nd argument is documented as ticks (a
        // Premiere-internal time unit), passed as a STRING — not
        // seconds. anchorSeconds.toString() (e.g. "5.2") was silently
        // misread as an almost-zero tick count every time, a very
        // plausible reason clips never landed on the timeline: the
        // call may have thrown or landed somewhere unintended rather
        // than truly failing. Time.ticks returns the correct string.
        '          var overwriteTime = new Time(); overwriteTime.seconds = anchorSeconds;\n' +
        '          audioTrack.overwriteClip(sfxItem, overwriteTime.ticks);\n' +
        '          resultMsg = usedFallbackPosition ? "OK:timeline:0:00 (couldn\'t find a selection/playhead, dropped at sequence start)" : "OK:timeline";\n' +
        '        } catch (eOverwrite) {\n' +
        '          resultMsg = (existing ? "OK:already:" : "OK:imported:") + "overwriteClip failed: " + eOverwrite.toString();\n' +
        '        }\n' +
        '      } else {\n' +
        '        resultMsg = (existing ? "OK:already:" : "OK:imported:") + whyNotTimeline;\n' +
        '      }\n' +
        '    }\n' +
        '  } catch (eImp) {\n' +
        '    resultMsg = "ERR:" + eImp.toString();\n' +
        '  }\n' +
        '  return resultMsg;\n' +
        '})();'
    );
}

function importSfx(item) {
    if (typeof CSInterface === "undefined") {
        showToast("Import only works inside After Effects or Premiere Pro.", true);
        return;
    }
    var fullPath = getAssetFullPath(item.file);
    if (!fullPath) {
        showToast("Couldn't resolve the file path — try reopening the panel.", true);
        return;
    }

    var cs = new CSInterface();
    var hostId = "";
    try { hostId = cs.getHostEnvironment().appId; } catch (eHost) {}

    var script = buildImportSfxScript(fullPath, hostId);

    cs.evalScript(script, function (result) {
        if (!result || result.indexOf("ERR:") === 0) {
            showToast(result ? result.slice(4) : "Import failed — unknown error.", true, 4200);
            return;
        }
        if (result === "OK:timeline") {
            showToast("“" + item.name + "” added ✓", false, 2200);
            return;
        }
        if (result.indexOf("OK:timeline:") === 0) {
            // Landed on the timeline, but at the sequence start rather
            // than a detected selection/playhead position — still a win
            // over Project-panel-only, worth saying so it's not mistaken
            // for having landed exactly where expected.
            showToast("“" + item.name + "” added at " + result.slice(12), false, 4200);
            return;
        }
        // Premiere carries a specific reason it didn't land on the
        // timeline (e.g. "OK:imported:no active sequence") instead of
        // the plain "OK:imported"/"OK:already" AE uses — surface it so
        // "went to Project panel instead of timeline" has an actual
        // cause attached rather than being a silent mystery.
        var parts = result.split(":");
        var status = parts[0] + ":" + parts[1]; // "OK:imported" or "OK:already"
        var reason = parts.slice(2).join(":");
        var base = status === "OK:already"
            ? "“" + item.name + "” is already in your Project panel"
            : "“" + item.name + "” added to your Project panel ✓";
        if (reason) {
            showToast(base + " — didn't land on the timeline (" + reason + "). Drag it from the Project panel instead.", true, 6000);
        } else {
            showToast(base + " — open a comp/sequence so it can drop straight onto the timeline next time.", false, 4200);
        }
    });
}
