// CreatorStash by Kreevo.

// ---------------------------------------------------------------
// CONFIG
// ---------------------------------------------------------------
var APP_VERSION = "1.6.2";

var CONFIG = {
    SUPPORT_EMAIL: "kreevoassets@gmail.com",
    // Hosted on kreevo.github.io (an existing, already-live GitHub Pages
    // site) rather than a new repo — version.json + the release zip live
    // under /creatorstash/ there. Bump version.json's "version" (and
    // push a new zip alongside it) on every real release; this file's
    // own APP_VERSION above is what gets compared against it.
    UPDATE_CHECK_URL: "https://kreevo.github.io/creatorstash/version.json",
    RELEASE_PAGE_URL: "https://kreevo.github.io/creatorstash/CreatorStash.zip",
    NEW_BADGE_DAYS: 30,
    // The product's Gumroad ID (same field/format as Crash Guard's own
    // GUMROAD_PRODUCT_ID — a base64-ish string ending in "=="; found on
    // the product's edit page, not the same thing as a customer's
    // license key).
    GUMROAD_PRODUCT_ID: "29W4vPTFQmpf0_r5D-hb8A==",
    // The product's public purchase page — powers the "Buy CreatorStash
    // Premium" settings-menu item and every locked-item tap prompt.
    PURCHASE_URL: "https://kreevo.gumroad.com/l/CreatorStashPremium"
};

// ---------------------------------------------------------------
// LICENSE — Gumroad license key verification (v2/licenses/verify, the
// public endpoint meant for exactly this client-side use — no seller
// access token needed). Same proven pattern as Crash Guard's Gumroad
// gate, adapted from ExtendScript+curl to a plain fetch() here since
// this panel runs in a real Chromium context. Verified once, when the
// user clicks Activate; the result is cached locally so every later
// panel open just reads it back instead of re-checking with Gumroad.
// ---------------------------------------------------------------
var LICENSE_STORAGE_KEY = "creatorstash_license";

function loadLicenseState() {
    try {
        var raw = localStorage.getItem(LICENSE_STORAGE_KEY);
        if (!raw) return { status: "free", key: "" };
        var obj = JSON.parse(raw);
        return (obj && obj.status === "licensed" && obj.key) ? obj : { status: "free", key: "" };
    } catch (e) {
        return { status: "free", key: "" };
    }
}

function saveLicenseState(status, key) {
    try {
        localStorage.setItem(LICENSE_STORAGE_KEY, JSON.stringify({ status: status, key: key || "" }));
    } catch (e) {}
}

var licenseState = loadLicenseState();
var LICENSE_STATUS = licenseState.status; // "free" | "licensed"

// 1.6.2: some machines (firewall / antivirus / VPN / proxy) block the panel's
// own browser from reaching Gumroad. Activation now tries several routes in
// turn — fetch, XHR, Node.js https, then the system's curl via ExtendScript —
// and the first real Gumroad answer wins.
var GUMROAD_VERIFY_URL = "https://api.gumroad.com/v2/licenses/verify";
var LICENSE_TIMEOUT_MS = 20000;

function parseGumroad(txt) {
    var d = JSON.parse(txt);
    if (!d || typeof d !== "object" || typeof d.success === "undefined") throw new Error("bad response");
    return d;
}
function licenseWithTimeout(p) {
    return new Promise(function (res, rej) {
        var t = setTimeout(function () { rej(new Error("timeout")); }, LICENSE_TIMEOUT_MS + 2000);
        p.then(function (v) { clearTimeout(t); res(v); }, function (e) { clearTimeout(t); rej(e); });
    });
}
function licenseViaFetch(body) {
    if (typeof fetch !== "function") return Promise.reject(new Error("no fetch"));
    return fetch(GUMROAD_VERIFY_URL, {
        method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: body
    }).then(function (r) { return r.text(); }).then(parseGumroad);
}
function licenseViaXHR(body) {
    return new Promise(function (res, rej) {
        try {
            var x = new XMLHttpRequest();
            x.open("POST", GUMROAD_VERIFY_URL, true);
            x.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            x.timeout = LICENSE_TIMEOUT_MS;
            x.onload = function () { try { res(parseGumroad(x.responseText)); } catch (e) { rej(e); } };
            x.onerror = x.ontimeout = function () { rej(new Error("xhr")); };
            x.send(body);
        } catch (e) { rej(e); }
    });
}
function licenseNodeRequire() {
    try { if (typeof cep_node !== "undefined" && cep_node.require) return cep_node.require; } catch (e) {}
    try { if (typeof require === "function") return require; } catch (e) {}
    return null;
}
function licenseViaNode(body) {
    return new Promise(function (res, rej) {
        var req = licenseNodeRequire();
        if (!req) { rej(new Error("no node")); return; }
        try {
            var r = req("https").request({
                hostname: "api.gumroad.com", path: "/v2/licenses/verify", method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded", "Content-Length": body.length }
            }, function (resp) {
                var chunks = "";
                resp.setEncoding("utf8");
                resp.on("data", function (c) { chunks += c; });
                resp.on("end", function () { try { res(parseGumroad(chunks)); } catch (e) { rej(e); } });
            });
            r.on("error", function (e) { rej(e); });
            r.setTimeout(LICENSE_TIMEOUT_MS, function () { r.abort(); rej(new Error("timeout")); });
            r.write(body);
            r.end();
        } catch (e) { rej(e); }
    });
}
function licenseViaCurl(key) {
    return new Promise(function (res, rej) {
        if (typeof CSInterface === "undefined") { rej(new Error("no host")); return; }
        if (!/^[A-Za-z0-9-]+$/.test(key)) { rej(new Error("key chars")); return; }
        var win = /win/i.test(navigator.platform || "");
        var cmd = (win ? "curl.exe" : "/usr/bin/curl") + " -sS -m 20 -X POST " + GUMROAD_VERIFY_URL +
            " -d product_id=" + encodeURIComponent(CONFIG.GUMROAD_PRODUCT_ID) +
            " -d license_key=" + key + " -d increment_uses_count=true";
        var es = "try{system.callSystem(" + JSON.stringify(cmd) + ")}catch(e){\"ERR:\"+e}";
        try {
            new CSInterface().evalScript(es, function (out) {
                var s = String(out || ""), i = s.indexOf("{");
                if (i < 0) { rej(new Error("curl")); return; }
                try { res(parseGumroad(s.slice(i))); } catch (e) { rej(e); }
            });
        } catch (e) { rej(e); }
    });
}

function verifyLicenseWithGumroad(key, callback) {
    var trimmedKey = String(key || "").replace(/\s+/g, "");
    if (!trimmedKey) { callback({ success: false, message: "Enter a license key first." }); return; }
    if (!CONFIG.GUMROAD_PRODUCT_ID) {
        callback({ success: false, message: "License verification isn't set up yet — contact support." });
        return;
    }
    var body = "product_id=" + encodeURIComponent(CONFIG.GUMROAD_PRODUCT_ID) +
        "&license_key=" + encodeURIComponent(trimmedKey) +
        "&increment_uses_count=true";
    var routes = [
        function () { return licenseViaFetch(body); },
        function () { return licenseViaXHR(body); },
        function () { return licenseViaNode(body); },
        function () { return licenseViaCurl(trimmedKey); }
    ];
    var i = 0;
    function next() {
        if (i >= routes.length) return Promise.reject(new Error("offline"));
        var r = routes[i++];
        return licenseWithTimeout(r()).then(null, next);
    }
    next().then(function (data) {
        if (data && data.success) {
            callback({ success: true });
        } else {
            callback({ success: false, message: (data && data.message) || "That license key isn't valid for CreatorStash." });
        }
    }, function () {
        callback({ success: false, message: "Couldn't reach Gumroad. A firewall, antivirus, VPN or proxy may be blocking Adobe. Allow it and try again, or email kreevoassets@gmail.com." });
    });
}

var DATA = {
    // Names for the files that arrived with unreadable filenames (Cyrillic
    // characters got stripped to underscores somewhere before upload —
    // that's data loss at the filesystem level, not something a
    // translation step could recover) are best-guess descriptions from
    // analysing each clip's audio (duration, brightness, attack shape),
    // not a literal translation of the lost original name. Two clips
    // (Buildup, Drop Down) kept readable names; one (Counter Tick) had a
    // usable ID3 title tag ("10 счетчик" = "10 counter"). Rename any of
    // these freely — it's just a label, doesn't touch the audio file.
    sfx: [
        { name: "Swipe Tick", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/swipe-tick.mp3" },
        { name: "Static Swipe", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/static-swipe.mp3" },
        { name: "Swipe Rise", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/swipe-rise.mp3" },
        { name: "Swoosh Short", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/swoosh-short.mp3" },
        { name: "Quick Click", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/quick-click.mp3" },
        { name: "Whoosh In", tier: "free", addedDate: "2026-08-11", file: "assets/sfx/whoosh-in.mp3" },
        { name: "UI Tap", tier: "free", addedDate: "2026-08-11", file: "assets/sfx/ui-tap.mp3" },
        { name: "Counter Tick", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/counter-tick.mp3" },
        { name: "Buildup", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/buildup.mp3" },
        { name: "Drop Down", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/drop-down.mp3" },
        { name: "iPhone Power Off", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/iphone-off.mp3" },
        { name: "Page Turn", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/page-turn.mp3" },
        { name: "Pop 011", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/pop-011.mp3" },
        { name: "Pop One", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/pop-1.mp3" },
        { name: "Pop Sparkles Up", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/pop-sparkles-up.wav" },
        { name: "Gears", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/gears.mp3" },
        { name: "Data Processing Error", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/data-processing-error.mp3" },
        { name: "Sparkle Pop", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/sparkle-pop.wav" },
        { name: "Sword Slash", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/sword-slash.mp3" },
        { name: "UI Swipe Down", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/ui-swipe-down.mp3" },
        { name: "Snap Tick", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/snap-tick.mp3" },
        { name: "Soft Pop", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/soft-pop.mp3" },
        { name: "Chime Tone", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/chime-tone.mp3" },
        { name: "Build Swell", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/build-swell.mp3" },
        { name: "Swoosh Bright", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/swoosh-bright.mp3" },
        { name: "Air Swipe", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/air-swipe.mp3" },
        { name: "Quick Tap", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/quick-tap.mp3" },
        { name: "Paper Exit", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/paper-exit.mp3" },
        { name: "Quick Swoosh", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/quick-swoosh.mp3" },
        { name: "Long Swoosh", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/long-swoosh.mp3" },
        { name: "Ambient Texture", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/ambient-texture.mp3" },
        { name: "Keyboard Typing", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/keyboard-typing.mp3" },
        { name: "Micro Click", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/micro-click.mp3" },
        { name: "Soft Impact", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/soft-impact.mp3" },
        { name: "Tone Hit", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/tone-hit.mp3" },
        { name: "Big Whoosh", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/big-whoosh.mp3" },
        { name: "UI Appear Click", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/ui-appear-click.mp3" },
        { name: "Low Thud", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/low-thud.mp3" },
        { name: "Deep Tone", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/deep-tone.mp3" },
        { name: "Swoosh Fade", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/swoosh-fade.mp3" },
        { name: "Impact Whoosh", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/impact-whoosh.mp3" },
        { name: "Quick Swipe", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/quick-swipe.mp3" },
        { name: "Snap Click", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/snap-click.mp3" },
        { name: "Tap Click", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/tap-click.mp3" },
        { name: "Rise Tick", tier: "premium", addedDate: "2026-08-11", file: "assets/sfx/rise-tick.mp3" }
    ],
    lut: [
        { name: "Cinematic Film", tier: "free", addedDate: "2026-08-11", file: "assets/luts/cinematic-film.cube", preview: "assets/lut-previews/cinematic-film.png" },
        { name: "VisionColor M31", tier: "premium", addedDate: "2026-08-11", file: "assets/luts/visioncolor-m31.cube", preview: "assets/lut-previews/visioncolor-m31.png" },
        { name: "Aqua", tier: "free", addedDate: "2026-08-11", file: "assets/luts/aqua.cube", preview: "assets/lut-previews/aqua.png" },
        { name: "Fire", tier: "free", addedDate: "2026-08-11", file: "assets/luts/fire.cube", preview: "assets/lut-previews/fire.png" },
        { name: "Like Portra", tier: "free", addedDate: "2026-08-11", file: "assets/luts/like-portra.cube", preview: "assets/lut-previews/like-portra.png" },
        { name: "Log Aqua", tier: "premium", addedDate: "2026-08-11", file: "assets/luts/log-aqua.cube", preview: "assets/lut-previews/log-aqua.png" },
        { name: "Log Fire", tier: "premium", addedDate: "2026-08-11", file: "assets/luts/log-fire.cube", preview: "assets/lut-previews/log-fire.png" },
        { name: "Log Pine", tier: "premium", addedDate: "2026-08-11", file: "assets/luts/log-pine.cube", preview: "assets/lut-previews/log-pine.png" },
        { name: "Pine", tier: "free", addedDate: "2026-08-11", file: "assets/luts/pine.cube", preview: "assets/lut-previews/pine.png" },
        { name: "Wave", tier: "free", addedDate: "2026-08-11", file: "assets/luts/wave.cube", preview: "assets/lut-previews/wave.png" }
    ],
    // Every entry here is a declarative animation spec, not a pre-rendered
    // file — there's no such thing as a "buildable" .ffx/.mogrt without a
    // live AE/Premiere session to render through, so instead each preset
    // is applied live: click Apply, and js/apply-engine.js turns the spec
    // below into ExtendScript run against whatever's selected in the host
    // via CSInterface.evalScript. See apply-engine.js for the full
    // mechanism list and exactly which AE API each one calls.
    text: [
        // Per-character / per-word Text Animator presets (mechanism
        // "animator", see buildAnimatorJSX_AE in js/apply-engine.js) —
        // the same Expression Selector approach MotionType ships with.
        // The card preview in the panel plays the same spec.
        { name: "Pop Up", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "bounce", delay: 0.035, dur: 0.5, amount: 0, blur: 0, a: { scale: 0, op: true } },
        { name: "Bounce In", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "bounce", delay: 0.04, dur: 0.55, amount: 40, blur: 0, a: { pos: [0, 1], scale: 85, op: true } },
        { name: "Apple Fade", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "word", mode: "smooth", delay: 0.08, dur: 0.9, amount: 0, blur: 14, a: { scale: 104, op: true } },
        { name: "Slide Up", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "word", mode: "smooth", delay: 0.07, dur: 0.6, amount: 50, blur: 4, a: { pos: [0, 1], op: true } },
        { name: "Slide Side", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "word", mode: "smooth", delay: 0.07, dur: 0.6, amount: 60, blur: 4, a: { pos: [-1, 0], op: true } },
        { name: "Rotate In", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "smooth", delay: 0.035, dur: 0.55, amount: 0, blur: 2, a: { rot: -25, scale: 80, op: true } },
        { name: "Shake Pop", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "bounce", delay: 0.03, dur: 0.5, amount: 0, blur: 0, a: { scale: 0, rot: -12, op: true } },
        { name: "Drop In", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "bounce", delay: 0.04, dur: 0.6, amount: 90, blur: 0, a: { pos: [0, -1], op: true } },
        { name: "Punch Scale", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "line", mode: "punch", delay: 0, dur: 0.35, amount: 0, blur: 0, a: { scale: 122 } },
        { name: "Blur Fade", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "smooth", delay: 0.03, dur: 0.7, amount: 0, blur: 40, a: { op: true } },
        { name: "Flip In", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "smooth", delay: 0.04, dur: 0.5, amount: 0, blur: 0, a: { scale: [100, 0], op: true } },
        { name: "Typewriter", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "hold", delay: 0.05, dur: 0.01, amount: 0, blur: 0, a: { op: true } },
        { name: "Karaoke Highlight", tier: "premium", addedDate: "2026-08-11", mechanism: "karaoke" },
        { name: "Letter Cascade", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "smooth", delay: 0.04, dur: 0.5, amount: 30, blur: 6, a: { pos: [0, 1], op: true } },
        { name: "Character Pop", tier: "premium", addedDate: "2026-08-11", mechanism: "animator",
          unit: "letter", mode: "bounce", delay: 0.04, dur: 0.5, amount: 0, blur: 0, a: { scale: 140, op: true } },
        // Real .ffx presets, built inside actual After Effects — applied
        // via layer.applyPreset(). "preview" is only for the panel card.
        { name: "Apple Text 1", tier: "free", addedDate: "2026-08-12", mechanism: "ffxPreset", ffxFile: "assets/ffx-presets/apple-text-1.ffx",
          preview: { unit: "word", mode: "smooth", delay: 0.08, dur: 0.9, amount: 0, blur: 12, a: { op: true } } },
        { name: "Apple Text 2", tier: "premium", addedDate: "2026-08-12", mechanism: "ffxPreset", ffxFile: "assets/ffx-presets/apple-text-2.ffx",
          preview: { unit: "word", mode: "smooth", delay: 0.08, dur: 0.9, amount: 30, blur: 10, a: { pos: [0, 1], op: true } } },
        { name: "Apple Text 3", tier: "premium", addedDate: "2026-08-12", mechanism: "ffxPreset", ffxFile: "assets/ffx-presets/apple-text-3.ffx",
          preview: { unit: "letter", mode: "smooth", delay: 0.03, dur: 0.8, amount: 0, blur: 14, a: { scale: 110, op: true } } },
        { name: "Apple Text 4", tier: "premium", addedDate: "2026-08-12", mechanism: "ffxPreset", ffxFile: "assets/ffx-presets/apple-text-4.ffx",
          preview: { unit: "line", mode: "smooth", delay: 0, dur: 1.0, amount: 0, blur: 16, a: { scale: 106, op: true } } },
        { name: "Apple Bounce 1", tier: "premium", addedDate: "2026-08-12", mechanism: "ffxPreset", ffxFile: "assets/ffx-presets/apple-bounce-1.ffx",
          preview: { unit: "word", mode: "bounce", delay: 0.08, dur: 0.7, amount: 30, blur: 4, a: { pos: [0, 1], op: true } } },
        { name: "Apple Bounce 2", tier: "premium", addedDate: "2026-08-12", mechanism: "ffxPreset", ffxFile: "assets/ffx-presets/apple-bounce-2.ffx",
          preview: { unit: "letter", mode: "bounce", delay: 0.035, dur: 0.6, amount: 0, blur: 2, a: { scale: 60, op: true } } }
    ],
    transitions: [
        { name: "Zoom Punch In", tier: "free", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Scale", keys: [ { t: 0, v: [130, 130] }, { t: 0.16, v: [97, 97] }, { t: 0.24, v: [100, 100] } ] },
              { prop: "Opacity", keys: [ { t: 0, v: 0 }, { t: 0.06, v: 100 } ] }
          ] },
        { name: "Whip Pan Left", tier: "free", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Position", keys: [ { t: 0, v: [280, 0] }, { t: 0.18, v: [0, 0] } ] }
          ],
          effects: [
              { name: "Directional Blur", prop: "Blur Length", keys: [ { t: 0, v: 40 }, { t: 0.18, v: 0 } ] }
          ] },
        { name: "Whip Pan Right", tier: "free", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Position", keys: [ { t: 0, v: [-280, 0] }, { t: 0.18, v: [0, 0] } ] }
          ],
          effects: [
              { name: "Directional Blur", prop: "Blur Length", keys: [ { t: 0, v: 40 }, { t: 0.18, v: 0 } ] }
          ] },
        { name: "Camera Shake Zoom", tier: "premium", addedDate: "2026-08-11", mechanism: "transform", shakeExpression: true,
          anim: [
              { prop: "Scale", keys: [ { t: 0, v: [112, 112] }, { t: 0.2, v: [100, 100] } ] },
              { prop: "Opacity", keys: [ { t: 0, v: 0 }, { t: 0.05, v: 100 } ] }
          ] },
        { name: "Spin In", tier: "premium", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Rotation", keys: [ { t: 0, v: -540 }, { t: 0.3, v: 0 } ] },
              { prop: "Scale", keys: [ { t: 0, v: [40, 40] }, { t: 0.3, v: [100, 100] } ] },
              { prop: "Opacity", keys: [ { t: 0, v: 0 }, { t: 0.08, v: 100 } ] }
          ] },
        { name: "Flash In", tier: "free", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Opacity", keys: [ { t: 0, v: 0 }, { t: 0.04, v: 100 }, { t: 0.09, v: 55 }, { t: 0.14, v: 100 } ] }
          ] },
        { name: "Slide Cut", tier: "free", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Position", keys: [ { t: 0, v: [360, 0] }, { t: 0.2, v: [-14, 0] }, { t: 0.28, v: [0, 0] } ] }
          ] },
        { name: "Glitch Punch", tier: "premium", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Position", keys: [ { t: 0, v: [18, 4] }, { t: 0.04, v: [-14, -6] }, { t: 0.08, v: [10, 3] }, { t: 0.12, v: [-6, 2] }, { t: 0.16, v: [0, 0] } ] },
              { prop: "Scale", keys: [ { t: 0, v: [102, 102] }, { t: 0.16, v: [100, 100] } ] }
          ] },
        { name: "Elastic Zoom", tier: "free", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Scale", keys: [ { t: 0, v: [0, 0] }, { t: 0.16, v: [112, 112] }, { t: 0.24, v: [94, 94] }, { t: 0.3, v: [103, 103] }, { t: 0.36, v: [100, 100] } ] },
              { prop: "Opacity", keys: [ { t: 0, v: 0 }, { t: 0.06, v: 100 } ] }
          ] },
        { name: "Drop Impact", tier: "premium", addedDate: "2026-08-11", mechanism: "transform",
          anim: [
              { prop: "Position", keys: [ { t: 0, v: [0, -160] }, { t: 0.18, v: [0, 10] }, { t: 0.24, v: [0, 0] } ] },
              { prop: "Scale", keys: [ { t: 0, v: [100, 110] }, { t: 0.18, v: [108, 88] }, { t: 0.26, v: [100, 100] } ] },
              { prop: "Opacity", keys: [ { t: 0, v: 0 }, { t: 0.05, v: 100 } ] }
          ] }
    ]
};

var TAB_LABELS = { sfx: "SFX", lut: "LUT", text: "Text", transitions: "Transitions" };

var activeTab = "sfx";
var activeFilter = "all"; // "all" | "free" | "premium" | "favorites"
var searchQuery = "";

var sidebar = document.getElementById("sidebar");
var grid = document.getElementById("grid");
var searchInput = document.getElementById("search");
var emptyState = document.getElementById("emptyState");
var chipsEl = document.getElementById("chips");

// ---------------------------------------------------------------
// HOST DETECTION — Text presets are AE-only for now (Premiere's
// reliable text mechanism needs real .mogrt template files that don't
// exist yet; see apply-engine.js). Rather than let a Premiere user
// click into a Text tab full of presets that will just error out one
// by one, the tab itself is hidden on that host — same "AE only"
// scope decision LUT/Transitions already got earlier, now host-aware
// instead of blanket-hidden.
// ---------------------------------------------------------------
var CURRENT_HOST = "";
try {
    if (typeof CSInterface !== "undefined") {
        CURRENT_HOST = new CSInterface().getHostEnvironment().appId;
    }
} catch (eHostDetect) {}

// ---------------------------------------------------------------
// FAVORITES — persisted locally (per machine) so they survive closing
// and reopening the panel. Keyed by "tab::name" since placeholder names
// repeat across tabs (e.g. "Whoosh In" exists in both sfx and
// transitions) and need to stay independently favoritable.
// ---------------------------------------------------------------
var FAVORITES_KEY = "creatorstash_favorites";

function loadFavorites() {
    try {
        var raw = localStorage.getItem(FAVORITES_KEY);
        return raw ? JSON.parse(raw) : {};
    } catch (e) {
        return {};
    }
}

function saveFavorites(favs) {
    try { localStorage.setItem(FAVORITES_KEY, JSON.stringify(favs)); } catch (e) {}
}

var favorites = loadFavorites();

function itemKey(type, item) { return type + "::" + item.name; }

function isNewItem(item) {
    if (!item.addedDate) return false;
    var added = new Date(item.addedDate + "T00:00:00");
    var diffDays = (Date.now() - added.getTime()) / 86400000;
    return diffDays >= 0 && diffDays <= CONFIG.NEW_BADGE_DAYS;
}

function waveformBars() {
    // A fixed, deliberately non-random pattern so every SFX card's
    // placeholder waveform looks the same until real audio is analysed.
    var heights = [40, 70, 100, 60, 85, 45, 75, 55];
    var html = "";
    for (var i = 0; i < heights.length; i++) {
        html += '<span style="height:' + heights[i] + '%"></span>';
    }
    return html;
}

// Preview (Play) always stays free across every tier — hearing/seeing a
// preset before buying is the whole point of a preview. Only the action
// that actually PUTS the preset to use (Apply/Import) is gated, so a
// premium item's button is still clickable but visually dimmed and
// wired (in render()/expandCard()) to prompt a purchase instead of
// running the real script.
function isLocked(item) {
    return item.tier === "premium" && LICENSE_STATUS !== "licensed";
}

function showLockedToast(item) {
    var hasPurchaseUrl = !!CONFIG.PURCHASE_URL;
    var msg = "🔒 “" + item.name + "” is a Premium item" +
        (hasPurchaseUrl ? " — tap to buy CreatorStash" : " — purchasing isn’t set up yet.") +
        "\nAlready bought it? Enter your license key under ⚙️ Settings.";
    showToast(msg, true, 0, hasPurchaseUrl ? function () { openExternal(CONFIG.PURCHASE_URL); } : null);
}

function cardPreviewHTML(type, item) {
    var lockedClass = isLocked(item) ? " locked" : "";
    if (type === "sfx") {
        return (
            '<div class="card-preview preview-sfx">' +
                '<div class="waveform">' + waveformBars() + '</div>' +
                '<div class="play-btn" title="Preview" aria-label="Preview">' +
                    '<svg width="10" height="10" viewBox="0 0 10 10"><polygon points="1,0 10,5 1,10"/></svg>' +
                '</div>' +
                '<div class="import-btn' + lockedClass + '" title="Add to Project panel" aria-label="Add to Project panel">' +
                    '<svg width="11" height="11" viewBox="0 0 16 16" fill="none"><path d="M8 2v8m0 0 3-3m-3 3L5 7M3 13h10" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                '</div>' +
            '</div>'
        );
    }
    if (type === "lut") {
        return (
            '<div class="card-preview preview-lut">' +
                '<img src="' + item.preview + '" alt="" draggable="false">' +
                '<div class="apply-btn' + lockedClass + '" title="Load this LUT onto the selected layer" aria-label="Load this LUT onto the selected layer">' +
                    '<svg width="11" height="11" viewBox="0 0 16 16" fill="none"><path d="M3 8.5 6.5 12 13 4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                '</div>' +
            '</div>'
        );
    }
    // Text presets: a real sample word that plays the preset's own
    // animation on hover (see js/preview.js). Transitions keep the
    // generic mini-motion shape. Both get the Apply button that runs the
    // preset's ExtendScript (see js/apply-engine.js).
    if (type === "text") {
        return (
            '<div class="card-preview preview-anim preview-text">' +
                '<div class="pt-text"></div>' +
                '<div class="apply-btn' + lockedClass + '" title="Apply to selected text layers" aria-label="Apply to selected text layers">' +
                    '<svg width="11" height="11" viewBox="0 0 16 16" fill="none"><path d="M3 8.5 6.5 12 13 4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                '</div>' +
            '</div>'
        );
    }
    return (
        '<div class="card-preview preview-anim">' +
            '<div class="anim-shape"></div>' +
            '<div class="apply-btn' + lockedClass + '" title="Apply to selected layer" aria-label="Apply to selected layer">' +
                '<svg width="11" height="11" viewBox="0 0 16 16" fill="none"><path d="M3 8.5 6.5 12 13 4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            '</div>' +
        '</div>'
    );
}

function starButtonHTML(key) {
    var favClass = favorites[key] ? " favorited" : "";
    return (
        '<button class="card-star' + favClass + '" data-key="' + key + '" title="Favorite" aria-label="Favorite">' +
            '<svg width="11" height="11" viewBox="0 0 16 16" fill="currentColor"><path d="M8 1.5l1.98 4.42 4.85.5-3.65 3.28 1.03 4.8L8 12.1l-4.21 2.4 1.03-4.8L1.17 6.42l4.85-.5z"/></svg>' +
        '</button>'
    );
}

function toggleFavorite(key) {
    favorites[key] = !favorites[key];
    if (!favorites[key]) delete favorites[key];
    saveFavorites(favorites);
}

// ---------------------------------------------------------------
// SFX PLAYBACK — only one preview plays at a time (starting a new one
// stops whatever was already playing), matching how every other sample
// library does it, so previews don't stack into noise.
// ---------------------------------------------------------------
var currentAudio = null;
var currentPlayingPreview = null;

function stopCurrentAudio() {
    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
    }
    if (currentPlayingPreview) currentPlayingPreview.classList.remove("playing");
    currentAudio = null;
    currentPlayingPreview = null;
}

function playSfx(item, previewEl) {
    if (currentPlayingPreview === previewEl) {
        // Clicking the button on the clip that's already playing stops it.
        stopCurrentAudio();
        return;
    }
    stopCurrentAudio();
    if (!item.file) return;

    var audio = new Audio(item.file);
    currentAudio = audio;
    currentPlayingPreview = previewEl;
    previewEl.classList.add("playing");

    audio.addEventListener("ended", function () {
        if (currentAudio === audio) stopCurrentAudio();
    });
    var playPromise = audio.play();
    if (typeof trackSfxProgress === "function") trackSfxProgress(audio, previewEl);
    playPromise.catch(function () {
        // Missing/blocked playback — fail quietly rather than throw, same
        // defensive pattern used everywhere else in this file.
        if (currentAudio === audio) stopCurrentAudio();
    });
}

// ---- Apple-style expand interaction ----
// Clicking a card scales it up from its exact grid position to a larger,
// centred card with a dimmed, blurred backdrop, then reverses on close.
//
// Built with the FLIP technique so the only animated CSS property is
// `transform` (plus `opacity` on the backdrop): the clone's real box
// (left/top/width/height) is set ONCE, immediately, to its final
// expanded position — never transitioned — then a transform is applied
// that visually squashes it back onto the original card's position and
// size, and THAT transform is what animates back to identity. Because
// transform/opacity are compositor-only properties, the browser never
// re-runs layout on any frame of the animation, which was the actual
// source of a stutter reported earlier (animating left/top/width/height
// forces a full document layout pass every frame, not scoped to the
// one moving element).
var EXPAND_MS = 240;

function expandCard(cardEl, type, item) {
    var rect = cardEl.getBoundingClientRect();

    var overlay = document.createElement("div");
    overlay.className = "expand-overlay";
    document.body.appendChild(overlay);

    var clone = cardEl.cloneNode(true);
    clone.classList.add("card-expanded");
    document.body.appendChild(clone);

    var targetW = Math.min(window.innerWidth - 48, 300);
    var targetH = Math.min(window.innerHeight - 80, 220);
    var targetLeft = (window.innerWidth - targetW) / 2;
    var targetTop = (window.innerHeight - targetH) / 2;

    // Real final box, set once — not animated.
    clone.style.left = targetLeft + "px";
    clone.style.top = targetTop + "px";
    clone.style.width = targetW + "px";
    clone.style.height = targetH + "px";

    var scaleX = rect.width / targetW;
    var scaleY = rect.height / targetH;
    var startTransform = "translate(" + (rect.left - targetLeft) + "px, " + (rect.top - targetTop) + "px) scale(" + scaleX + ", " + scaleY + ")";
    var endTransform = "translate(0px, 0px) scale(1, 1)";

    // Make the full-size clone LOOK like it's still at the original
    // card's position/size before anything is visible...
    clone.style.transform = startTransform;

    void clone.offsetWidth; // force the browser to apply that start state before animating

    requestAnimationFrame(function () {
        overlay.classList.add("visible");
        clone.style.transform = endTransform; // ...then animate the transform to identity = grows into place.
    });

    function close() {
        overlay.classList.remove("visible");
        clone.style.transform = startTransform;
        if (currentPlayingPreview === clone.querySelector(".preview-sfx")) stopCurrentAudio();
        setTimeout(function () {
            overlay.remove();
            clone.remove();
        }, EXPAND_MS);
    }

    overlay.addEventListener("click", close);
    clone.addEventListener("click", close);

    // cloneNode(true) copies markup but never event listeners, so the
    // play button, import button, favorite star, and apply button all
    // need their handlers re-wired on the clone specifically.
    if (type === "sfx") {
        var playBtn = clone.querySelector(".play-btn");
        if (playBtn) {
            playBtn.style.opacity = "1";
            playBtn.style.transform = "scale(1)";
            playBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                playSfx(item, clone.querySelector(".preview-sfx"));
            });
        }
        var importBtn = clone.querySelector(".import-btn");
        if (importBtn) {
            importBtn.style.opacity = "1";
            importBtn.style.transform = "scale(1)";
            importBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                if (isLocked(item)) { showLockedToast(item); return; }
                importSfx(item);
            });
        }
    }

    if (type === "text" || type === "transitions") {
        var applyBtn = clone.querySelector(".apply-btn");
        if (applyBtn) {
            applyBtn.style.opacity = "1";
            applyBtn.style.transform = "scale(1)";
            applyBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                if (isLocked(item)) { showLockedToast(item); return; }
                applyPreset(item, type);
            });
        }
    }

    if (type === "lut") {
        var lutApplyBtn = clone.querySelector(".apply-btn");
        if (lutApplyBtn) {
            lutApplyBtn.style.opacity = "1";
            lutApplyBtn.style.transform = "scale(1)";
            lutApplyBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                if (isLocked(item)) { showLockedToast(item); return; }
                applyLut(item);
            });
        }
    }

    var starBtn = clone.querySelector(".card-star");
    if (starBtn) {
        starBtn.addEventListener("click", function (e) {
            e.stopPropagation();
            var k = this.getAttribute("data-key");
            toggleFavorite(k);
            this.classList.toggle("favorited");
            // Keep the grid's own star in sync without a full re-render —
            // render() would rebuild the grid out from under this still-
            // open expanded clone.
            var gridStar = grid.querySelector('.card-star[data-key="' + CSS.escape(k) + '"]');
            if (gridStar) gridStar.classList.toggle("favorited", !!favorites[k]);
        });
    }
}

function render() {
    var items = DATA[activeTab] || [];

    var q = searchQuery.trim().toLowerCase();
    if (q) {
        items = items.filter(function (item) {
            return item.name.toLowerCase().indexOf(q) !== -1;
        });
    }
    if (activeFilter === "free") {
        items = items.filter(function (item) { return item.tier === "free"; });
    } else if (activeFilter === "premium") {
        items = items.filter(function (item) { return item.tier === "premium"; });
    } else if (activeFilter === "favorites") {
        items = items.filter(function (item) { return !!favorites[itemKey(activeTab, item)]; });
    }

    grid.innerHTML = "";
    for (var i = 0; i < items.length; i++) {
        // `let`, not `var`: the play/expand click handlers below close
        // over `item`, and `var` is function-scoped, not per-iteration —
        // every card's handler would end up sharing the SAME `item`
        // binding and firing with whatever the LAST loop iteration left
        // it as (confirmed: clicking the first card played the last
        // card's audio). `let` gives each iteration its own binding.
        let item = items[i];
        var key = itemKey(activeTab, item);
        var card = document.createElement("div");
        card.className = "card";
        var badgeHTML = isNewItem(item) ? '<span class="card-badge-new">New</span>' : "";
        var proTagHTML = item.tier === "premium" ? '<span class="tier-tag">PRO</span>' : "";
        card.innerHTML = badgeHTML + starButtonHTML(key) + cardPreviewHTML(activeTab, item) +
            '<div class="card-name"><span class="card-name-text">' + item.name + '</span>' + proTagHTML + '</div>';

        if (activeTab === "text" && typeof setupTextCardPreview === "function") setupTextCardPreview(card, item);
        if (activeTab === "sfx" && typeof setupSfxCardPreview === "function") setupSfxCardPreview(card, item);

        var starBtn = card.querySelector(".card-star");
        starBtn.addEventListener("click", function (e) {
            e.stopPropagation();
            var k = this.getAttribute("data-key");
            toggleFavorite(k);
            this.classList.toggle("favorited");
            if (activeFilter === "favorites") render(); // drop it from the list immediately
        });

        if (activeTab === "sfx") {
            var playBtn = card.querySelector(".play-btn");
            playBtn.addEventListener("click", function (e) {
                // Play button has its own job (play/stop the clip) and
                // shouldn't also trigger the card's expand animation.
                e.stopPropagation();
                playSfx(item, this.closest(".preview-sfx"));
            });
        }

        if (activeTab === "sfx") {
            // Native HTML5 drag-out (webview -> host's native timeline
            // panel) turned out not to work reliably in real testing —
            // dropping across that CEP/native boundary depends on engine
            // internals this build can't guarantee. importSfx() below
            // uses plain ExtendScript file import instead — the same
            // proven app.project.importFile()/importFiles() call already
            // used elsewhere — which lands the file in the host's own
            // Project panel. From there, dragging onto the timeline is a
            // native-to-native drag inside the host itself, so it always
            // works exactly the way every other imported asset does.
            var importBtn = card.querySelector(".import-btn");
            importBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                if (isLocked(item)) { showLockedToast(item); return; }
                importSfx(item);
            });
        }

        if (activeTab === "text" || activeTab === "transitions") {
            var applyBtn = card.querySelector(".apply-btn");
            applyBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                if (isLocked(item)) { showLockedToast(item); return; }
                applyPreset(item, activeTab);
            });
        }

        if (activeTab === "lut") {
            var lutApplyBtn = card.querySelector(".apply-btn");
            lutApplyBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                if (isLocked(item)) { showLockedToast(item); return; }
                applyLut(item);
            });
        }

        card.addEventListener("click", function () {
            expandCard(this, activeTab, item);
        });

        grid.appendChild(card);
    }

    emptyState.hidden = items.length !== 0;
    emptyState.textContent = (activeFilter === "favorites")
        ? "No favorites yet in " + TAB_LABELS[activeTab] + " — tap the star on a card to add one."
        : "No items match your search.";
}

sidebar.addEventListener("click", function (e) {
    var btn = e.target.closest(".tab");
    if (!btn) return;
    var tabs = sidebar.querySelectorAll(".tab");
    for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove("active");
    btn.classList.add("active");
    activeTab = btn.getAttribute("data-tab");
    searchInput.placeholder = "Search " + TAB_LABELS[activeTab] + "…";
    render();
});

// Text tab hidden on Premiere — see the CURRENT_HOST comment above for
// why. AE (or an undetected host, so the tab isn't hidden on a false
// negative) still shows it normally.
if (CURRENT_HOST === "PPRO") {
    var textTabBtn = sidebar.querySelector('[data-tab="text"]');
    if (textTabBtn) {
        textTabBtn.setAttribute("hidden", "");
        if (activeTab === "text") {
            activeTab = "sfx";
            var sfxTabBtn = sidebar.querySelector('[data-tab="sfx"]');
            if (sfxTabBtn) {
                textTabBtn.classList.remove("active");
                sfxTabBtn.classList.add("active");
            }
        }
    }
}

searchInput.addEventListener("input", function () {
    searchQuery = searchInput.value;
    render();
});

chipsEl.addEventListener("click", function (e) {
    var btn = e.target.closest(".chip");
    if (!btn) return;
    var chips = chipsEl.querySelectorAll(".chip");
    for (var i = 0; i < chips.length; i++) chips[i].classList.remove("active");
    btn.classList.add("active");
    activeFilter = btn.getAttribute("data-filter");
    render();
});

// ---------------------------------------------------------------
// LICENSE STATUS BADGE + SETTINGS MENU LICENSE SECTION
// ---------------------------------------------------------------
var tierBadge = document.getElementById("tierBadge");
var buyLink = document.getElementById("buyLink");
var licenseSection = document.getElementById("licenseSection");
var licenseInput = document.getElementById("licenseInput");
var licenseActivateBtn = document.getElementById("licenseActivateBtn");
var licenseStatusMsg = document.getElementById("licenseStatusMsg");

function refreshLicenseUI() {
    if (LICENSE_STATUS === "licensed") {
        tierBadge.textContent = "Licensed";
        tierBadge.classList.add("licensed");
        buyLink.hidden = true;
        licenseSection.hidden = true;
    } else {
        tierBadge.textContent = "Free tier";
        tierBadge.classList.remove("licensed");
        buyLink.hidden = !CONFIG.PURCHASE_URL;
        licenseSection.hidden = false;
    }
}
refreshLicenseUI();

buyLink.addEventListener("click", function (e) {
    e.preventDefault();
    if (CONFIG.PURCHASE_URL) openExternal(CONFIG.PURCHASE_URL);
});

licenseActivateBtn.addEventListener("click", function () {
    var key = licenseInput.value;
    licenseActivateBtn.disabled = true;
    licenseStatusMsg.textContent = "Verifying with Gumroad…";
    licenseStatusMsg.className = "license-status-msg";
    verifyLicenseWithGumroad(key, function (result) {
        licenseActivateBtn.disabled = false;
        if (result.success) {
            LICENSE_STATUS = "licensed";
            saveLicenseState("licensed", key.replace(/^\s+|\s+$/g, ""));
            licenseStatusMsg.textContent = "Activated ✓";
            licenseStatusMsg.className = "license-status-msg ok";
            refreshLicenseUI();
            render(); // unlock every premium card's Apply/Import right away
        } else {
            licenseStatusMsg.textContent = result.message;
            licenseStatusMsg.className = "license-status-msg err";
        }
    });
});

// ---------------------------------------------------------------
// SETTINGS MENU / SUPPORT LINK
// ---------------------------------------------------------------
var settingsBtn = document.getElementById("settingsBtn");
var settingsMenu = document.getElementById("settingsMenu");
var supportLink = document.getElementById("supportLink");

// mailto: links turned out unreliable two ways in a row: a plain <a
// href="mailto:..."> navigates CEP's own embedded browser, which
// doesn't know that scheme and breaks the WHOLE PANEL ("Page failed to
// load / ERR_UNKNOWN_URL_SCHEME", confirmed via a real screenshot).
// Routing it through openExternal() instead stopped the crash, but a
// real test then showed it just opens the OS's default BROWSER (Opera)
// to its home page — mailto: isn't a browser thing, and evidently
// nothing on that system routes it on to an actual mail client either.
// Two different failure modes on two different mechanisms is enough to
// stop trying to "launch" anything here — same lesson already learned
// with LUT paths: copy the email to the clipboard instead (the one
// mechanism that's already proven itself reliable in this file) and
// let the person paste it into whatever mail app/client they use.
supportLink.addEventListener("click", function (e) {
    e.preventDefault();
    var copied = copyToClipboard(CONFIG.SUPPORT_EMAIL);
    showToast(
        copied ? "Support email copied: " + CONFIG.SUPPORT_EMAIL : CONFIG.SUPPORT_EMAIL,
        !copied,
        4200
    );
});

settingsBtn.addEventListener("click", function (e) {
    e.stopPropagation();
    settingsMenu.hidden = !settingsMenu.hidden;
});

document.addEventListener("click", function (e) {
    if (!settingsMenu.hidden && !settingsMenu.contains(e.target) && e.target !== settingsBtn) {
        settingsMenu.hidden = true;
    }
});

// ---------------------------------------------------------------
// AUTO-UPDATE — a single, quiet, one-time check on open. Never on a
// timer, never retried automatically: if the fetch fails (offline,
// GitHub unreachable, the repo/file doesn't exist yet) it just does
// nothing, silently. No self-replacement is attempted — CreatorStash
// is a multi-file extension, so the update button just sends the user
// to the release/download page, which is the reliable option for CEP.
// ---------------------------------------------------------------
function compareVersions(a, b) {
    var pa = String(a).split(".").map(Number);
    var pb = String(b).split(".").map(Number);
    var len = Math.max(pa.length, pb.length);
    for (var i = 0; i < len; i++) {
        var na = pa[i] || 0, nb = pb[i] || 0;
        if (na > nb) return 1;
        if (na < nb) return -1;
    }
    return 0;
}

function openExternal(url) {
    try {
        if (typeof CSInterface !== "undefined") {
            var cs = new CSInterface();
            cs.openURLInDefaultBrowser(url);
            return;
        }
    } catch (e) {}
    // Fallback for testing outside a real CEP host (a plain browser).
    window.open(url, "_blank");
}

function showUpdateBanner(remote) {
    var banner = document.getElementById("updateBanner");
    var text = document.getElementById("updateText");
    var btn = document.getElementById("updateBtn");
    var dismiss = document.getElementById("updateDismiss");

    text.textContent = "Update available — v" + remote.version + (remote.notes ? ": " + remote.notes : "");
    banner.hidden = false;

    btn.onclick = function () {
        openExternal(remote.url || CONFIG.RELEASE_PAGE_URL);
    };
    dismiss.onclick = function () {
        banner.hidden = true;
    };
}

function checkForUpdate() {
    var url = CONFIG.UPDATE_CHECK_URL + (CONFIG.UPDATE_CHECK_URL.indexOf("?") === -1 ? "?" : "&") + "_=" + Date.now();
    fetch(url, { cache: "no-store" })
        .then(function (res) { return res.ok ? res.json() : null; })
        .then(function (remote) {
            if (!remote || !remote.version) return;
            if (compareVersions(remote.version, APP_VERSION) > 0) {
                showUpdateBanner(remote);
            }
        })
        .catch(function () { /* offline or repo not reachable yet — stay silent */ });
}

// Disabled for now — there's only ever been one real version out in the
// world so far, so an "update available" banner has nothing meaningful
// to say yet. The mechanism itself (compareVersions/showUpdateBanner/
// checkForUpdate above) is untouched — flip this back on by calling
// checkForUpdate() once there's an actual second release to point at.
// checkForUpdate();

render();
