@echo off
setlocal
title CreatorStash installer
echo.
echo   ===============================================
echo     CreatorStash by Kreevo - installer (Windows)
echo   ===============================================
echo.
echo   Please close After Effects and Premiere Pro first.
echo.
pause

set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
set "DEST=%APPDATA%\Adobe\CEP\extensions\CreatorStash"

if not exist "%SRC%\CSXS\manifest.xml" (
    echo.
    echo   ERROR: unzip CreatorStash.zip first, then run this file
    echo   from the unzipped folder.
    echo.
    pause
    exit /b 1
)

if /I "%SRC%"=="%DEST%" (
    echo   Already installed in the right place.
    goto debugmode
)

echo   Copying files to:
echo   %DEST%
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%" >nul 2>&1
robocopy "%SRC%" "%DEST%" /E /NFL /NDL /NJH /NJS /NP >nul
if %ERRORLEVEL% GEQ 8 (
    echo.
    echo   ERROR: could not copy the files. Try running this file again,
    echo   or follow the manual steps in INSTALL.txt.
    echo.
    pause
    exit /b 1
)

:debugmode
echo   Enabling PlayerDebugMode...
for %%v in (9 10 11 12) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

echo.
echo   Done! Open After Effects or Premiere Pro and go to:
echo   Window ^> Extensions ^> CreatorStash by Kreevo
echo.
pause
endlocal
