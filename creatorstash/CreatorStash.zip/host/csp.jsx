// CreatorStash - Premiere Pro side of the text presets.
// The panel renders a preset to a transparent PNG sequence; these functions import it and put it at the playhead.
function cspErr(e) { return 'err|' + (e && e.message ? e.message : String(e)); }
function cspJson(o) { var a = []; for (var k in o) { var v = o[k]; a.push('"' + k + '":' + (typeof v === 'number' ? v : '"' + String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"')); } return '{' + a.join(',') + '}'; }
function cspDir() {
  var base = null;
  try { if (app.project.path) { var f = new File(app.project.path); if (f.parent && f.parent.exists) base = f.parent; } } catch (e) {}
  if (!base) base = Folder.myDocuments;
  var d = new Folder(base.fsName + '/CreatorStash Text'); if (!d.exists) d.create();
  return d.fsName;
}
function csp_info() {
  try {
    var seq = app.project.activeSequence; if (!seq) return 'err|Open a sequence first.';
    var fps = 254016000000 / Number(seq.timebase);
    return 'ok|' + cspJson({ w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), fps: Math.round(fps * 1000) / 1000, dir: cspDir() });
  } catch (e) { return cspErr(e); }
}
function cspBin() {
  var root = app.project.rootItem, i;
  for (i = 0; i < root.children.numItems; i++) { var c = root.children[i]; if (c.name === 'CreatorStash Text' && c.type === ProjectItemType.BIN) return c; }
  return root.createBin('CreatorStash Text');
}
function cspFind(bin, name) {
  var stem = name.replace(/_\d+\.png$/i, ''), i, c;
  for (i = bin.children.numItems - 1; i >= 0; i--) { c = bin.children[i]; if (c.name === name) return c; }
  for (i = bin.children.numItems - 1; i >= 0; i--) { c = bin.children[i]; if (String(c.name).indexOf(stem) === 0) return c; }
  return null;
}
function cspFree(track, s, e) {
  for (var i = 0; i < track.clips.numItems; i++) { var c = track.clips[i]; if (c.start.seconds < e - 0.001 && c.end.seconds > s + 0.001) return false; }
  return true;
}
function cspTrack(seq, s, e) {
  var vt = seq.videoTracks, i;
  for (i = 1; i < vt.numTracks; i++) if (cspFree(vt[i], s, e)) return i;
  var before = vt.numTracks;
  try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, before, 0); } catch (eQ) {}
  seq = app.project.activeSequence;
  if (seq.videoTracks.numTracks > before) return seq.videoTracks.numTracks - 1;
  return (vt.numTracks && cspFree(vt[0], s, e)) ? 0 : -1;
}
function cspImport(f, o) {
  var bin = cspBin();
  app.project.importFiles([f.fsName], true, bin, true);
  var item = cspFind(bin, f.name);
  if (!item) return null;
  try { item.setOverrideFrameRate(o.fps); } catch (eF) {}
  try { item.name = 'CS ' + o.name; } catch (eN) {}
  return item;
}
var CSP_RX = /[\\\/]CS_[^\\\/]+_\d+\.png$/i;
function csp_place(o) {
  try {
    var f = new File(o.file); if (!f.exists) return 'err|The rendered frames are missing. Try again.';
    var len = o.frames / o.fps;
    var seq = app.project.activeSequence; if (!seq) return 'err|Open a sequence first.';
    var item = cspImport(f, o);
    if (!item) return 'err|Premiere did not import the frames. Check the disk has free space and try again.';
    var s = seq.getPlayerPosition().seconds;
    var v = cspTrack(seq, s, s + len);
    if (v < 0) return 'err|No empty video track at the playhead. Add a video track and try again.';
    seq = app.project.activeSequence;
    seq.videoTracks[v].overwriteClip(item, s);
    return 'ok|V' + (v + 1);
  } catch (e) { return cspErr(e); }
}
function csp_selected() {
  try {
    var seq = app.project.activeSequence; if (!seq) return 'err|Open a sequence first.';
    var sel = seq.getSelection();
    for (var i = 0; i < sel.length; i++) {
      var c = sel[i], mp = '';
      try { mp = c.projectItem.getMediaPath(); } catch (eM) {}
      if (!CSP_RX.test(mp)) continue;
      var vt = seq.videoTracks, t = -1;
      for (var k = 0; k < vt.numTracks && t < 0; k++) for (var j = 0; j < vt[k].clips.numItems; j++) if (vt[k].clips[j].nodeId === c.nodeId) { t = k; break; }
      return 'ok|' + cspJson({ path: mp, node: c.nodeId, track: t, start: c.start.seconds, trackName: t >= 0 ? 'V' + (t + 1) : '' });
    }
    return 'err|Select a CreatorStash text clip on the timeline first.';
  } catch (e) { return cspErr(e); }
}
function csp_replace(o) {
  try {
    var f = new File(o.file); if (!f.exists) return 'err|The rendered frames are missing. Try again.';
    var seq = app.project.activeSequence; if (!seq) return 'err|Open a sequence first.';
    var vt = seq.videoTracks, clip = null, track = -1;
    for (var k = 0; k < vt.numTracks && !clip; k++) for (var j = 0; j < vt[k].clips.numItems; j++) if (vt[k].clips[j].nodeId === o.node) { clip = vt[k].clips[j]; track = k; break; }
    if (!clip) return 'err|The text clip is gone from the timeline. Select it again and press Edit selected.';
    var start = clip.start.seconds;
    var item = cspImport(f, o);
    if (!item) return 'err|Premiere did not import the frames. Check the disk has free space and try again.';
    clip.remove(false, false);
    seq = app.project.activeSequence;
    seq.videoTracks[track].overwriteClip(item, start);
    var nn = '', cl = seq.videoTracks[track].clips;
    for (var n = 0; n < cl.numItems; n++) if (Math.abs(cl[n].start.seconds - start) < 0.01) { nn = cl[n].nodeId; break; }
    return 'ok|V' + (track + 1) + '|' + nn;
  } catch (e) { return cspErr(e); }
}
'csp-ready';
