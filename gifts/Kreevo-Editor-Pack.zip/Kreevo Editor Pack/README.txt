Kreevo Editor Pack - a thank-you gift

- Phone Wallpapers: 5 designs (1290x2796, fits every phone)
- Desktop Wallpaper: After Effects shortcuts (2560x1440)
- Poster: After Effects shortcuts, A3 PDF, print it for your desk

Mac: Ctrl = Cmd, Alt = Option.

Share your setup and tag @kreevo.assets!
kreevo.github.io
